﻿$(document).ready(function () {

    var IdentifyReload = true;


    $(this).scrollTop(0);

    //trigger inputan date :

    //$("#dtp_DateOfProposal").on("input", function () {
    //    generateFiscalYear();

    //    var tgl = $("#dtp_DateOfProposal").val();
    //    var btnName = $("#txt_DateOfProposal");
    //    formatTanggal(tgl, btnName); 
    //});

    //$("#dtp_DateOfProposal").on("change", function () {
    //    generateFiscalYear();

    //    var tgl = $("#dtp_DateOfProposal").val();
    //    var btnName = $("#txt_DateOfProposal");
    //    formatTanggal(tgl, btnName); 
    //});
     
    function generateFiscalYear() {
        var tgl = $("#dtp_DateOfProposal").val();           // contoh: "2025-11-18"
        var date = new Date(tgl);

        let tahun = date.getFullYear();
        let bulan = date.getMonth() + 1;   // getMonth() = 0-11 → tambah 1

        var fiscalYear;

        if (bulan >= 4) {
            fiscalYear = tahun;            // mulai April → FY = tahun input
        } else {
            fiscalYear = tahun - 1;        // Jan–Mar → FY = tahun sebelumnya
        }

        $("#txt_FiscalYear").val(fiscalYear);
        $("#txt_RateFY").html("(FY " + fiscalYear  +") ")



        //set untuk nama kolom di inputan Payment
        var FY1 = fiscalYear;
        var FY2 = fiscalYear + 1
        var FY3 = fiscalYear + 2

        $("#span_PaymentFY1").html(FY1);
        $("#span_PaymentFY2").html(FY2);
        $("#span_PaymentFY3").html(FY3); 
        // end of 



      //get Rate
            var xFiscalYear = fiscalYear;
            var xCurrencyCode = "USD"; 
            GetRate(xFiscalYear, xCurrencyCode)
      //end of   
    }

    

    $("#dtp_PeriodeCommencement").on("input", function () {

        var tgl = $("#dtp_PeriodeCommencement").val();
        var btnName = "#txt_PeriodeCommencement";
        formatTanggal(tgl, btnName);
    });

    $("#dtp_PeriodeCommencement").on("change", function () { 
        var tgl = $("#dtp_PeriodeCommencement").val();
        var btnName = "#txt_PeriodeCommencement"; 
        formatTanggal(tgl, btnName);
    });

    $("#dtp_PeriodeCompletion").on("input", function () {

        var tgl = $("#dtp_PeriodeCompletion").val();
        var btnName = "#txt_PeriodeCompletion";
        formatTanggal(tgl, btnName);
    });

    $("#dtp_PeriodeCompletion").on("change", function () { 
        var tgl = $("#dtp_PeriodeCompletion").val();
        var btnName = "#txt_PeriodeCompletion"; 
        formatTanggal(tgl, btnName);
    });
     
    //end of trigger inputan Date 



    //OTHER FUNCTION
    function formatTanggal(tgl, dtp) {
        // tgl contoh: "03/13/2026"

        if (tgl == "" || tgl == null) {
            return;
        }

        // Input contoh: "2025-11-21"
        let parts = tgl.split("-");

        let tahun = parts[0];
        let bulan = parts[1];
        let hari = parts[2];

        let namaBulan = [
            "", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
            "Juli", "Agustus", "September", "Oktober", "November", "Desember"
        ];

     
        var result = ""
        if (dtp == "#txt_PeriodeCommencement" || dtp == "#txt_PeriodeCompletion") {
              result = namaBulan[parseInt(bulan)] + " " + tahun;
        } else { 
            var result = parseInt(hari) + " " + namaBulan[parseInt(bulan)] + " " + tahun;
        }

        $(dtp).html(result);
  

    }
    //end of OTHER FUNCTION



    //PAYMENT 
    $(".inputamt").on('input', function () {
        this.value = this.value.replace(/[^0-9.,]/g, '');

        // Replace koma jadi titik
        this.value = this.value.replace(',', '.');

        // Batasi hanya 1 angka setelah desimal
        this.value = this.value.replace(/^(\d+)\.(\d?).*$/, '$1.$2');
    })

    PAYMENT();

    function PAYMENT() {

        // SIMPAN LAST VALUE saat focus
        $('[id^="CAPEX_"], [id^="EXP_"]').on('focus', function () {
            $(this).data('lastvalue', $(this).val());
        
        });

        // Event untuk semua input CAPEX & EXP
        $('[id^="CAPEX_"], [id^="EXP_"]').on('input', function () {

            var limit = parseFloat($("#txt_AmountBudget").val()) || 0;
            var currentBox = $(this);
            var newValue = parseFloat(currentBox.val()) || 0;

            // =========================
            // Hitung total baru TANPA update field total lebih dulu
            // =========================
            var totalBaru = 0;

            $('[id^="TOTAL_FY"]').each(function () {
                totalBaru += parseFloat($(this).val()) || 0;
            });

            // Kurangi nilai lama di kolom ini, tambahkan nilai baru
            var lastValue = parseFloat(currentBox.data('lastvalue')) || 0;
            totalBaru = totalBaru - lastValue + newValue;

            // =========================
            // VALIDASI LIMIT
            // =========================
            if (totalBaru > limit) {

                var AmountBudgetMaster = $("#txt_AmountBudget").val();


                if (IdentifyReload == false) { 

                Swal.fire({
                    title: "Total must not exceed the approved budget!",
                    text: "Your Budget : " + AmountBudgetMaster + " KUSD",
                    icon: "warning",
                    draggable: true,
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

                }
                IdentifyReload = false;

                // Kembalikan ke nilai sebelumnya
                currentBox.val(lastValue);

                // Jangan lanjut update total
                return;
            }

            // Aman → simpan nilai sebagai lastValue baru
            currentBox.data('lastvalue', newValue);

            // Update total setelah lolos validasi
            updateAllTotals();
        });






























        // -----------------------
        // FUNCTION UPDATE TOTAL
        // -----------------------
        function updateAllTotals() {
            for (var fy = 1; fy <= 3; fy++) {
                for (var q = 1; q <= 4; q++) {
                    var capex = parseFloat($("#CAPEX_FY" + fy + "_Q" + q).val()) || 0;
                    var exp = parseFloat($("#EXP_FY" + fy + "_Q" + q).val()) || 0;
                    $("#TOTAL_FY" + fy + "_Q" + q).val((capex + exp).toFixed(1));
                }
            }

            sumTOTALBARIS();
            sumEXPTOTALBARIS();
            sumCAPEXTOTALBARIS();
        }

        function sumTOTALBARIS() {
            var total = 0;
            $('[id^="TOTAL_FY"]').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $("#TOTAL_ALL").val(total.toFixed(1));
        }

        function sumEXPTOTALBARIS() {
            var total = 0;
            $('[id^="EXP_FY"]').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $("#EXP_TOTAL").val(total.toFixed(1));
        }

        function sumCAPEXTOTALBARIS() {
            var total = 0;
            $('[id^="CAPEX_FY"]').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $("#CAPEX_TOTAL").val(total.toFixed(1));
        }

    }
//END OF PAYMENT


    //PURPOSE
    $("#divPurposeDescription, #divRequisiteSpesification, #divExpectedEffect").summernote({
        focus: false,
        height: 150,
        codemirror: { // codemirror options
            mode: 'text/html',
            htmlMode: true,
            lineNumbers: true,
            theme: 'monokai'
        },

        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'italic', 'underline', 'clear', 'fontsize', 'color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['picture', 'table']],
            ['view', ['fullscreen', 'help']],
            ['misc', ['undo', 'redo']],
            ['style2', ['hr']]
        ],
    });
    //END OF PURPOSE



    //validasi UPLOAD FILE PDF
    function validatePdf(input) {
        const file = input.files[0];
        const errorMsg = input.parentElement.querySelector("small");

        if (!file) return;

        // Validasi tipe PDF
        if (file.type !== "application/pdf") {
            errorMsg.classList.remove("d-none");
            errorMsg.textContent = "File must be PDF.";
            input.value = "";
            return;
        }

        // Validasi ukuran maksimum 2MB
        if (file.size > 2 * 1024 * 1024) { 


            // Hapus file dari input (clear)
            input.value = "";  


            Swal.fire({
                icon: 'info',
                title: 'Your file size is more than 2MB',
                text: 'Re-upload with file size not exceeding 2MB',
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big'
                }
            });

        }

        // Jika OK
        errorMsg.classList.add("d-none");
    }

    // Terapkan ke setiap input file
    ["fileContentOverview", "fileSchedule", "fileBiddingDocument"].forEach(id => {
        document.getElementById(id).addEventListener("change", function () {
            validatePdf(this);
        });
    });

    //END OF UPLOAD FILE PDF


    //pilih decision
    $('input[name="DecisionLevel"]').on('change', function () {
        // Jika ada yang dipilih, tampilkan div
        if ($('input[name="DecisionLevel"]:checked').length > 0) {
            $('#div_AFDType').show();
            $("#div_inputan").removeClass("hidden");

        }
    });
    //end of pilih decision


    //validasi radiobutton disposal 
    $("#txtOtherDept").hide();         // Awal kondisi: input text hidden


    $("input[name='deptDisposal']").change(function () {
        if ($("#otherDept").is(":checked")) {
            $("#txtOtherDept").show();
        } else {
            $("#txtOtherDept").hide();
            $("#txtOtherDept").val(""); // optionally clear input
        }
    });
    //END OF validasi  radiobutton disposal


    //BUDGET SHEET
    $("#btnOpenBudgetForm").click(function () {
        var txt_CoverLetterID = $("#txt_CoverLetterID").val(); 

        if (txt_CoverLetterID === undefined || txt_CoverLetterID === "") {

            Swal.fire({
                icon: 'warning',
                title:'The Cover Letter ID has not been created yet.',
                text: 'Please save this as a draft first !!!',
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big'
                }
            });

        } else {
            var url = "/AFDCoverLetter/BudgetSheet?id=" + txt_CoverLetterID;
            window.open(url, "_blank"); // buka new tab
        }


      
    });
    //END OF BUDGET SHEET


    //VA SHEET
    $("#btnOpenVAReportForm").click(function () {
        var txt_CoverLetterID = $("#txt_CoverLetterID").val(); 

        if (txt_CoverLetterID === undefined || txt_CoverLetterID === "") {

            Swal.fire({
                icon: 'warning',
                title: 'The Cover Letter ID has not been created yet.',
                text: 'Please save this as a draft first !!!',
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big'
                }
            });

        } else {
            var url = "/AFDCoverLetter/VASheet?id=" + txt_CoverLetterID;
            window.open(url, "_blank"); // buka new tab
        }



    });
    //END OF VA SHEET


    //AFD Type Change
    $(document).on('change', '#ddl_AFDType', function () {
        var val = $(this).val();
        getAFDSubType(val);

        $("#ddl_Category").remove();
        $("#txt_FormAFDID").val("");

        if (val === "CAPITAL INVESTMENT") {
            $("#div_ResponsibleforDisposal").addClass("hidden");
            $("#txt_AmountBudget").val("");
            $("#span_AmountBudget").html("");
            $("#div_Payment").addClass("hidden");
        }

        if (val === "DISPOSAL") {
            $("#div_ResponsibleforDisposal").removeClass("hidden");
            $("#txt_AmountBudget").val(0);
            $("#span_AmountBudget").html("(Additional)");
            $("#btn_SearchMasterBudget").addClass("hidden");
            $("#div_Payment").removeClass("hidden");
        }
    });


    function getAFDSubType(val) {
        if (val === "CAPITAL INVESTMENT") {
            html = `  
                    <select id="ddl_AFDSubType" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Rutin</option> 
                        <option>Special</option> 
                    </select> `;
        }

        else if (val === "DISPOSAL") {
            html = `  
                    <select id="ddl_AFDSubType" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Stock</option> 
                        <option>Asset</option> 
                    </select> `;
        }

        // isi atau kosongkan wrapper
        $('#div_AFDSubType').html(html);

    }
    //END OF AFD Type Change
     

    //AFD Sub Type Change
    $('#div_AFDSubType').on('change', function () {
        $('#div_Category').removeClass('hidden');
    });

     
    $(document).on('change', '#ddl_AFDSubType', function () {
      
        //isi pilihan pada category 
        getCategory();
         
        $("#span_ViewAmount").html("");
        $("#txt_FormAFDID").val("");
    });

    function getCategory() {
        html2 = `<select id="ddl_Category" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Mesin / Fasilitas Produksi langsung</option>
                        <option>Lain-lain (selain mesin / fasilitas produksi)</option>
                    </select>`;

        $('#div_Category').html(html2);
    }
    // END OF AFD Sub Type Change


    //Category Change 
    $(document).on('change', '#ddl_Category', function () { 
        $('#div_Category').removeClass('hidden');
        //$("#tbl_minmaxamount").removeClass('hidden');


        var AFDType = $("#ddl_AFDType").val();

        //jika DISPOSAL tidak ingin menggunakan master
        if (AFDType === "DISPOSAL") {
            $("#btn_SearchMasterBudget").addClass("hidden");
            $("#txt_AmountBudget").prop("disabled", false); 
            $("#txt_AmountBudget").val("");  
            $("#txt_AmountBudget").focus(); 
        } else {
            $("#btn_SearchMasterBudget").removeClass("hidden");
            $("#txt_AmountBudget").prop("disabled", true); 
            $("#txt_AmountBudget").val(0);  
        }

        ////jika DISPOSAL ingin menggunakan master
        //$("#btn_SearchMasterBudget").removeClass("hidden");
      
      
        GetAmountRange();

    });


    function GetAmountRange() {

        var xDecision = $('input[name="DecisionLevel"]:checked').val();
        var xAFDType = $('#ddl_AFDType').val();
        var xAFDSubType = $('#ddl_AFDSubType').val();
        var xCategory = $('#ddl_Category').val();

        $.ajax({
            url: "/AFDCoverLetter/GetAmountRange",
            type: "GET",
            data: {
                decisionLevel: xDecision,
                afdType: xAFDType,
                afdSubType: xAFDSubType,
                category: xCategory
            },
            success: function (res) {
                if (res.status === "error") {
                    //alert(res.message);

                    Swal.fire({
                        icon: 'warning',
                        title: "Master data is not available.",
                        text: "please check in table M_Form_AFD",
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big'
                        }
                    });

                    $("#span_MinAmount").html(0);
                    $("#span_MaxAmount").html(0);
                    $("#span_ViewAmount").html(0);
                    $("#txt_FormAFDID").html(0);

                    return;

                } else {

                    // jika tidak error 
                    $("#span_MinAmount").html(res.minAmount);
                    $("#span_MaxAmount").html(res.maxAmount);
                    $("#span_ViewAmount").html(res.viewAmount);
                    $("#txt_FormAFDID").val(res.idAFDForm);

                }
            }
        });


    }
     
    function GetRate(xFiscalYear, xCurrencyCode) { 
        $.ajax({
            url: "/AFDCoverLetter/GetRate",
            type: "GET",
            data: {
                FiscalYear: xFiscalYear,
                CurrencyCode: xCurrencyCode
            },
            success: function (res) {
                if (res.status === "error") {
                    //alert(res.message);

                    Swal.fire({
                        icon: 'warning',
                        title: res.message,
                        text: res.solution, 
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });
                      

                    $("#txt_Rate").val("").prop("disabled", true);

                    return;
                } else {

                    // jika tidak error

                    let nilai = res.Rate;

                    nilai = (nilai === null || nilai === undefined) ? "" : String(nilai).replace(/,/g, "");

                    if (nilai === "" || isNaN(Number(nilai))) {
                        $("#txt_Rate").val("");
                    } else {
                        // gunakan locale en-US untuk pemisah koma (16,750). Untuk format Indonesia ganti ke 'id-ID' -> 16.750
                        let formatted = Number(nilai).toLocaleString('en-US');
                        $("#txt_Rate").val(formatted);
                    }
                     

                }
            }
        }); 
    } 
     
    $("#btn_SearchMasterBudget").click(function () {

        // Tampilkan modal
        $("#modalSearchMasterBudget").modal("show");

        // Loading text
        $("#mb_list").html("Loading the final master budget data, please wait...");


        $.ajax({
            url: "/AFDCoverLetter/GetMasterBudgetFinal",
            type: "GET",
            dataType: "json",
            data: {
                CostSection: $("#txt_CostSection").val(),   // contoh pengambilan dari dropdown
                FiscalYear: $("#txt_FiscalYear").val(),
                AFDSubType: $("#ddl_AFDSubType").val(),
                MinAmount: $("#span_MinAmount").text(),
                MaxAmount: $("#span_MaxAmount").text()
            },
            success: function (res) {

                // Jika server kirim status error
                if (res.status !== "ok") {
                    $("#mb_list").html(`
                    <p style='color:red'>${res.message}</p>
                    <small>${res.solution}</small>
                `);
                    return;
                }

                // Jika datanya kosong
                if (res.data.length === 0) {
                    $("#mb_list").html("<p>No data found.</p>");
                    return;
                }

                // Build tabel
                let html = "<table class='table table-bordered table-lg'>";
                html += `
                    <table class="table table-bordered table-lg">
                    <thead>
                    <tr >
                        <th class='hidden'>Budget Final ID</th>
                        <th class="text-center">Budget Type</th>
                        <th class="text-center">Title</th> 
                        <th class="text-center">Purpose</th>
                        <th class="text-center">Cost Section</th>
                        <th class="text-center">Fiscal Year</th>
                        <th class="text-center">Budget Amount</th>
                        <th class="text-center">Remark Budget Amount</th>
                        <th class="text-center">Remark</th> 
                        <th></th> 
                    </tr>
                    </thead>
                    <tbody>`;

                res.data.forEach(x => {
                    html += `
                    <tr>
                        <td class='hidden'>${x.Budget_Final_ID ?? ''}</td>
                        <td>${x.Budget_Type ?? ''}</td>
                        <td>${x.Title ?? ''}</td>
                        <td style='text-align:center'>${x.Purpose_Type ?? ''}</td>
                        <td style='text-align:center'>${x.Cost_Section ?? ''}</td>
                        <td style='text-align:center'>${x.Fiscal_Year ?? ''}</td>
                        <td style='text-align:center'>${x.Budget_Amount ?? ''}</td>
                        <td style='text-align:right'>${x.Remark_Budget_Amount ?? ''}</td>
                        <td>${x.Remark ?? ''}</td>
                        <td style='text-align:center'><button class="btn btn-primary btn-sm btnSelect">Select</button></td>
                    </tr>
                `;
                });

                html += "</tbody></table>";

                $("#mb_list").html(html);

            },
            error: function () {
                $("#mb_list").html("<p style='color:red'>Oops! Something went wrong while loading the data.</p>");
            }
        });

    });

    $(document).on("click", ".btnSelect", function () {

        // Ambil nilai Budget Final ID dari kolom pertama (yang hidden)
        let budgetFinalID = $(this).closest("tr").find("td:eq(0)").text().trim();

        console.log("Budget Final ID =", budgetFinalID);
  
        // Lanjutkan pengecekan ID ke server
        checkBudgetIDinTransaction(budgetFinalID);
    });

    function checkBudgetIDinTransaction(xbudgetFinalID) {
        $.ajax({
            url: "/AFDCoverLetter/CheckBudgetIDinTransaction",
            type: "GET",
            dataType: "json",
            data: { BudgetFinalID: xbudgetFinalID },
            success: function (res) {

                if (res.status === "exists") { 
                    Swal.fire({
                        icon: 'warning',
                        title: res.message,
                        //text: res.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });
                }


                if (res.status === "ok")
                {  
                    var Budget_Final_ID = res.data[0].Budget_Final_ID;
                    var Title = res.data[0].Title; 
                    var Budget_Type = res.data[0].Budget_Type;
                    var Budget_Amount = res.data[0].Budget_Amount;
                    var Purpose_Type = res.data[0].Purpose_Type;


                    $("#span_BudgetFinalID").html(Budget_Final_ID);
                    $("#span_AmountBudget").html(" (" + Budget_Type + ")");

                    Budget_Amount = Number(Budget_Amount).toLocaleString('en-US');
                    $("#txt_AmountBudget").val(Budget_Amount);

                   // $("#txt_PurposeFor").val(Purpose_Type); 
                    $("#ddl_PurposeFor").val(Purpose_Type); 
                     
                    $("#btn_CloseModalMasterBudget").trigger("click");

                    Title = Title.toUpperCase();
                    $("#txt_Title").val(Title); 

                    //Swal.fire({
                    //    title: "Would you like the title on the cover letter to be the same as the title in the master budget?",
                    //    text: "",
                    //    icon: "warning",
                    //    showCancelButton: true,
                    //    confirmButtonColor: "#10ac84",
                    //    cancelButtonColor: "#d33",
                    //    cancelButtonText: "No",
                    //    confirmButtonText: "Yes",
                    //    width: '80rem',
                    //    customClass: {
                    //        title: 'swal-title-big',
                    //        htmlContainer: 'swal-text-big',
                    //        confirmButton: 'swal-btn-big',
                    //        cancelButton: 'swal-btn-big',
                    //        icon: 'swal-icon-big'
                    //    }
                    //}).then((result) => {
                    //    if (result.isConfirmed) {

                    //        Title = Title.toUpperCase(); 
                    //        $("#txt_Title").val(Title); 
                             
                    //        Swal.fire({
                    //            title: "",
                    //            text: "Your title has been changed.",
                    //            icon: "success",
                    //            width: '60rem',
                    //            customClass: {
                    //                title: 'swal-title-big',
                    //                htmlContainer: 'swal-text-big',
                    //                icon: 'swal-icon-big',
                    //                  confirmButton: 'swal-btn-big'
                    //            }
                    //        });
                    //    }
                    //});



                    $("#div_Payment").removeClass("hidden");

                    var AFDType = $("#ddl_AFDType").val();
                    if (AFDType == "DISPOSAL") {
                        //$("#ddl_PurposeFor").removeAttr("disabled");
                        $("#ddl_PurposeFor").attr("disabled", "disabled");
                    } else {
                        $("#ddl_PurposeFor").attr("disabled", "disabled");
                    }


                }








            },
            error: function () {
                alert("Error checking Budget ID.");
            }
        });
    }


        //**********************************  ACTION BUTTON


    $("#btnSaveFirst").click(async function () {
         
        //cek ada inputan kosong ??
        let isValid = ValidasiRequiredInput(); 
        if (!isValid) {
            Swal.fire({
                icon: 'warning',
                title: "This field cannot be empty.",
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    confirmButton: 'swal-btn-big',
                    icon: 'swal-icon-big'
                }
            });
            return; // stop semua proses
        }
        //end of


        //cek range inputan budget amount
        let isValidAmountBudget = true;
        let minAmount = 0;
        let maxAmount = 0;

        if ($("#ddl_AFDType").val() === "DISPOSAL") {
            const result = ValidasiInputanAmountBudget();
            isValidAmountBudget = result.isValid;
            minAmount = result.minAmount;
            maxAmount = result.maxAmount;
        } 
        if (!isValidAmountBudget) {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Input',
                text: 'Budget amount must be between ' +
                    minAmount.toLocaleString() + ' and ' +
                    maxAmount.toLocaleString(),
                confirmButtonText: 'OK',
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big'
                }
            }).then(() => {
                $("#txt_AmountBudget")
                    .prop("disabled", false)
                    //.removeClass("is-invalid") // optional reset
                    //.addClass("is-invalid")
                    .focus();
            });

            return;
        }

        //end of



        // convert file to Base64
        async function toBase64(file) {
            if (!file) return null;
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result.split(',')[1]);
                reader.onerror = error => reject(error);
                reader.readAsDataURL(file);
            });
        }
         
        var divPurposeDescription = $('#divPurposeDescription').summernote('code');
        var divRequisiteSpesification = $('#divRequisiteSpesification').summernote('code');
        var divExpectedEffect = $('#divExpectedEffect').summernote('code');

        var AmountBudget = $("#txt_AmountBudget").val();
        AmountBudget = AmountBudget.replace(/,(?=\d{3}(?:\D|$))/g, '');

        var Rate = $("#txt_Rate").val();
        Rate = Rate.replace(/,(?=\d{3}(?:\D|$))/g, '');

        var fileContentOverview = await toBase64($("#fileContentOverview")[0].files[0]);
        var fileSchedule = await toBase64($("#fileSchedule")[0].files[0]);
        var fileBiddingDocument = await toBase64($("#fileBiddingDocument")[0].files[0]);


        var model = {
            CoverLetterID: $("#txt_CoverLetterID").val(),
            FiscalYear: $("#txt_FiscalYear").val(),
            DateOfProposal: $("#dtp_DateOfProposal").val(),
            DateOfDecision: $("#dtp_DateofDecision").val(),
            DecisionNumber: $("#txt_DecisionNumber").val(),
            Title: $("#txt_Title").val(),
            AFDType: $("#ddl_AFDType").val(),
            AFDSubType: $("#ddl_AFDSubType").val(),
            MinAmount: $("#span_MinAmount").text(),
            MaxAmount: $("#span_MaxAmount").text(),
            FormAFDID: $("#txt_FormAFDID").val(),
            CostSection: $("#txt_CostSection").val(),
            NIKLogin: $("#txt_NIKLogin").val(),
            AmountBudget: AmountBudget, 
            AmountBudgetID: $("#span_BudgetFinalID").html(),
            Rate: Rate,
            Place: $("#txt_Place").val(),
            PeriodeCommencement: $("#dtp_PeriodeCommencement").val(),
            PeriodeCompletion: $("#dtp_PeriodeCompletion").val(),
            //PurposeFor: $("#txt_PurposeFor").val(),
            PurposeFor: $("#ddl_PurposeFor").val(),
            PurposeDescription: divPurposeDescription,
            RequisiteSpecification: divRequisiteSpesification,
            ExpectedEffect: divExpectedEffect,
            CoordinatorName: $("#txt_CoordinatorName").val(),
            CoordinatorSection: $("#txt_CoordinatorSection").val(),
            DecisionLevel: $("input[name='DecisionLevel']:checked").val(),
            DisposalResponsible: $("input[name='deptDisposal']:checked").val(),

            Payment: {
                CAPEX: {
                    FY1: {
                        Q1: $("#CAPEX_FY1_Q1").val(),
                        Q2: $("#CAPEX_FY1_Q2").val(),
                        Q3: $("#CAPEX_FY1_Q3").val(),
                        Q4: $("#CAPEX_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#CAPEX_FY2_Q1").val(),
                        Q2: $("#CAPEX_FY2_Q2").val(),
                        Q3: $("#CAPEX_FY2_Q3").val(),
                        Q4: $("#CAPEX_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#CAPEX_FY3_Q1").val(),
                        Q2: $("#CAPEX_FY3_Q2").val(),
                        Q3: $("#CAPEX_FY3_Q3").val(),
                        Q4: $("#CAPEX_FY3_Q4").val()
                    },
                    Total: $("#CAPEX_TOTAL").val()
                },

                // EXPENSE
                EXPENSE: {
                    FY1: {
                        Q1: $("#EXP_FY1_Q1").val(),
                        Q2: $("#EXP_FY1_Q2").val(),
                        Q3: $("#EXP_FY1_Q3").val(),
                        Q4: $("#EXP_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#EXP_FY2_Q1").val(),
                        Q2: $("#EXP_FY2_Q2").val(),
                        Q3: $("#EXP_FY2_Q3").val(),
                        Q4: $("#EXP_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#EXP_FY3_Q1").val(),
                        Q2: $("#EXP_FY3_Q2").val(),
                        Q3: $("#EXP_FY3_Q3").val(),
                        Q4: $("#EXP_FY3_Q4").val()
                    },
                    Total: $("#EXP_TOTAL").val()
                },

                // TOTAL ROW
                TOTAL: {
                    FY1: {
                        Q1: $("#TOTAL_FY1_Q1").val(),
                        Q2: $("#TOTAL_FY1_Q2").val(),
                        Q3: $("#TOTAL_FY1_Q3").val(),
                        Q4: $("#TOTAL_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#TOTAL_FY2_Q1").val(),
                        Q2: $("#TOTAL_FY2_Q2").val(),
                        Q3: $("#TOTAL_FY2_Q3").val(),
                        Q4: $("#TOTAL_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#TOTAL_FY3_Q1").val(),
                        Q2: $("#TOTAL_FY3_Q2").val(),
                        Q3: $("#TOTAL_FY3_Q3").val(),
                        Q4: $("#TOTAL_FY3_Q4").val()
                    },
                    Total: $("#TOTAL_ALL").val()
                }
            },


            FileContentOverview: fileContentOverview,
            FileNameContentOverview: $("#fileContentOverview").val(),
            FileSchedule: fileSchedule,
            FileNameSchedule: $("#fileSchedule").val(),
            FileBiddingDocument: fileBiddingDocument,
            FileNameBiddingDocument: $("#fileBiddingDocument").val(),
        };

        // Tampilkan loading sebelum AJAX dijalankan
        Swal.fire({
            title: 'Saving your data...',
            text: 'Please wait',
            width: '60rem',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                title: 'swal-title-big',
                htmlContainer: 'swal-text-big',
                confirmButton: 'swal-btn-big',
                icon: 'swal-icon-big'
            },
            didOpen: () => {
                Swal.showLoading();
            }
        });


        $.ajax({
            url: '/AFDCoverLetter/SaveDraft',
            type: 'POST',
            data: JSON.stringify(model),
            contentType: "application/json; charset=utf-8",
            success: function (result) {

                Swal.close(); // MATIKAN LOADING

                $("#txt_CoverLetterID").val(result.afd_id);   
                $("#btnSaveFirst").addClass("hidden");
                $("#btnSaveDraft").removeClass("hidden");
                $("#btnDeleteData").removeClass("hidden");
              


                $("#ddl_AFDType").prop("disabled", true);
                $("#ddl_AFDSubType").prop("disabled", true);
                $("#ddl_Category").prop("disabled", true);

                  
                Swal.fire({
                    icon: 'success',
                    title: 'Your data has been saved as a draft.',
                    text: '',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });



                if ($("#ddl_AFDType").val() === "DISPOSAL") {
                    $("#div_Attach1").removeClass("hidden"); 
                    $("#div_Attach3").removeClass("hidden"); 
                    $("#div_Attach5").removeClass("hidden");
                }

                if ($("#ddl_AFDType").val() === "CAPITAL INVESTMENT") {
                    $("#div_Attach1").removeClass("hidden");
                    $("#div_Attach2").removeClass("hidden");
                    $("#div_Attach3").removeClass("hidden");
                    $("#div_Attach4").removeClass("hidden");
                    $("#div_Attach5").removeClass("hidden");
                }


                $("input[name='DecisionLevel']").prop("disabled", true);
                $("#div_btnPreviewCoverLetter").removeClass("hidden");
                var CoverLetterID = $("#txt_CoverLetterID").val();
                $("#btnPreviewCoverLetter").attr("href", "/AFDCoverLetter/PrintCoverLetter?CoverLetterId=" + CoverLetterID);



            },
            error: function (xhr) {


                Swal.close(); // MATIKAN LOADING


                Swal.fire({
                    icon: 'error',
                    title: 'Your data cannot be saved as a draft.',
                    text: xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText,
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });
            }
        });


    
    });

    $("#btnSaveDraft").click(async function () {

        //cek ada inputan kosong ??
        let isValid = ValidasiRequiredInput(); 
        if (!isValid) {
            Swal.fire({
                icon: 'warning',
                title: "This field cannot be empty.",
                width: '60rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    confirmButton: 'swal-btn-big',
                    icon: 'swal-icon-big'
                }
            });
            return; // stop semua proses
        }
        //end of


        //cek range inputan budget amount
        let isValidAmountBudget = true;
        let minAmount = 0;
        let maxAmount = 0;

        if ($("#ddl_AFDType").val() === "DISPOSAL") {
            const result = ValidasiInputanAmountBudget();
            isValidAmountBudget = result.isValid;
            minAmount = result.minAmount;
            maxAmount = result.maxAmount;
        }
        if (!isValidAmountBudget) {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Input',
                text: 'Budget amount must be between ' +
                    minAmount.toLocaleString() + ' and ' +
                    maxAmount.toLocaleString(),
                confirmButtonText: 'OK',
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big'
                }
            });

            $("#txt_AmountBudget").addClass("is-invalid");
            return; // STOP proses
        }
        //end of











        // convert file to Base64
        async function toBase64(file) {
            if (!file) return null;
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result.split(',')[1]);
                reader.onerror = error => reject(error);
                reader.readAsDataURL(file);
            });
        }


        var divPurposeDescription = $('#divPurposeDescription').summernote('code');
        var divRequisiteSpesification = $('#divRequisiteSpesification').summernote('code');
        var divExpectedEffect = $('#divExpectedEffect').summernote('code');

        var AmountBudget = $("#txt_AmountBudget").val();
        AmountBudget = AmountBudget.replace(/,(?=\d{3}(?:\D|$))/g, '');

        var Rate = $("#txt_Rate").val();
        Rate = Rate.replace(/,(?=\d{3}(?:\D|$))/g, '');

        var fileContentOverview = await toBase64($("#fileContentOverview")[0].files[0]);
        var fileSchedule = await toBase64($("#fileSchedule")[0].files[0]);
        var fileBiddingDocument = await toBase64($("#fileBiddingDocument")[0].files[0]);


        var model = {

            CoverLetterID: $("#txt_CoverLetterID").val(),
            FiscalYear: $("#txt_FiscalYear").val(),
            DateOfProposal: $("#dtp_DateOfProposal").val(),
            DateOfDecision: $("#dtp_DateofDecision").val(),
            DecisionNumber: $("#txt_DecisionNumber").val(),
            Title: $("#txt_Title").val(),
            AFDType: $("#ddl_AFDType").val(),
            AFDSubType: $("#ddl_AFDSubType").val(),
            MinAmount: $("#span_MinAmount").text(),
            MaxAmount: $("#span_MaxAmount").text(),
            FormAFDID: $("#txt_FormAFDID").val(),
            CostSection: $("#txt_CostSection").val(),
            NIKLogin: $("#txt_NIKLogin").val(),
            AmountBudget: AmountBudget,
            AmountBudgetID: $("#span_BudgetFinalID").html(),
            Rate: Rate,
            Place: $("#txt_Place").val(),
            PeriodeCommencement: $("#dtp_PeriodeCommencement").val(),
            PeriodeCompletion: $("#dtp_PeriodeCompletion").val(),
            //PurposeFor: $("#txt_PurposeFor").val(),
            PurposeFor: $("#ddl_PurposeFor").val(),
            PurposeDescription: divPurposeDescription,
            RequisiteSpecification: divRequisiteSpesification,
            ExpectedEffect: divExpectedEffect,
            CoordinatorName: $("#txt_CoordinatorName").val(),
            CoordinatorSection: $("#txt_CoordinatorSection").val(),
            DecisionLevel: $("input[name='DecisionLevel']:checked").val(),
            DisposalResponsible: $("input[name='deptDisposal']:checked").val(),


            Payment: {
                CAPEX: {
                    FY1: {
                        Q1: $("#CAPEX_FY1_Q1").val(),
                        Q2: $("#CAPEX_FY1_Q2").val(),
                        Q3: $("#CAPEX_FY1_Q3").val(),
                        Q4: $("#CAPEX_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#CAPEX_FY2_Q1").val(),
                        Q2: $("#CAPEX_FY2_Q2").val(),
                        Q3: $("#CAPEX_FY2_Q3").val(),
                        Q4: $("#CAPEX_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#CAPEX_FY3_Q1").val(),
                        Q2: $("#CAPEX_FY3_Q2").val(),
                        Q3: $("#CAPEX_FY3_Q3").val(),
                        Q4: $("#CAPEX_FY3_Q4").val()
                    },
                    Total: $("#CAPEX_TOTAL").val()
                },

                // EXPENSE
                EXPENSE: {
                    FY1: {
                        Q1: $("#EXP_FY1_Q1").val(),
                        Q2: $("#EXP_FY1_Q2").val(),
                        Q3: $("#EXP_FY1_Q3").val(),
                        Q4: $("#EXP_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#EXP_FY2_Q1").val(),
                        Q2: $("#EXP_FY2_Q2").val(),
                        Q3: $("#EXP_FY2_Q3").val(),
                        Q4: $("#EXP_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#EXP_FY3_Q1").val(),
                        Q2: $("#EXP_FY3_Q2").val(),
                        Q3: $("#EXP_FY3_Q3").val(),
                        Q4: $("#EXP_FY3_Q4").val()
                    },
                    Total: $("#EXP_TOTAL").val()
                },

                // TOTAL ROW
                TOTAL: {
                    FY1: {
                        Q1: $("#TOTAL_FY1_Q1").val(),
                        Q2: $("#TOTAL_FY1_Q2").val(),
                        Q3: $("#TOTAL_FY1_Q3").val(),
                        Q4: $("#TOTAL_FY1_Q4").val()
                    },
                    FY2: {
                        Q1: $("#TOTAL_FY2_Q1").val(),
                        Q2: $("#TOTAL_FY2_Q2").val(),
                        Q3: $("#TOTAL_FY2_Q3").val(),
                        Q4: $("#TOTAL_FY2_Q4").val()
                    },
                    FY3: {
                        Q1: $("#TOTAL_FY3_Q1").val(),
                        Q2: $("#TOTAL_FY3_Q2").val(),
                        Q3: $("#TOTAL_FY3_Q3").val(),
                        Q4: $("#TOTAL_FY3_Q4").val()
                    },
                    Total: $("#TOTAL_ALL").val()
                }
            },


            FileContentOverview: fileContentOverview,
            FileNameContentOverview: $("#fileContentOverview").val(),
            FileSchedule: fileSchedule,
            FileNameSchedule: $("#fileSchedule").val(),
            FileBiddingDocument: fileBiddingDocument,
            FileNameBiddingDocument: $("#fileBiddingDocument").val(),
        };


        // Tampilkan loading sebelum AJAX dijalankan
        Swal.fire({
            title: 'Saving your data...',
            text: 'Please wait',
            width: '60rem',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                title: 'swal-title-big',
                htmlContainer: 'swal-text-big',
                confirmButton: 'swal-btn-big',
                icon: 'swal-icon-big'
            },
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: '/AFDCoverLetter/SaveChanges',
            type: 'POST',
            data: JSON.stringify(model),
            contentType: "application/json; charset=utf-8",
            success: function (result) {

                Swal.close(); // MATIKAN LOADING

                $("#txt_CoverLetterID").val(result.afd_id);
                $("#btnSaveFirst").addClass("hidden");
                $("#btnSaveDraft").removeClass("hidden");


                //ganti sesuai dengan file yg diupload ulang
                var url = $("#link_fileContentOverview").attr("href");  
                var folderPath = url.substring(0, url.lastIndexOf('/') + 1);

                var NewURL_ContentOverview = folderPath + result.attch1;
                var NewURL_Schedule = folderPath + result.attch3;
                var NewURL_BiddingDocument = folderPath + result.attch5;

                if (result.attch1 != "") { $("#link_fileContentOverview").attr("href", NewURL_ContentOverview);}
                if (result.attch3 != "") { $("#link_fileSchedule").attr("href", NewURL_Schedule); }
                if (result.attch5 != "") { $("#link_fileBiddingDocument").attr("href", NewURL_BiddingDocument)}; 
                //end of


                Swal.fire({
                    icon: 'success',
                    title: 'Changes to your data have been saved.',
                    width: '80rem',
                    confirmButtonText: 'OK',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                }).then((swalResult) => {

                    if (swalResult.isConfirmed) {
                        // redirect + reload otomatis
                        window.location.href = '/AFDCoverLetter/Index?CoverLetterId=' + result.afd_id;
                    }

                });



                $("#div_btnPreviewCoverLetter").removeClass("hidden");

                //$("#link_fileContentOverview").removeClass("hidden");
                //$("#link_fileSchedule").removeClass("hidden");
                //$("#link_fileBiddingDocument").removeClass("hidden");


            },
            error: function (xhr) {

                Swal.close(); // MATIKAN LOADING


                Swal.fire({
                    icon: 'error',
                    title: 'Your data cannot be changed',
                    text: xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText,
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });
            }

        });



    });

    $("#btnDeleteData").click(function () {

        var xCoverLetterId = $("#txt_CoverLetterID").val();

        $.ajax({
            url: '/AFDCoverLetter/DeleteData',
            type: 'POST',
            data: {
                CoverLetterId: xCoverLetterId
            },
            success: function (result) {

               
                    Swal.fire({
                        icon: result.status,
                        title: result.message,
                        text: result.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    }).then(() => {

                        if (result.status == "success") { 
                            $("#div_btnAction").remove();  
                            setTimeout(function () {
                                window.location.href = urlIndexAFDCL;   // redirect
                            }, 1000); // 800 ms delay supaya tidak terasa hang
                        } 
                    
                    });
               

            },
 
        });

    });

    function ValidasiRequiredInput() {

  
        var ddl_AFDType = $("#ddl_AFDType").val();
        var ddl_AFDSubType = $("#ddl_AFDSubType").val();
        var ddl_Category = $("#ddl_Category").val(); 
        var AmountBudget = $("#txt_AmountBudget").val(); 
        var txt_Title = $("#txt_Title").val();
        var txt_Place = $("#txt_Place").val();
        var dtp_PeriodeCommencement = $("#dtp_PeriodeCommencement").val();
        var dtp_PeriodeCompletion = $("#dtp_PeriodeCompletion").val();
        var ddl_PurposeFor = $("#ddl_PurposeFor").val();
        var Disposal_Responsible = $("input[name='deptDisposal']:checked").val() || "";

    
        if (ddl_AFDType == "") { $("#ddl_AFDType").focus(); return false }
        if (ddl_AFDSubType == "") { $("#ddl_AFDSubType").focus(); return false }
        if (ddl_Category == "") { $("#ddl_AFDSubType").focus(); return false }
        if (txt_Title == "") { $("#txt_Title").focus(); return false }
        if (txt_Place == "") { $("#txt_Place").focus(); return false } 
        if (AmountBudget == "") { $("#txt_AmountBudget").focus(); return false }
        if (dtp_PeriodeCommencement == "") { $("#dtp_PeriodeCommencement").focus(); return false }
        if (dtp_PeriodeCompletion == "") { $("#dtp_PeriodeCompletion").focus(); return false }
        if (ddl_PurposeFor == "") { $("#ddl_PurposeFor").focus(); return false }
     

         
        if (ddl_AFDType === "DISPOSAL" && !Disposal_Responsible) { 
            // highlight label
            $("#lblDisposal").css({ "color": "red" }); 
            $("#txt_AmountBudget").prop("disabled", false); 
            return false;
        } else {
            // reset jika valid
            $("#lblDisposal").css({ "color": "", });
            $("#txt_AmountBudget").prop("disabled", true); 
        }
         
        return true; // ← WAJIB ADA!
    }

    function ValidasiInputanAmountBudget() { 
        let amount = parseFloat($("#txt_AmountBudget").val().replace(/,/g, '')) || 0;
        let minAmount = parseFloat($("#span_MinAmount").text().replace(/,/g, '')) || 0;
        let maxAmount = parseFloat($("#span_MaxAmount").text().replace(/,/g, '')) || 0;

        let isValid = !(amount < minAmount || amount > maxAmount);

        return {
            isValid: isValid,
            minAmount: minAmount,
            maxAmount: maxAmount
        };
    }


    //**********************************  end of  ACTION BUTTON







    //**********************************  TRIGGER SAAT LOAD AWAL

    //get cost section
    var xNIKLogin = $("#txt_NIKLogin").val();
    GetCostSection(xNIKLogin)
    function GetCostSection(xNIKLogin) {
        $.ajax({
            url: "/AFDCoverLetter/GetCostSection",
            type: "GET",
            data: {
                NIKLogin: xNIKLogin,
            },
            success: function (res) {
                if (res.status === "error") {
                    //alert(res.message);

                    Swal.fire({
                        icon: 'warning',
                        title: res.message,
                        text: res.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });


                    $("#txt_CostSection").val("").prop("disabled", true);

                    return;
                } else {
                    $("#txt_CostSection").val(res.CostSection);

                }
            }
        });
    } 


    //set datenow
    var IDDataAFD = $("#txt_CoverLetterID").val();
    let today = new Date().toISOString().split('T')[0];

    if (IDDataAFD === "") { 
        $("#dtp_DateOfProposal").val(today);

        var proposalDate = $("#dtp_DateOfProposal").val();
        $("#dtp_PeriodeCommencement").attr("min", proposalDate);
        $("#dtp_PeriodeCompletion").attr("min", proposalDate);
    }

    generateFiscalYear();
    var tgl = $("#dtp_DateOfProposal").val();
    var btnName = $("#txt_DateOfProposal");
    formatTanggal(tgl, btnName); 

  
   // isi coordinator name & coordinator section  
    var xNIKLogin = $("#txt_NIKLogin").val();
    $.ajax({
        url: "/AFDCoverLetter/GetCoordinator",
        type: "GET",
        data: {
            NIKLogin: xNIKLogin
        },
        success: function (res) {
            if (res.status === "error") {

                Swal.fire({
                    icon: 'warning',
                    title: res.message,
                    text: res.solution,
                    width: '60rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

                $("#txt_CostSection").val("").prop("disabled", true);

                return;

            } else {

                // jika tidak error
                let nilai = res.data;
                 
                var CoordinatorName = nilai[0].Name.trim();
                var SectionName = nilai[0].SectionName.trim();



                $("#txt_CoordinatorName").val(CoordinatorName).prop("disabled", true);
                $("#txt_CoordinatorSection").val(SectionName).prop("disabled", true);

            }
        }
    });



    //validasi auto get data jika ada query string
    function getQueryParam(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    var coverLetterId = getQueryParam("CoverLetterId"); 
    $("#txt_CoverLetterID").val(coverLetterId);

    if (coverLetterId != null && coverLetterId !== "") {

        $("#div_inputan").removeClass("hidden");
        $("#div_AFDType").removeClass("hide"); 
        $("#div_Category").removeClass("hidden");
        $("#btn_SearchMasterBudget").removeClass("hidden");

        getCoverLetter(coverLetterId); // <-- kirim ID yang benar
       
    }

    function getCoverLetter(id) {
        $.ajax({
            url: "/AFDCoverLetter/GetCoverLetter",
            type: "GET",
            data: {
                CoverLetterId: id
            },
            success: function (res) {
                if (res.status === "success") {
                     
                    //HEADER
                    var decisionBy = res.AFD.xDecision_By; 
                    $("input[name='DecisionLevel'][value='" + decisionBy + "']").prop("checked", true);
                    $("input[name='DecisionLevel']").prop("disabled", true);
                     
                    $("#txt_CoverLetterID").val(res.AFD.xAFD_ID);
                    $("#btnPreviewCoverLetter").attr("href", "/AFDCoverLetter/PrintCoverLetter?CoverLetterId=" + res.AFD.xAFD_ID);
                    $("#txt_FiscalYear").val(res.AFD.xFiscal_Year);
                     
                    var xProposalDate = res.AFD.xProposal_Date; 
                    $("#dtp_DateOfProposal").val(xProposalDate);   
                    formatTanggal(xProposalDate, "#txt_DateOfProposal");
                     
                    var xDecision_Date = res.AFD.xDecision_Date; 
                    $("#dtp_DateofDecision").val(xDecision_Date);
                    formatTanggal(xDecision_Date, "#txt_DateofDecision");
                     
                    $("#txt_DecisionNumber").val(res.AFD.xDecision_Number); 
                    $("#txt_Title").val(res.AFD.xTitle);
                
                    $("#txt_FormAFDID").val(res.AFD.xForm_AFD_ID);
                     
                    $("#txt_CostSection").val(res.AFD.xCost_Section);
                     
                    $("#txt_AmountBudget").val(res.AFD.xBudget_Amount_Master);
                    $("#span_AmountBudget").html(" (" + res.AFD.xBudget_Type + ") ");
                    $("#span_BudgetFinalID").html(res.AFD.xBudget_Final_ID);
                    $("#txt_Rate").val(res.AFD.xExchangeRate_USD);
                    $("#txt_RateFY").html(" (" + res.AFD.xFiscal_Year + ") ");
                    $("#txt_Place").val(res.AFD.xPlace);
                     
                    var xPeriod_Commencement = res.AFD.xPeriod_Commencement;
                    $("#dtp_PeriodeCommencement").val(xPeriod_Commencement);
                    formatTanggal(xPeriod_Commencement, "#txt_PeriodeCommencement");

                    var xPeriod_Completion = res.AFD.xPeriod_Completion;
                    $("#dtp_PeriodeCompletion").val(xPeriod_Completion);
                    formatTanggal(xPeriod_Completion, "#txt_PeriodeCompletion");
                     
                    $("#divPurposeDescription").summernote("code", res.AFD.xPurpose_Description);
                    $("#divRequisiteSpesification").summernote("code", res.AFD.xSpecification_Requisite);
                    $("#divExpectedEffect").summernote("code", res.AFD.xExpected_Effect);

                    //$("#txt_PurposeFor").val(res.AFD.xPurpose_Type);
                    $("#ddl_PurposeFor").val(res.AFD.xPurpose_Type).trigger("change").prop("disabled", true);




                    $("#txt_CoordinatorName").val(res.AFD.xCoordinator_Name);
                    $("#txt_CoordinatorSection").val(res.AFD.xCoordinator_Section);



                    // Jalankan AJAX dengan promise
                    $.when( 
                        getAFDSubType(res.AFD.xAFD_Type),     // load ddl Sub Type
                        getCategory()                         // load category
                    ).done(function () {

                   
                    // Set value setelah semua dropdown ter-load
                    $("#ddl_AFDType").val(res.AFD.xAFD_Type);
                    $("#ddl_AFDSubType").val(res.AFD.xAFD_SubType);
                    $("#ddl_Category").val(res.AFD.xForm_AFD_Category);

                    // Baru jalankan ini setelah semuanya selesai
                    GetAmountRange();

                    //get Rate
                    var xFiscalYear = res.AFD.xFiscal_Year;
                    var xCurrencyCode = "USD";
                    GetRate(xFiscalYear, xCurrencyCode)


                    //set path document
                        var urlContentOverview = res.AFD.xPath_Content_Overview;  
                        $("#link_fileContentOverview").attr("href", urlContentOverview); 

                        var urlPathSchedule = res.AFD.xPath_Schedule;
                        $("#link_fileSchedule").attr("href", urlPathSchedule); 

                        var urlPathBiddingDocument = res.AFD.xPath_Bidding_Document;
                        $("#link_fileBiddingDocument").attr("href", urlPathBiddingDocument); 


                        var filenameContentOverview = decodeURIComponent(urlContentOverview.split('/').pop());
                        var filenamePathSchedule = decodeURIComponent(urlPathSchedule.split('/').pop());
                        var filenamePathBiddingDocument = decodeURIComponent(urlPathBiddingDocument.split('/').pop());

                        if (filenameContentOverview != "") { $("#link_fileContentOverview").removeClass("hidden"); }
                        if (filenamePathSchedule != "") { $("#link_fileSchedule").removeClass("hidden"); }
                        if (filenamePathBiddingDocument != "") { $("#link_fileBiddingDocument").removeClass("hidden"); }

 
                    });


                 
                   
                    //PAYMENT 
                    $("#div_Payment").removeClass("hidden");

                    // --- SET FISCAL YEAR ---
                    $("#span_PaymentFY1").html(res.Payment[0].FiscalYear);
                    $("#span_PaymentFY2").html(res.Payment[4].FiscalYear);
                    $("#span_PaymentFY3").html(res.Payment[8].FiscalYear);

                    //FOR DEBUGING
                    //console.log("=== PAYMENT CHECK ===");
                    //console.log("Length:", res.Payment.length);
                    //console.log(res.Payment);


                    // --- LOOP UNTUK CAPEX & EXP ---
                    ["CAPEX", "EXP"].forEach(type => {
                        for (let fy = 1; fy <= 3; fy++) {
                            for (let q = 1; q <= 4; q++) {
 
                                // Hitung index array Payment
                                let index = (fy - 1) * 4 + (q - 1);

                                // Pilih key data
                                let key = (type === "CAPEX") ? "CapitalExpense" : "Expense";

                                // Build selector
                                let selector = `#${type}_FY${fy}_Q${q}`;


                                //FOR DEBUGING
                                //console.log(
                                //    "selector =", selector,
                                //    "| index =", index,
                                //    "| key =", key,
                                //    "| value =", res.Payment[index] ? res.Payment[index][key] : "undefined",
                                //    "| element exists =", $(selector).length
                                //);



                                // Isi value
                                $(selector).val(res.Payment[index][key]);
                            }
                        }
                    });


                    //// Trigger event setelah semua di-set
                    //$(".inputamt").trigger("input");
                    console.log(res.AFD.xDisposal_Responsible )

                    if (res.AFD.xAFD_Type == "DISPOSAL") { 
                        $("#div_ResponsibleforDisposal").removeClass("hidden");  
                        $("input[name='deptDisposal'][value='" + res.AFD.xDisposal_Responsible + "']").prop("checked", true);
                    }


                    //VALIDASI 
                    var FlagDraft = res.AFD.xFlag_Draft;
                    if (FlagDraft == 1) { 
                        $("#btnDeleteData").removeClass("hidden");
                        $("#btnSaveFirst").addClass("hidden");
                        $("#btnSaveDraft").removeClass("hidden");
                    }

                    //VALIDASI NON EDITABLE
                    $("#btn_SearchMasterBudget").remove();
                    $("#ddl_AFDType").prop("disabled", true);
                    $("#ddl_AFDSubType").prop("disabled", true);
                    $("#ddl_Category").prop("disabled", true);


                    if (res.AFD.xAFD_Type == "CAPITAL INVESTMENT") {
                        $("#div_Attach1").removeClass("hidden");
                        $("#div_Attach2").removeClass("hidden");
                        $("#div_Attach3").removeClass("hidden");
                        $("#div_Attach4").removeClass("hidden");
                        $("#div_Attach5").removeClass("hidden");
                    }

                    if (res.AFD.xAFD_Type == "DISPOSAL") {
                        $("#div_Attach1").removeClass("hidden"); 
                        $("#div_Attach3").removeClass("hidden"); 
                        $("#div_Attach5").removeClass("hidden");
                    }

                
                    $("#div_btnPreviewCoverLetter").removeClass("hidden");

                } else {

                    Swal.fire({
                        icon: 'warning',
                        title: res.message,
                        text: '',
                        width: '40rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            icon: 'swal-icon-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });

                    $("#div_rb_decision").remove();
                    $("#div_inputan").remove();
                  
                }
            }
        }); 

    }

 



//**********************************  end of TRIGGER SAAT LOAD AWAL
     
    //PRINT PREVIEW


    //DECISION NUMBER
    $("#txt_DecisionNumber").on("input", function () {
        let v = $(this).val().toUpperCase();   // otomatis kapital
        v = v.replace(/-/g, "");               // hilangkan semua '-' sebelum format ulang

        // Pola: 1 huruf - 2 angka - 2 angka - 1 huruf - 1 huruf
        let formatted = "";

        if (v.length > 0) formatted += v.substring(0, 1);
        if (v.length > 1) formatted += "-" + v.substring(1, 3);
        if (v.length > 3) formatted += "-" + v.substring(3, 5);
        if (v.length > 5) formatted += "-" + v.substring(5, 7);

        $(this).val(formatted);
    });
    //END OF


   //VALIDASI FORMAT INPUTAN BUDGET AMOUNT 
    let lastValidValue_BudgetAmount = "";
    let isAlertShown_BudgetAmount = false;

    //format: max 1 decimal
    function isValidAmountFormat(value) { 
        const regex = /^\d{0,3}(,\d{3})*(\.\d{0,1})?$|^\d*(\.\d{0,1})?$/;
        return regex.test(value);
    }

    $("#txt_AmountBudget").on("input", function () {

        let currentValue = $(this).val();

        // kosong dianggap valid
        if (currentValue === "") {
            lastValidValue_BudgetAmount = "";
            isAlertShown_BudgetAmount = false;
            return;
        }

        if (!isValidAmountFormat(currentValue)) {

            // rollback ke nilai terakhir yang valid
            $(this).val(lastValidValue_BudgetAmount);

            if (!isAlertShown_BudgetAmount) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Format',
                    text: 'Please enter a number with up to 1 decimal place only.',
                    confirmButtonText: 'OK',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    } 
                });

                isAlertShown_BudgetAmount = true;
            }

        } else {
            // simpan nilai valid
            lastValidValue_BudgetAmount = currentValue;
            isAlertShown_BudgetAmount = false;
        }

    });
    //END OF





 


 });
