﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web_Portal.Models
{
    public class HtmlReportModel
    {
        public class DailyReportModel
        {
            public string TargetHariSelamat { get; set; }
            public string HariSelamatSeksi { get; set; }
            public string HariSelamatDept { get; set; }
            public string HariSelamatITS { get; set; }
            public string SampaiDengan { get; set; }

            public string UHBKK { get; set; }
            public string KYT { get; set; }
            public string MSP { get; set; }
            public string SK { get; set; }
            public string NC { get; set; }
            public List<abc> ListABC { get; set; }
            public List<stockchip> ListStockchip { get; set; }


        }

        public class abc
        {
            public string A { get; set; }
            public string B { get; set; }
            public string C { get; set; }
            public string D { get; set; }
            public string DLDS { get; set; }
            public string HJP { get; set; }

        }

        public class stockchip
        {
            public string Silo { get; set; }
            public string Berat { get; set; }
            public string Sounding { get; set; }
            public string TypeProd { get; set; }
            public string Kg { get; set; }
            public string Bag { get; set; }
            public string Bunker { get; set; }
            public string BeratBunker { get; set; }
            public string TypeProdBunker { get; set; }
        }


    }
}