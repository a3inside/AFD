﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

 
namespace Web_Portal.Models
{
    public class AFDCreateModel
    {

        // 1. General Info
        public string CoverLetterID { get; set; }
        public string FiscalYear { get; set; }
        public DateTime? DateOfProposal { get; set; }
        public DateTime? DateOfDecision { get; set; }
        public string DecisionNumber { get; set; }
        public string Title { get; set; }
        public string AFDType { get; set; }
        public string AFDSubType { get; set; }
        public decimal MinAmount { get; set; }
        public decimal MaxAmount { get; set; }
        public int FormAFDID { get; set; }
        public string CostSection { get; set; }
        public string NIKLogin { get; set; }
        public decimal AmountBudget { get; set; } 
        public int AmountBudgetID { get; set; }
        public decimal Rate { get; set; }
        public string Place { get; set; }
        public DateTime? PeriodeCommencement { get; set; }
        public DateTime? PeriodeCompletion { get; set; }
        public string PurposeFor { get; set; }
        public string DisposalResponsible { get; set; }
        public string BudgetType { get; set; }
        


        // 2. Long Text Fields
        public string PurposeDescription { get; set; }
        public string RequisiteSpecification { get; set; }
        public string ExpectedEffect { get; set; }

        // 3. Coordinator
        public string CoordinatorName { get; set; }
        public string CoordinatorSection { get; set; }

        // 4. Decision (Radio)
        public string DecisionStatus { get; set; }  // Approved / Hold / Disapproved

        // 5. Payments (nested model)
        public PaymentModel Payment { get; set; }

        // 6. File uploads (base64)
        public string FileContentOverview { get; set; }
        public string FileNameContentOverview { get; set; }

        public string FileSchedule { get; set; }
        public string FileNameSchedule { get; set; }

        public string FileBiddingDocument { get; set; }
        public string FileNameBiddingDocument { get; set; }


        // 7. Flag

        public string  Flag_Reapplication { get; set; }
        public string  Flag_Close_Approval { get; set; }
        public string  Flag_Draft { get; set; }

    }



    public class PaymentQuarterModel
    {
        public decimal Q1 { get; set; }
        public decimal Q2 { get; set; }
        public decimal Q3 { get; set; }
        public decimal Q4 { get; set; }
    }


    public class PaymentCategoryModel
    {
        public PaymentQuarterModel FY1 { get; set; }
        public PaymentQuarterModel FY2 { get; set; }
        public PaymentQuarterModel FY3 { get; set; }
        public decimal Total { get; set; }
    }


    public class PaymentModel
    {
        public PaymentCategoryModel CAPEX { get; set; }
        public PaymentCategoryModel EXPENSE { get; set; }
        public PaymentCategoryModel TOTAL { get; set; }
    }



    public class PaymentViewModel
    {
        public string FiscalYear { get; set; }
        public string Quarter { get; set; }
        public decimal CapitalExpense { get; set; }
        public decimal Expense { get; set; }
    }







    public class PrintCoverLetter
    {
 
        public string DecisionLevel_BOD { get; set; } 
        public string DecisionLevel_PD { get; set; }
        public string DecisionLevel_GM { get; set; }


        public string budgettype_inbudget { get; set; } 
        public string budgettype_additional { get; set; }

        public string AFD_Type_Disposal { get; set; }
        public string AFD_Type_Investment { get; set; }

        public string Show_Disposal { get; set; }
        public string Type_Form { get; set; } 
         

        public decimal Total_CAP_EXP { get; set; }
        public decimal Capital_Expense_Amount  { get; set; }
        public decimal Expense_Amount  { get; set; }


        public string RemarkAmountBudget { get; set; }
        public decimal AmountBudgetMaster { get; set; } 
        public string FiscalYear { get; set; }

        public string DateOfProposal { get; set; }
        public string DateOfDecision { get; set; }
        public string DecisionNumber { get; set; }

        public string Title { get; set; }
        public string AFDType { get; set; }
        public string AFDSubType { get; set; }  
        public string CostSection { get; set; }  
        public string Rate { get; set; }
        public string Place { get; set; }

        public string PeriodeCommencement { get; set; }
        public string PeriodeCompletion { get; set; }
         
        public string PurposeFor { get; set; }
        public string PurposeDescription { get; set; }
        public string RequisiteSpecification { get; set; }
        public string ExpectedEffect { get; set; }

        public string CoordinatorName { get; set; }
        public string CoordinatorSection { get; set; }
 
      
        public PaymentModel Payment { get; set; }

        public string DisposalResponsible_Sales { get; set; }
        public string DisposalResponsible_Purch { get; set; }
        public string DisposalResponsible_SE { get; set; }


    }

    public class PrintSignature
    {

        public int Approval_Step { get; set;}
        public string Sign_Name { get; set; }
        public string Sign_Image { get; set; } 
        public string Sign_Date { get; set; }
    }


}