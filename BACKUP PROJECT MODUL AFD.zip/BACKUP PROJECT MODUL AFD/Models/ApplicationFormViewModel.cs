﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Web_Portal.Models
{
    public class ApplicationFormViewModel
    {
        [Required]
        public string NIK { get; set; }

        public string txtName { get; set; }
        public string txtTittleName { get; set; }
        public string txtGradeName { get; set; }

        [Required(ErrorMessage = "Please select a document type.")]
        public int Form_ID { get; set; } // Changed to int

        public HttpPostedFileBase DocumentFile { get; set; }

        public string TittleCode { get; set; }
        public string DeptCode { get; set; }
        public string SectionCode { get; set; }

        // Slot fields for "Surat Keterangan Tidak Slot / TC"
        public string SlotType { get; set; } // TSI or TSO
        public DateTime? SlotDate { get; set; }
        public TimeSpan? SlotTime { get; set; }
        public string SlotReason { get; set; }
    }

    public class ApplicationProgressViewModel
    {
        public int Transaction_ID { get; set; }
        public string NIK { get; set; }

        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }

        [Display(Name = "Section")]
        public string SectionName { get; set; }

        [Display(Name = "Department")]
        public string DepartmentName { get; set; }

        [Display(Name = "Input Date")]
        public DateTime Input_Date { get; set; }

        [Display(Name = "Form Name")]
        public string Form_Name { get; set; }

        [Display(Name = "Uploaded File")]
        public string Form_Path { get; set; }

        [Display(Name = "Status")]
        public string Record_Status { get; set; }

        [Display(Name = "Approver")]
        public string ApproverName { get; set; }

        [Display(Name = "Approval Date")]
        public DateTime? Confirmation_Date { get; set; }

        [Display(Name = "Reason / Remark")]
        public string Confirm_Reason { get; set; }
    }
}