﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web_Portal.Models
{
    public class MasterModel
    {
        public class HomeModel
        {
            public List<HariSelamat> selamat { get; set; }
            public List<HariSelamat> hariSelamatDept { get; set; }
            public Instruksi instruksi { get; set; }
            public List<ListInstruksiSeksi> listInstruksi { get; set; }

            public List<Instruksi> listInstruksiBucho { get; set; }


            public Informasi informasi { get; set; }
            public HariSelamat hariSelamatITS { get; set; }
            //public List<T_Log_Activity> listLogActivity { get; set; }

            public ModelLogActivityCRUD listLogActivity { get; set; }
            public List<T_News> listNews { get; set; }
        }

        public class NewsModel
        {
            public List<T_News> listNews { get; set; }

            public List<M_Hari_Selamat_Dept> StartDayHariSelamatDept { get; set; }
        }

        public IEnumerable<SelectListItem> Months
        {
            get
            {
                return DateTimeFormatInfo
                       .InvariantInfo
                       .MonthNames
                       .Select((monthName, index) => new SelectListItem
                       {
                           Value = (index + 1).ToString(),
                           Text = monthName
                       });
            }
        }

        public class VanningView
        {
            public List<ModelVanning> ListModelVanning { get; set; }
            public string NoInvoice { get; set; }
            public string TypeChip { get; set; }
            public string Year { get; set; }
            public string Month { get; set; }

        }

        public class AttendanceView
        {
            public List<ModelAttendance> ListModelAttendance { get; set; }
            public string DeptName { get; set; }
            public string Employee { get; set; }
            public string Year { get; set; }
            public string Month { get; set; }

        }

        public class AssessmentHeaderView
        {
            public List<ModelAssessmentHeader> ListModelAssessmentHeader { get; set; }
            public string SectionName { get; set; }
            public string Flag { get; set; }

        }

        public class AksesAssessmentView
        {
            public List<ModelAksesAssessment> ListModelAkses { get; set; }
            public string DeptName { get; set; }

        }

        public class SummaryGrdView
        {
            public List<ModelSummaryGrd> ListModelSummary { get; set; }
            public string SectionName { get; set; }

        }

        public class ModelSummaryGrd
        {
            public string SectionName { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
            public string GradeCode { get; set; }
            public int? January { get; set; }
            public int? February { get; set; }
            public int? March { get; set; }
            public int? April { get; set; }
            public int? May { get; set; }
            public int? June { get; set; }
            public int? July { get; set; }
            public int? August { get; set; }
            public int? September { get; set; }
            public int? October { get; set; }
            public int? November { get; set; }
            public int? December { get; set; }
        }

        public class AssessmentDetailView
        {
            public List<ModelAssessmentDetail> ListModelAssessmentDetail { get; set; }
            public string NIK { get; set; }
            public string Year { get; set; }

        }

        public class AssessmentValueView
        {
            public List<ModelAssessmentValue> ListModelAssessmentValue { get; set; }
            public string NIK { get; set; }
            public int? Kondite { get; set; }

        }

        public class ModelAssessmentValue
        {
            public int? ID_Assessment_Detail { get; set; }
            public int? ID_Assessment_Header { get; set; }
            public int? ID_Assessment { get; set; }
            public string Assessment_Name { get; set; }
            public int value { get; set; }
        }

        public class AssessmentApproveView
        {
            public List<ModelApprove> ListModelApprove { get; set; }
            public string SectionName { get; set; }
            public string Flag { get; set; }
        }
        public class ModelApprove
        {
            public string SectionName { get; set; }
            public string User_Approve { get; set; }
            public string Date_Approve { get; set; }
            public string Status { get; set; }
            public string User_Request { get; set; }
            public string Time_Request { get; set; }
        }

        public partial class Data_Export
        {
            public string Tahun { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
            public string SectionCode { get; set; }
            public string SectionName { get; set; }
            public string GradeCode { get; set; }
            public int? January { get; set; }
            public int? February { get; set; }
            public int? March { get; set; }
            public int? April { get; set; }
            public int? May { get; set; }
            public int? June { get; set; }
            public int? July { get; set; }
            public int? August { get; set; }
            public int? September { get; set; }
            public int? October { get; set; }
            public int? November { get; set; }
            public int? December { get; set; }
            public int? AVG_Kondite { get; set; }
        }
        public class ModelTypeChip
        {
            public string Chip_code { get; set; }

        }

        public class ModelVanning
        {
            public string Type { get; set; }
            public string ContainerNo { get; set; }
            public string TraceNo { get; set; }
            public int Weight { get; set; }
            public string Silo { get; set; }
            public DateTime ChargingDate { get; set; }
            public string InvoiceNo { get; set; }
            public decimal SP { get; set; }
            public double TiO2 { get; set; }
            public double? COLORa { get; set; }
            public double WeightChip { get; set; }
            public decimal? DEG { get; set; }
            public double? ColorL { get; set; }
            public decimal IV { get; set; }
            public double COOH { get; set; }
            public double TM { get; set; }
            public decimal? ColorB { get; set; }
            public decimal? FM { get; set; }
            public decimal? Haze { get; set; }

        }

        public class ModelAttendance
        {
            public string NIK { get; set; }
            public string Name { get; set; }
            public string DeptName { get; set; }
            public string TittleName { get; set; }
            public string Day { get; set; }
            public DateTime Date { get; set; }
            public string Time_In { get; set; }
            public string Time_Out { get; set; }
            public string Reamark { get; set; }
            public string CreateIP { get; set; }
            public string UpdateIP { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string UpdateDateTime { get; set; }
        }

        public class ModelAssessmentHeader
        {
            public string SectionName { get; set; }
            public string Flag { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
            public string GradeCode { get; set; }
            public int? January { get; set; }
            public int? February { get; set; }
            public int? March { get; set; }
            public int? April { get; set; }
            public int? May { get; set; }
            public int? June { get; set; }
            public int? July { get; set; }
            public int? August { get; set; }
            public int? September { get; set; }
            public int? October { get; set; }
            public int? November { get; set; }
            public int? December { get; set; }
        }

        public class ModelAksesAssessment
        {
            public string DeptName { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
            public string SectionCode { get; set; }
            public string SectionName { get; set; }
            public Boolean IsActive { get; set; }
        }

        public class ModelAssessmentDetail
        {
            public string NIK { get; set; }
            public string Name { get; set; }
            public string DeptName { get; set; }
            public string SectionName { get; set; }
            public string Gol { get; set; }
            public string Periode { get; set; }
            public string Bulan { get; set; }
            public string Tanggal { get; set; }
            public int? Kondite { get; set; }
            public double? Prosentase_Absensi { get; set; }
            public string Penilai { get; set; }
            public int? Tanggung_jawab { get; set; }
            public int? Kerja_sama { get; set; }
            public int? Disiplin { get; set; }
            public int? Hasil { get; set; }
            public int? Aktif { get; set; }
            public int? Pengetahuan { get; set; }
            public int? Pengambilan_Keputusan { get; set; }
            public int? Kekuatan_Negosiasi { get; set; }
            public int? Keterampilan_Kepemimpinan { get; set; }
        }

        public class ModelDeptname
        {
            public string DeptName { get; set; }
        }


        public class HariSelamat
        {
            public int ID { get; set; }
            public int IDDept { get; set; }
            public string NamaDept { get; set; }
            public int IDSeksi { get; set; }
            public string Seksi { get; set; }
            public DateTime StartDay { get; set; }
            public int Total { get; set; }
            public string Remark { get; set; }

        }

        public class ModelLogActivityCRUD
        {
            public int ID_User { get; set; }
            public int ID_Seksi { get; set; }
            public string Log_Activity { get; set; }
            public string Log_Date { get; set; }

        }

        //public class dataAttendance
        //{
        //    public int ID_Attendance { get; set; }
        //    public string NIK { get; set; }
        //    public string DeptCode { get; set; }
        //    public string SectionCode { get; set; }
        //    public string TittleCode { get; set; }
        //    public DateTime Date { get; set; }
        //    public Nullable<DateTime> Time_In { get; set; }
        //    public Nullable<DateTime> Time_Out { get; set; }
        //    public int ID_Reason { get; set; }
        //    public string Remark { get; set; }
        //    public string Record_Status { get; set; }
        //}

        public class DDLHariSelamat
        {

            public int ID { get; set; }
            public int IDDept { get; set; }
            public int IDSeksi { get; set; }
            public string Seksi { get; set; }

        }

        public class ListInstruksiSeksi
        {
            public string SeksiHariSelamat { get; set; }
            public string Seksi { get; set; }
            public List<Instruksi> ListInstruksi { get; set; }
        }

        public class Instruksi
        {

            public DateTime Daily { get; set; }
            public string Message { get; set; }
            public string DateIntruksi { get; set; }

        }

        public class Informasi
        {
            public string Photo { get; set; }
            public string Post { get; set; }

        }

        public class ModelLog
        {

            public Nullable<int> ID_User { get; set; }
            public Nullable<int> ID_Seksi { get; set; }
            public string Log_Activity { get; set; }
            public Nullable<System.DateTime> Log_Date { get; set; }
        }

        public class ModelInstruksiList
        {
            public T_Instruksi_Komunikasi InstruksiHeader { get; set; }
            public List<InstruksiDetail> ListInstruksiDetail { get; set; }

        }


        public class InstruksiDetail
        {
            public T_Instruksi_Komunikasi_Detail instruksiDetail { get; set; }
            public string user_name { get; set; }
        }

        public class ModelGrafik
        {
            public string Type { get; set; }
            public DateTime ChargingDate { get; set; }
            public string InvoiceNo { get; set; }
            public decimal Compare1 { get; set; }
            public decimal Compare2 { get; set; }
            public decimal Min { get; set; }
            public decimal Max { get; set; }

        }

        public class ModelViewGrafikVanning
        {
            public string Type { get; set; }
            public string ChargingDate { get; set; }
            public string X { get; set; }
            public decimal Y { get; set; }
            public decimal Y2 { get; set; }
            public decimal minValue { get; set; }
            public decimal maxValue { get; set; }
        }

        public class ModelViewGrafikVanningAll
        {
            public string grafikName { get; set; }
            public string grafikID { get; set; }
            public List<ModelViewGrafikVanning> grafikData { get; set; }

        }


        //modul overtime
        public class OvertimeView
        {

            public List<ModelOvertime> ListModelOvertime { get; set; }
            public List<ModelOvertime> ListSectionOvertime { get; set; }

            public int CountRecord { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
            public string DeptName { get; set; }

            public string SectionName { get; set; }
            public string TittleName { get; set; }
            public string GradeName { get; set; }
            public int TittleCode { get; set; }

            public string CreateDateTime { get; set; }
            public string CreateNIK { get; set; }
            public string OvertimeDate { get; set; }
            public string BreakTime { get; set; }
            public string OvertimeIn { get; set; }
            public string OvertimeOut { get; set; }

            public string DescJob { get; set; }
            public string Status { get; set; }
            public string Reason_Confirm { get; set; }

            public string Revisi_OvertimeIn { get; set; }
            public string Revisi_OvertimeOut { get; set; }
            public string Name_day { get; set; }



            public List<ModelOvertime> ListEmployeebySection { get; set; }

            public List<ModelOvertime> ListProgressOvertime { get; set; }
        }

        public class ModelControlMonth
        {
            public int ID_Control_Month { get; set; }
            public DateTime Start_Date { get; set; }
            public DateTime End_Date { get; set; }

            public DateTime Input_End_OT { get; set; }
            public Boolean isActive { get; set; }
            public string STATUS { get; set; }
            public string BUTTON { get; set; }

        }

        public class ModelOvertime
        {
            public string DeptName { get; set; }
            public string SectionName { get; set; }
            public string Name { get; set; }


            public int Overtime_ID { get; set; }
            public string NIK { get; set; }
            public string DeptCode { get; set; }

            public string SectionCode { get; set; }

            public string TittleCode { get; set; }
            public DateTime Overtime_Date { get; set; }
            public DateTime Overtime_In { get; set; }
            public DateTime Overtime_Out { get; set; }
            public int Break_Time { get; set; }
            public string Description_Job { get; set; }
            public string Confirmation_Date { get; set; }
            public string Confirm_Reason { get; set; }
            public string Record_Status { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateUserName { get; set; }
            public string CreateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserName { get; set; }
            public string UpdateIP { get; set; }

            public Boolean Flag_Export { get; set; }

            public string Name_Day { get; set; }
            public double Total_Hour { get; set; }
        }
 

        public class ModelEmployee
        {
            public string NIK { get; set; }
            public string Name { get; set; }
            public string DeptName { get; set; }
            public string DeptCode { get; set; }
            public string TittleName { get; set; }
            public string TittleCode { get; set; }
            public string SectionName { get; set; }
            public string SectionCode { get; set; }
            public string GradeCode { get; set; }
            public string GradeName { get; set; }
            public string ClassCode { get; set; }
            public string ClassName { get; set; }
            public string TypeCode { get; set; }
            public string TypeName { get; set; }
            public int CountMgr { get; set; }
        }

        public class ModelAksesMenuOvertime
        {
            public string DeptName { get; set; }
            public string SectionName { get; set; }
            public string GradeName { get; set; }
            public string TittleName { get; set; }
            public string Name { get; set; }

            public int ID_Akses_Overtime { get; set; }
            public string NIK { get; set; }
            public Boolean Create_OT { get; set; }
            public Boolean List_Progress_OT { get; set; }
            public Boolean Confirm_OT { get; set; }
            public Boolean Export_OT { get; set; }
            public Boolean Change_Period { get; set; }
            public Boolean Akses_User { get; set; }

            public Boolean Employee_Temp { get; set; }

        }

        //end of


        //MODUL TROUBLE & SOP [2022-05-23]
        public class ModelTroubleViewDetail
        {
            public int IDTroubleHeader { get; set; }
            public int IDTroubleDetail { get; set; }
            public string ProcessName { get; set; }
            public string CategoryName { get; set; }
            public string CreateUserID { get; set; }
            public string CreateIP { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateName { get; set; }
            public string UpdateName { get; set; }
            public string UpdateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string DocDirectory { get; set; }
            public string DocName { get; set; }
            public string DocExt { get; set; }
        }
        public class TroubleView
        {

            public List<ModelTroubleViewDetail> ListModelTroubleViewDetail { get; set; }


            public int IDDept { get; set; }
            public string DeptName { get; set; }
            public int IDSection { get; set; }
            public string SectionName { get; set; }
            public int IDTroubleHeader { get; set; }
            public DateTime TroubleDate { get; set; }
            public string TroubleDesc { get; set; }
            public int IDProcess { get; set; }
            public string ProcessName { get; set; }
            public int IDCategory { get; set; }
            public string CategoryName { get; set; }



            public string Location { get; set; }
            public string Machine_Name { get; set; }
            public string Product_Type { get; set; }
            public string Situation_Condition { get; set; }
            public string Damage_Influence { get; set; }
            public string Now_Action { get; set; }
            public string Permanent_Action { get; set; }


            public string CreateName { get; set; }
            public string CreateIP { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string UpdateName { get; set; }
            public string UpdateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
        }
        public class ModelTroubleList
        {
            public T_Trouble TroubleHeader { get; set; }
            public List<TroubleListDetail> ListTroubleDetail { get; set; }
        }
        public class TroubleListDetail
        {
            public T_Trouble_Detail TroubleDetail { get; set; }
            public string user_name { get; set; }
        }
        public class ViewTrouble
        {
            public string Dept_Name { get; set; }
            public string Seksi_Name { get; set; }
            public string Trouble_Year { get; set; }
            public string Trouble_Date { get; set; }
            public string Process_Name { get; set; }
            public string Category_Name { get; set; }
            public string Trouble_Desc { get; set; }
            public int ID_Trouble { get; set; }
            public int ID_Process { get; set; }
            public int ID_Category { get; set; }

            public string Location { get; set; }
            public string Machine_Name { get; set; }
            public string Product_Type { get; set; }
            public string Situation_Condition { get; set; }
            public string Damage_Influence { get; set; }
            public string Now_Action { get; set; }
            public string Permanent_Action { get; set; }

            public string Author { get; set; }
            public string Last_Updated { get; set; }

        }
        public class ViewTroubleDetail
        {
            public int ID_Trouble_Detail { get; set; }
            public int ID_Trouble_Header { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateUserId { get; set; }
            public string CreateIP { get; set; }
            public string CreateUserName { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserId { get; set; }
            public string UpdateIP { get; set; }
            public string Directory_Doc { get; set; }
            public string Name_Doc { get; set; }
            public string Ext_Doc { get; set; }
        }


        public class ModelSOPViewDetail
        {
            public int IDSOPHeader { get; set; }
            public int IDSOPDetail { get; set; }
            public string ProcessName { get; set; }
            public string CategoryName { get; set; }
            public string CreateUserID { get; set; }
            public string CreateIP { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateName { get; set; }
            public string UpdateName { get; set; }
            public string UpdateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string DocDirectory { get; set; }
            public string DocName { get; set; }
            public string DocExt { get; set; }
        }
        public class SOPView
        {
            public List<ModelSOPViewDetail> ListModelSOPViewDetail { get; set; }

            public int IDDept { get; set; }
            public string DeptName { get; set; }
            public int IDSection { get; set; }
            public string SectionName { get; set; }
            public int IDSOPHeader { get; set; }
            public DateTime SOPDate { get; set; }
            public string SOPDesc { get; set; }
            public int IDProcess { get; set; }
            public string ProcessName { get; set; }
            public int IDCategory { get; set; }
            public string CategoryName { get; set; }



            public string Location { get; set; }
            public string Machine_Name { get; set; }
            public string Product_Type { get; set; }
            public string Situation_Condition { get; set; }
            public string Damage_Influence { get; set; }
            public string Now_Action { get; set; }
            public string Permanent_Action { get; set; }


            public string CreateName { get; set; }
            public string CreateIP { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string UpdateName { get; set; }
            public string UpdateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
        }
        public class ModelSOPList
        {
            public T_SOP SOPHeader { get; set; }
            public List<SOPListDetail> ListSOPDetail { get; set; }
        }
        public class SOPListDetail
        {
            public T_SOP_Detail SOPDetail { get; set; }
            public string user_name { get; set; }
        }
        public class ViewSOP
        {
            public string Dept_Name { get; set; }
            public string Seksi_Name { get; set; }
            public string SOP_Year { get; set; }
            public string SOP_Date { get; set; }
            public string Process_Name { get; set; }
            public string Category_Name { get; set; }
            public string SOP_Desc { get; set; }
            public int ID_SOP { get; set; }
            public int ID_Process { get; set; }
            public int ID_Category { get; set; }

            public string Author { get; set; }
            public string Last_Updated { get; set; }

        }
        public class ViewSOPDetail
        {
            public int ID_SOP_Detail { get; set; }
            public int ID_SOP_Header { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateUserId { get; set; }
            public string CreateIP { get; set; }
            public string CreateUserName { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserId { get; set; }
            public string UpdateIP { get; set; }
            public string Directory_Doc { get; set; }
            public string Name_Doc { get; set; }
            public string Ext_Doc { get; set; }
        }



        public class ModelProcess
        {
            public int IdDept { get; set; }
            public string DeptName { get; set; }
            public int IdSeksi { get; set; }
            public string SeksiName { get; set; }
            public int IdProcess { get; set; }
            public string ProcessName { get; set; }

        }

        public class ModelKategori
        {
            public int ID_Category { get; set; }
            public string Category_Type { get; set; }
            public string Category_Name { get; set; }

        }
        public class ModelProductType
        {
            public string Short_Code { get; set; }
            public string TYPEI { get; set; }
            public string TYPEII { get; set; }
            public string Group_Short_Code { get; set; }
        }

        public class ModelGenerateButtonViewChangeDept
        {
            public string DEPT_NAME { get; set; }
            public string DEPT { get; set; }
            public string IP_ADDRESS { get; set; }
            public int ID_USER { get; set; }
            public int ID_USER_LOGIN { get; set; }
        }


        //END OF





        //TMI 2022-12-29

        public class ModelFlashDetailViewTMI
        {
            public int IDFlashDetail { get; set; }
            public int IDFlash { get; set; }
            public string DirectoryDoc { get; set; }

            public DateTime CreateDateTime { get; set; }
            public string CreateUserID { get; set; }
            public string CreateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserId { get; set; }
            public string UpdateIP { get; set; }

            public string Name_Doc { get; set; }
            public string Ext_Doc { get; set; }

        }

        public class ModelProcessTMI
        {

            public int Id_Process { get; set; }
            public string Dept_Code { get; set; }
            public string Process_Name { get; set; }

        }
        public class ModelSubProcessTMI
        {

            public int Id_Sub_Process { get; set; }
            public int Id_Process { get; set; }
            public string Sub_Process_Name { get; set; }
            public string Dept_Code { get; set; }

        }
        public class ModelDepartmentTMI
        {

            public string Dept_Code { get; set; }
            public string Dept_Name { get; set; }

        }
        public class ModelSectionTMI
        {

            public string Section_Code { get; set; }
            public string Section_Name { get; set; }

        }
        public class ModelMachineTMI
        {

            public int ID_Machine { get; set; }
            public string Dept_Code { get; set; }
            public int ID_Process { get; set; }
            public string Machine_Name { get; set; }

        }

        public class M_User_Access_TMI
        {

            public int IDUser { get; set; }
            public string RoleCode { get; set; }

        }

        public class ViewFlash
        {
            public int ID_Flash { get; set; }
            public int ID_Trouble { get; set; }

            public string Trouble_Title { get; set; }
            public string Trouble_Date { get; set; }
            public string TimeStopDate { get; set; }
            public string TimeStopTime { get; set; }
            public string TimeStartRepairDate { get; set; }
            public string TimeStartRepairTime { get; set; }
            public string TimeEndRepairDate { get; set; }
            public string TimeEndRepairTime { get; set; }
            public string TimeStartProdDate { get; set; }
            public string TimeStartProdTime { get; set; }
            public string TimeStartOpsDate { get; set; }
            public string TimeStartOpsTime { get; set; }
            public int TotalStop { get; set; }

            public string CreatedDate { get; set; }
            public string Trouble_Day { get; set; }
            public string Trouble_Place { get; set; }
            public string Dept_Code { get; set; }
            public string Dept_Name { get; set; }
            public string Section_Code { get; set; }
            public string Section_Name { get; set; }
            public string Trouble_Year { get; set; }
            public string Category_Name { get; set; }
            public int ID_Process { get; set; }
            public string Process_Name { get; set; }
            public int ID_Sub_Process { get; set; }
            public string Sub_Process_Name { get; set; }
            public int ID_Machine { get; set; }
            public string Machine_Name { get; set; }
            public string Trouble_Description { get; set; }
            public string Solve_Description { get; set; }
        }


        public class ModelAksesMenuTMI
        {
            public int ID_Access { get; set; }
            public int ID_User { get; set; }
            public string Dept_Code { get; set; }
            public string Section_Code { get; set; }
            public string Role_Code { get; set; }
            public string Dept_Name { get; set; }
            public string Section_Name { get; set; }
            public string Role_Name { get; set; }
            public string Role_Remark { get; set; }
            public string NIK { get; set; }

            public Nullable<int> TroubleOutstanding { get; set; }
        }

        public class TMIMasterModel
        {
            public string Dept_Code { get; set; }
            public string Dept_Name { get; set; }
            public string Section_Code { get; set; }
            public string Section_Name { get; set; }


            public int ID_Machine { get; set; }
            public int ID_Process { get; set; }
            public string Process_Name { get; set; }
            public string Machine_Name { get; set; }
            public int ID_Sub_Process { get; set; }
            public string Sub_Process_Name { get; set; }
            public string Role_Code { get; set; }
            public string Role_Name { get; set; }
            public string Role_Remark { get; set; }



            //*******modify by 1914 2023-02-18
            public int ID_Net_Running { get; set; }
            public string Periode { get; set; }
            public Nullable<int> AVG_Op_Units { get; set; }
            public Nullable<int> AVG_Op_Time { get; set; }
            public Nullable<int> Op_DM { get; set; }
            public Nullable<int> Tot_Op_Time { get; set; }


            public int ID_Downtime_Ratio { get; set; }
            public Nullable<double> Target { get; set; }
            public string PeriodeAwal { get; set; }
            public string PeriodeAkhir { get; set; }


            public int ID_Control_Month { get; set; }
            public Nullable<int> Active { get; set; }

            //*******end of
        }


        public class FlashViewTMI
        {
            public List<ModelFlashDetailViewTMI> ListModelFlashDetailViewTMI { get; set; }

            public int IDFlash { get; set; }
            public int IDFlashA2 { get; set; }
            public string CodeFlash { get; set; }
            public string xForm { get; set; }
            public string xFormA2 { get; set; }
            public DateTime TroubleDate { get; set; }
            public DateTime TroubleDateA2 { get; set; }
            public string TroubleTitle { get; set; }
            public string TroubleTitleA2 { get; set; }

            public string RoleCode { get; set; }
            public string Dept_Code { get; set; }
            public string Section_Code { get; set; }
            public string Trouble_Day { get; set; }
            public DateTime TimeStop { get; set; }
            public DateTime TimeStopA2 { get; set; }
            public DateTime TimeStartRepair { get; set; }
            public DateTime TimeStartRepairA2 { get; set; }
            public DateTime TimeEndRepair { get; set; }
            public DateTime TimeEndRepairA2 { get; set; }
            public DateTime TimeStartOps { get; set; }
            public DateTime TimeStartOpsA2 { get; set; }
            public DateTime TimeStartProd { get; set; }
            public DateTime TimeStartProdA2 { get; set; }
            public int TotalStop { get; set; }
            public int TMIAge { get; set; }
            public int TotalStopMinutes { get; set; }
            public string xTotalStop { get; set; }
            public int TotalStopA2 { get; set; }

            public string Trouble_Place { get; set; }
            public int ID_Process { get; set; }
            public int ID_Sub_Process { get; set; }
            public int ID_Machine { get; set; }
            public string Posisi { get; set; }
            public string PosisiA2 { get; set; }
            public int intPosisi { get; set; }
            public string CreateUserId { get; set; }
            public DateTime CreatedDate { get; set; }

            public string HakAksesEdit { get; set; }
        }



        //end of



        //******************//modify by 1914 2023-02-17
        public class ModelControlMonthTMI
        {
            public int ID_Control_Month { get; set; }
            public string Periode { get; set; }
            public int Active { get; set; }

        }

        public class ModelDowntimeRatioView
        {
            public int ID_Downtime_Ratio { get; set; }
            public string Process_Name { get; set; }
            public string Dept_Code { get; set; }
            public string PeriodeAwal { get; set; }
            public string PeriodeAkhir { get; set; }
            public Nullable<double> AVG { get; set; }
            public Nullable<double> Target { get; set; }
            public Nullable<double> APR { get; set; }
            public Nullable<double> MEI { get; set; }
            public Nullable<double> JUN { get; set; }
            public Nullable<double> JUL { get; set; }
            public Nullable<double> AUG { get; set; }
            public Nullable<double> SEPT { get; set; }
            public Nullable<double> OCT { get; set; }
            public Nullable<double> NOV { get; set; }
            public Nullable<double> DEC { get; set; }
            public Nullable<double> JAN { get; set; }
            public Nullable<double> FEB { get; set; }
            public Nullable<double> MAR { get; set; }
            public string Resume { get; set; }

            public Nullable<double> Year1 { get; set; }
            public Nullable<double> Year2 { get; set; }
            public Nullable<double> Year3 { get; set; }
            public Nullable<double> Year4 { get; set; }
            public Nullable<double> Year5 { get; set; }
        }

        public class ModelListDataTrouble
        {
            public DateTime Trouble_Date { get; set; }
            public string Trouble_Title { get; set; }
            public string Dept_Name { get; set; }
            public string Section_Name { get; set; }
            public string Trouble_Day { get; set; }
            public string TimeStopDate { get; set; }
            public string TimeStopTime { get; set; }
            public string TimeStartOpsDate { get; set; }
            public string TimeStartOpsTime { get; set; }
            public string TimeStartRepairDate { get; set; }
            public string TimeStartRepairTime { get; set; }
            public string TimeEndRepairDate { get; set; }
            public string TimeEndRepairTime { get; set; }
            public string TimeStartProdDate { get; set; }
            public string TimeStartProdTime { get; set; }
            public string Trouble_Place { get; set; }
            public string Process_Name { get; set; }
            public string Sub_Process_Name { get; set; }
            public string Machine_Name { get; set; }
            public string Trouble_Description { get; set; }
            public string Solve_Description { get; set; }
            public string Cause_Analyze { get; set; }
            public string Permanent_Action { get; set; }

            public string Approve_Name_MS { get; set; }
            public DateTime Approve_Date_MS { get; set; }
            public string Approve_Name_MD { get; set; }
            public DateTime Approve_Date_MD { get; set; }


            public Nullable<double> WasteVol { get; set; }
            public Nullable<double> WasterCurr { get; set; }
            public Nullable<double> LostTimeHours { get; set; }
            public Nullable<double> LostTimeCurr { get; set; }
            public Nullable<double> TotalLostCost { get; set; }

        }

        public class ModelSignatureTrouble
        {
            public int Id_Flash { get; set; }
            public int Sequence_Step { get; set; }
            public string NIK { get; set; }
            public DateTime Approve_Date { get; set; }
            public string Approve_IP { get; set; }

        }

        public class ModelGetIdentityUserCreateA1
        {
            public int ID_User_A1 { get; set; }
            public string NIK_A1 { get; set; }
            public string Create_IP_A1 { get; set; }

        }

        //******************//end of



        //modify 2024-03-04
        public class ModelListDataCompanyRule
        {

            public string NoIndex { get; set; }
            public int ID_Company_Rule { get; set; }
            public int ID_Dept { get; set; }
            public int ID_Seksi { get; set; }
            public string Directory_File { get; set; }
            public string Directory_Image { get; set; }
            public string Rule_Name { get; set; }
            public string File_Name { get; set; }
            public string Description { get; set; }
            public string Type_Rule { get; set; }
            public string Access_Right { get; set; }
            public string Access_View { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateUserId { get; set; }
            public string CreateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserId { get; set; }
            public string UpdateIP { get; set; }


        }
        //end of


        // permission 
        public class ModelAksesPermission
        {
            public string DeptName { get; set; }
            public string SectionName { get; set; }
            public string GradeName { get; set; }
            public string TittleName { get; set; }
            public string Name { get; set; }

            public int ID { get; set; }
            public string NIK { get; set; }
            public Boolean Create_OT { get; set; }
            public Boolean List_Progress_OT { get; set; }
            public Boolean Confirm_OT { get; set; }
            public Boolean Export_OT { get; set; }
            public Boolean Change_Period { get; set; }
            public Boolean Akses_User { get; set; }

            public Boolean Employee_Temp { get; set; }

        }


        public class ModelConfirmationPermission
        {
            public T_Attendance_Permission Permission { get; set; }
            public string SectionName { get; set; }
            public string DeptName { get; set; }
            public string Name { get; set; }
        }


        public class ModelPermission
        {
            public string DeptName { get; set; }
            public string SectionName { get; set; }
            public string Name { get; set; }


            public int Permission_ID { get; set; }
            public string NIK { get; set; }
            public string DeptCode { get; set; }

            public string SectionCode { get; set; }

            public string TittleCode { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }

            public string ScheduleStartDate { get; set; }
            public string ScheduleEndDate { get; set; }

            public string ScheduleStartTime { get; set; }
            public string ScheduleEndTime { get; set; }

            public string ActStartDate { get; set; }
            public string ActEndDate { get; set; }

            public string ActStartTime { get; set; }
            public string ActEndTime { get; set; }

            public string Description { get; set; }
            public string Confirmation_Date { get; set; }
            public string Confirm_Reason { get; set; }
            public string Record_Status { get; set; }
            public DateTime CreateDateTime { get; set; }
            public string CreateUserName { get; set; }
            public string CreateIP { get; set; }
            public Nullable<DateTime> UpdateDateTime { get; set; }
            public string UpdateUserName { get; set; }
            public string UpdateIP { get; set; }

            public Boolean Flag_Export { get; set; }
        }

        //modul permission list


        public class PermissionView
        {
            public string DeptName { get; set; }
            public string SectionName { get; set; }

            public string SectionNameOri { get; set; } //untuk section name yg asli ada space nya.

            public List<ModelAttendancePermission> ListModelPermission { get; set; } // Ensure this matches the expected type

            // Additional properties if needed
            public int CountRecord { get; set; }
            public string NIK { get; set; }
            public string Name { get; set; }
        }


        public class ModelAttendancePermission
        {
            // Data from T_Attendance_Permission table
            public int Permission_ID { get; set; }
            public string NIK { get; set; }
            public string TransCode { get; set; }
            public string ReasonCode { get; set; }
            public string PermitCode { get; set; }
            public string Description { get; set; }
            public DateTime? Confirmation_Date { get; set; }
            public string Confirm_Reason { get; set; }
            public string PermitName { get; set; }
            public string Record_Status { get; set; }
            public DateTime? Start_Date { get; set; }
            public DateTime? End_Date { get; set; }
            public DateTime? SchDateIN { get; set; }
            public DateTime? SchDateOut { get; set; }
            public string SchTimeIN { get; set; }  // Changed from DateTime? to string
            public string SchTimeOUT { get; set; } // Changed from DateTime? to string
            public DateTime? ActDateIN { get; set; }
            public DateTime? ActDateOut { get; set; }
            public string ActTimeIN { get; set; } // Changed from DateTime? to string
            public string ActTimeOUT { get; set; } // Changed from DateTime? to string
            public DateTime CreateDateTime { get; set; }
            public string CreateUserName { get; set; }
            public string CreateIP { get; set; }
            public DateTime? UpdateDateTime { get; set; }
            public string UpdateUserName { get; set; }
            public string UpdateIP { get; set; }
            public string DeptCode { get; set; }
            public string SectionCode { get; set; }
            public string TitleCode { get; set; }

            // Data from M_Employee table
            public string SectionName { get; set; }
            public string DeptName { get; set; }
            public string Name { get; set; }
        }











        //PROJECT AFD
        //start develop 2025-10-21
        //finish develop 

        public class ModelAksesMenuAFD
        {
            public string NIK { get; set; }
            public string Sign_Title { get; set; }
            public int Flag_Create { get; set; }
            public int Flag_View { get; set; }
            public int Flag_Approve { get; set; }
            public int Flag_Return { get; set; }
            public int Flag_Use { get; set; }

            public int Flag_Master_Budget { get; set; }


        }


        public class ModelMasterBudgetFinal
        { 
            public int Budget_Final_ID { get; set; }
            public string Budget_Type { get; set; }
            public string Title { get; set; }
            public string Cost_Section { get; set; }
            public string Fiscal_Year { get; set; }
            public Nullable<double> Budget_Amount { get; set; }
            public Nullable<double> Proposal_Amount { get; set; }
            public int Flag_Unknown_Amount { get; set; }
            public string Unknown_Amount { get; set; }
            public string Status { get; set; }
            public string Remark { get; set; }

        }




        //END OF PROJECT AFD







    }
}