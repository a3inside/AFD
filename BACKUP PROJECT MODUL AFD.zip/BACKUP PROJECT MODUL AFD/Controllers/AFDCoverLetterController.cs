﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using System.IO;


namespace Web_Portal.Controllers
{ 

    public class AFDCoverLetterController : Controller
    {

        private WebPortalEntities db = new WebPortalEntities();
        private AFDEntities db_AFD = new AFDEntities();
        private Attendance_MGREntities db_Att = new Attendance_MGREntities();


        // GET: AFDCoverLetter
        public ActionResult Index(string mode, string CoverLetterId)
        { 
            db.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db.Configuration.ProxyCreationEnabled = false;

            db_Att.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db_Att.Configuration.ProxyCreationEnabled = false;

            db_AFD.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db_AFD.Configuration.ProxyCreationEnabled = false;
             
            string NIKlogin = Session["NIK"].ToString();    
            ViewBag.NIKLogin = NIKlogin;

            int id = Convert.ToInt32(CoverLetterId);

            var afd = db_AFD.T_AFD
            .Where(a => a.AFD_ID == id)
            .Select(a => a.Flag_Draft)
            .FirstOrDefault();

             
            if (afd == null)
            {
                ViewBag.StatusData = "new";
            }
            else if (afd == 1)
            {
                ViewBag.StatusData = "draft";
            }
            else
            {
                ViewBag.StatusData = "inprogress";
            }


            return View(); 
        }


        // /AFDCoverLetter/BudgetSheet?id=123
        public ActionResult BudgetSheet(int id)
        {
            // ID yang dikirim dari tombol masuk ke sini ✅
            ViewBag.BudgetId = id;

            // Jika kamu butuh data dari DB, query di sini:
            // var data = db.TableBudget.FirstOrDefault(x => x.Id == id);
            // return View(data);



            return View(); // atau return View(data);
        }


        public JsonResult GetAFDType()
        {
            var data = db_AFD.M_Form_AFD
         .Select(a => a.AFD_Type)
         .Distinct()
         .Select(x => new {
             Value = x,
             Text = x
         })
         .ToList(); 

            return Json(data, JsonRequestBehavior.AllowGet);
        }
         
        public JsonResult GetAmountRange(
       string decisionLevel,
       string afdType,
       string afdSubType,
       string category)
        {


            string NIKlogin = Session["NIK"].ToString();

            var data =
                    (from a in db_AFD.M_Form_AFD
                     join r in db_AFD.M_Rule_Approval
                     on a.Form_AFD_ID equals r.Form_AFD_ID
                     where a.AFD_Type == afdType
                     && a.Decision_By == decisionLevel
                     && a.Form_AFD_Category == category
                     && r.Approver_NIK == NIKlogin
                     && r.Approval_Step == 0
                     select new
                     {
                         a.Approval_Min_Amount,
                         a.Approval_Max_Amount,
                         a.View_Amount,
                         a.Form_AFD_ID
                     })
                    .FirstOrDefault();


            if (data == null)
            {
                return Json(new
                {
                    status = "error"
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
            return Json(new
            {
                status = "ok",
                minAmount = data.Approval_Min_Amount,
                maxAmount = data.Approval_Max_Amount,
                viewAmount = data.View_Amount,
                idAFDForm = data.Form_AFD_ID
            }, JsonRequestBehavior.AllowGet);

            }




        }

        public JsonResult GetRate(string FiscalYear, string CurrencyCode)
        {
            // Cek session user
            if (Session["NIK"] == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Session Expired",
                    solution = "Please login in fisrt"
                }, JsonRequestBehavior.AllowGet);
            }

            string NIKlogin = Session["NIK"].ToString();

            var data = db_AFD.M_Rate_AFD
                .Where(x => x.Fiscal_Year == FiscalYear && x.Currency_Code == CurrencyCode)
                .Select(x => x.Rate)
                .FirstOrDefault();

            if (data == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Rate is not available",
                    solution = "please check in table M_Rate_AFD"
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                Rate = data
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCostSection(string NIKLogin)
        {
            var result = db_AFD.M_Rule_Approval
                .Where(x => x.Approver_NIK == NIKLogin)
                .Select(x => x.Cost_Section)
                .Distinct()
                .ToList();

            if (!result.Any())
            {
                return Json(new
                {
                    status = "error",
                    message = "Cost Section is not available",
                    solution = "please check in table M_Rule_Approval",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                CostSection = result
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCoordinator(string NIKLogin)
        {
            var result = db_Att.M_Employee
                .Where(e => e.NIK == NIKLogin)
                .Select(e => new
                {
                    e.Name,
                    e.SectionName
                })
                .ToList();   // penting!

            if (!result.Any())
            {
                return Json(new
                {
                    status = "error",
                    message =  "Coordinator & Section is not available.",
                    solution =  "please check in table M_Employee",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                data = result
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMasterBudgetFinal(string CostSection, string FiscalYear, string AFDSubType, float MinAmount, float MaxAmount)
        {
             
            var data =
    (from a in db_AFD.M_Budget_Final
     join b in db_AFD.T_AFD
         on a.Budget_Final_ID equals b.Budget_Final_ID into temp
     from b in temp.DefaultIfEmpty()
     where a.Fiscal_Year == FiscalYear
        && a.Cost_Section == CostSection
         && a.Classification == AFDSubType
        && b == null
        && a.Budget_Amount >= MinAmount
        && a.Budget_Amount <= MaxAmount
     select a
    ).ToList();


            // Cek jika data kosong
            if (!data.Any())
            {
                return Json(new
                {
                    status = "error",
                    message = "Master Budget not found",
                    solution = "Please check or create a new data in Master",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                data = data
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CheckBudgetIDinTransaction(int BudgetFinalID)
        {
            // Ambil data T_AFD berdasarkan BudgetFinalID
            var data = db_AFD.T_AFD
                             .Where(x => x.Budget_Final_ID == BudgetFinalID)
                             .ToList();

            // Jika tidak ada data sama sekali
            if (data == null || data.Count == 0)
            {
                // Maka ambil data dari M_Budget_Final
                var dataMaster = db_AFD.M_Budget_Final
                                       .Where(x => x.Budget_Final_ID == BudgetFinalID)
                                       .ToList();
                 
                return Json(new
                {
                    status = "ok",
                    message = "Budget Final ID has not been used before in this system",
                    data = dataMaster
                }, JsonRequestBehavior.AllowGet);
                
            }
            else
            {
                // Jika ada data master di T_AFD, tidak boleh pilih master
                return Json(new
                {
                    status = "exists",
                    message = "This Budget Final ID is already used",
                    data = (object)null   // <== kirim seluruh object
                }, JsonRequestBehavior.AllowGet);

            }

        }



        public JsonResult GetCoverLetter(int CoverLetterId)
        {
            var data = (  
                from a in db_AFD.T_AFD
                join b in db_AFD.M_Budget_Final
                    on a.Budget_Final_ID equals b.Budget_Final_ID into temp
                from b in temp.DefaultIfEmpty() 
                join c in db_AFD.M_Form_AFD
                    on a.Form_AFD_ID equals c.Form_AFD_ID into temp2
                from c in temp2.DefaultIfEmpty() 
                where a.AFD_ID == CoverLetterId 
                select new
                        {
                        a.AFD_ID,
                        a.Form_AFD_ID,
                        a.Budget_Final_ID, 
                        c.AFD_Type,
                        a.AFD_SubType,
                        a.Proposal_Date,
                        a.AFD_Title, 
                        a.Capital_Expense_Amount,
                        a.Expense_Amount,
                        a.ExchangeRate_USD,
                        a.Place,
                        a.Period_Commencement,
                        a.Period_Completion,
                        a.Purpose_Description,
                        a.Specification_Requisite,
                        a.Expected_Effect,
                        a.Coordinator_Name,
                        a.Coordinator_Section,
                        a.Disposal_Responsible,
                        c.Decision_By,
                        a.Decision_Status,
                        a.Decision_Number,
                        a.Decision_Date,
                        a.Content_Overview,
                        a.Schedule,
                        a.Bidding_Document,
                        a.Flag_Reapplication,
                        a.Flag_Close_Approval,
                        a.Flag_Draft,
                        a.History_Return, 
              
                        // Data Budget Final
                        b.Classification,
                        b.Budget_Type,
                        b.Title,
                        b.Cost_Section,
                        b.Fiscal_Year,
                        b.Budget_Amount,
                        b.Remark_Budget_Amount,
                        b.Remark,
                        b.Purpose_Type,
                         
                        // Data Master Form 
                        c.Form_AFD_Category,
                         
                        //Path Document
                        Path_Content_Overview = "FY" + b.Fiscal_Year + "/" + c.AFD_Type + "/" + a.AFD_SubType + "/" + b.Cost_Section + "/" + a.Content_Overview, 
                        Path_Schedule = "FY" + b.Fiscal_Year + "/" + c.AFD_Type + "/" + a.AFD_SubType + "/" + b.Cost_Section + "/" + a.Schedule, 
                        Path_Bidding_Document = "FY" + b.Fiscal_Year + "/" + c.AFD_Type + "/" + a.AFD_SubType + "/" + b.Cost_Section + "/" + a.Bidding_Document
                     
                }).FirstOrDefault();



            if (data == null)
            {
                return Json(new
                {
                    status = "warning",
                    message = "No data available.",
                    solution = ""
                }, JsonRequestBehavior.AllowGet);
            }


            // Get config path di webconfig 
            string SourceViewDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceViewDocumentAFD"];


       
            
            var resultAFD = new
            {
                xAFD_ID = data.AFD_ID,
                xForm_AFD_ID = data.Form_AFD_ID,
                xBudget_Final_ID = data.Budget_Final_ID,
                xAFD_Type = data.AFD_Type,
                xAFD_SubType = data.AFD_SubType,
                xProposal_Date = data.Proposal_Date?.ToString("yyyy-MM-dd") ?? "",
                xAFD_Title = data.AFD_Title,
                xBudget_Amount = data.Budget_Amount,
                xCapital_Expense_Amount = data.Capital_Expense_Amount,
                xExpense_Amount = data.Expense_Amount,
                xExchangeRate_USD = data.ExchangeRate_USD,
                xPlace = data.Place,
                xPeriod_Commencement = data.Period_Commencement?.ToString("yyyy-MM-dd") ?? "",
                xPeriod_Completion = data.Period_Completion?.ToString("yyyy-MM-dd") ?? "",
                xPurpose_Description = data.Purpose_Description,
                xSpecification_Requisite = data.Specification_Requisite,
                xExpected_Effect = data.Expected_Effect,
                xCoordinator_Name = data.Coordinator_Name,
                xCoordinator_Section = data.Coordinator_Section,
                xDisposal_Responsible = data.Disposal_Responsible,
                xDecision_By = data.Decision_By,
                xDecision_Status = data.Decision_Status,
                xDecision_Number = data.Decision_Number,
                xDecision_Date = data.Decision_Date?.ToString("yyyy-MM-dd") ?? "",
                xContent_Overview = data.Content_Overview,
                xSchedule = data.Schedule,
                xBidding_Document = data.Bidding_Document,
                xFlag_Reapplication = data.Flag_Reapplication,
                xFlag_Close_Approval = data.Flag_Close_Approval,
                xFlag_Draft = data.Flag_Draft,
                xHistory_Return = data.History_Return,

                // Data Budget Final
                xClassification = data.Classification,
                xBudget_Type = data.Budget_Type,
                xTitle = data.Title,
                xCost_Section = data.Cost_Section,
                xFiscal_Year = data.Fiscal_Year,
                xBudget_Amount_Master = data.Budget_Amount,
                xRemark_Budget_Amount = data.Remark_Budget_Amount,
                xRemark = data.Remark,
                xPurpose_Type = data.Purpose_Type,

                // Data Master Form
                 xForm_AFD_Category = data.Form_AFD_Category,

             
                //Path Document 
                xPath_Content_Overview = SourceViewDocumentAFD +  data.Path_Content_Overview, 
                xPath_Schedule = SourceViewDocumentAFD + data.Path_Schedule,
                xPath_Bidding_Document = SourceViewDocumentAFD + data.Path_Bidding_Document

            };
             

            var resultPayment = (from a in db_AFD.T_Payment
                                 where a.AFD_ID == CoverLetterId
                                 select new PaymentViewModel
                                 {
                                     FiscalYear = a.Fiscal_Year,
                                     Quarter = a.Fiscal_Quarter,
                                     CapitalExpense = a.Capital_Expense_Amount ?? 0,
                                     Expense = a.Expense_Amount ?? 0
                                 }).ToList();




            return Json(new
            {
                status = "success",
                message = "Data Found",
                solution = "",
                AFD = resultAFD,
                Payment = resultPayment
            }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDraft(AFDCreateModel model)
        {
            try
            {
                // --- INSERT HEADER ---
                T_AFD data = new T_AFD()
                {
                    Form_AFD_ID = model.FormAFDID,
                    Budget_Final_ID = model.AmountBudgetID,
                    Proposal_Date = model.DateOfProposal,
                    AFD_Title = model.Title, 
                    AFD_SubType = model.AFDSubType,
                    Budget_Amount = (double)model.AmountBudget,

                    ExchangeRate_USD = (double)model.Rate,
                    Place = model.Place,
                    Period_Commencement = model.PeriodeCommencement,
                    Period_Completion = model.PeriodeCompletion,
                    Purpose_Description = model.PurposeDescription,
                    Specification_Requisite = model.RequisiteSpecification,
                    Expected_Effect = model.ExpectedEffect,
                    Coordinator_Name = model.CoordinatorName,
                    Coordinator_Section = model.CoordinatorSection,
                    Decision_Status = model.DecisionStatus,
                    Disposal_Responsible = model.DisposalResponsible,

                    CreateUserId = model.NIKLogin,
                    CreateDateTime = DateTime.Now,
                    CreateIP = Request.UserHostAddress,

                    Flag_Draft = 1
                };

                db_AFD.T_AFD.Add(data);
                db_AFD.SaveChanges();

                int newAFDID = data.AFD_ID;   // <-- ID berhasil terbentuk


                // =====================================================================
                //  INSERT DETAIL PAYMENT FY1–FY3
                // =====================================================================


                var FY = int.Parse(model.FiscalYear);

                var payments = new List<T_Payment>();

                for (int fy = 1; fy <= 3; fy++)
                {
                    for (int q = 1; q <= 4; q++)
                    {
                        decimal capex = 0;
                        decimal expense = 0;
                        int fiscalyear = FY;   // <-- default agar tidak unassigned

                        if (fy == 1)
                        {
                            if (q == 1) { capex = model.Payment.CAPEX.FY1.Q1; expense = model.Payment.EXPENSE.FY1.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY1.Q2; expense = model.Payment.EXPENSE.FY1.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY1.Q3; expense = model.Payment.EXPENSE.FY1.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY1.Q4; expense = model.Payment.EXPENSE.FY1.Q4; }
                        }

                        if (fy == 2)
                        {
                            fiscalyear = FY + 1;
                            if (q == 1) { capex = model.Payment.CAPEX.FY2.Q1; expense = model.Payment.EXPENSE.FY2.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY2.Q2; expense = model.Payment.EXPENSE.FY2.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY2.Q3; expense = model.Payment.EXPENSE.FY2.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY2.Q4; expense = model.Payment.EXPENSE.FY2.Q4; }
                        }

                        if (fy == 3)
                        {
                            fiscalyear = FY + 2;
                            if (q == 1) { capex = model.Payment.CAPEX.FY3.Q1; expense = model.Payment.EXPENSE.FY3.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY3.Q2; expense = model.Payment.EXPENSE.FY3.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY3.Q3; expense = model.Payment.EXPENSE.FY3.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY3.Q4; expense = model.Payment.EXPENSE.FY3.Q4; }
                        }

                        payments.Add(new T_Payment
                        {
                            AFD_ID = newAFDID,
                            Fiscal_Year = fiscalyear.ToString(),
                            Fiscal_Quarter = $"Q{q}",
                            Capital_Expense_Amount = capex,
                            Expense_Amount = expense
                        });
                    }
                }

                db_AFD.T_Payment.AddRange(payments);
                db_AFD.SaveChanges();



                // =====================================================================
                //  UPDATE TOTAL
                // =====================================================================

                decimal? totalCapex = payments.Sum(x => x.Capital_Expense_Amount);
                decimal? totalExpense = payments.Sum(x => x.Expense_Amount);

                var afd = db_AFD.T_AFD.Find(newAFDID);

                afd.Capital_Expense_Amount = (double?)totalCapex;
                afd.Expense_Amount = (double?)totalExpense;
                //afd.Budget_Amount = (double?)totalCapex + (double?)totalExpense;
              

                db_AFD.SaveChanges();



                // =====================================================================
                //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
                // =====================================================================

                string SaveAndRename(string base64, string originalName, string folderPath, string prefix)
                {
                    if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
                        return "";

                    string cleanName = Path.GetFileName(originalName);
                    string originalPath = Path.Combine(folderPath, cleanName);

                    byte[] fileBytes = Convert.FromBase64String(base64);

                    // Pastikan jika file lama masih ada → hapus (unlock friendly)
                    if (System.IO.File.Exists(originalPath))
                    {
                        System.IO.File.SetAttributes(originalPath, FileAttributes.Normal);
                        System.IO.File.Delete(originalPath);
                    }

                    // SAVE FILE TANPA LOCK
                    using (var fs = new FileStream(originalPath, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        fs.Write(fileBytes, 0, fileBytes.Length);
                    } // <-- file dijamin tertutup 100%

                    // Rename
                    string newFileName = $"{prefix}_{cleanName}";
                    string newFilePath = Path.Combine(folderPath, newFileName);
                  
                    if (System.IO.File.Exists(newFilePath))
                    {
                        System.IO.File.SetAttributes(newFilePath, FileAttributes.Normal);
                        System.IO.File.Delete(newFilePath);
                    }

                    // MOVE TANPA LOCK
                    System.IO.File.Move(originalPath, newFilePath);

                    return newFileName;
                }




                string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";
                if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

                // Save + Rename fisik:
                string overviewFile = SaveAndRename(
                    model.FileContentOverview,
                    model.FileNameContentOverview,
                    xFolder,
                    newAFDID + "_ContentOverview"
                );

                string scheduleFile = SaveAndRename(
                    model.FileSchedule,
                    model.FileNameSchedule,
                    xFolder,
                    newAFDID + "_Schedule"
                );

                string biddingFile = SaveAndRename(
                    model.FileBiddingDocument,
                    model.FileNameBiddingDocument,
                    xFolder,
                    newAFDID + "_Bidding"
                );

                var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == newAFDID);

                if (afdAttachFile != null)
                {
                    if (!string.IsNullOrEmpty(overviewFile))
                        afdAttachFile.Content_Overview = overviewFile;

                    if (!string.IsNullOrEmpty(scheduleFile))
                        afdAttachFile.Schedule = scheduleFile;

                    if (!string.IsNullOrEmpty(biddingFile))
                        afdAttachFile.Bidding_Document = biddingFile;

                    db_AFD.SaveChanges();
                }

                // =====================================================================
                //  RETURN + KIRIM AFD_ID KE FRONTEND
                // =====================================================================

                ViewBag.StatusData = "draft";
                ViewBag.CoverLetterID = newAFDID;
                return Json(new { success = true, afd_id = newAFDID, status = "saved" });

            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult SaveChanges(AFDCreateModel model)
        {
            try
            {

                int CoverLetterID = Convert.ToInt32(model.CoverLetterID);


                // Ambil data lama
                var data = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);


                if (data == null)
                {
                    return Json(new { success = false, message = "Data not found" });
                }

                // =====================================================================
                //  UPDATE HEADER
                // =====================================================================
                data.Form_AFD_ID = model.FormAFDID;
                data.Budget_Final_ID = model.AmountBudgetID;
                data.Proposal_Date = model.DateOfProposal;
                data.AFD_Title = model.Title;
                data.AFD_SubType = model.AFDSubType;

                data.ExchangeRate_USD = (double)model.Rate;
                data.Place = model.Place;
                data.Period_Commencement = model.PeriodeCommencement;
                data.Period_Completion = model.PeriodeCompletion;
                data.Purpose_Description = model.PurposeDescription;
                data.Specification_Requisite = model.RequisiteSpecification;
                data.Expected_Effect = model.ExpectedEffect;
                data.Coordinator_Name = model.CoordinatorName;
                data.Coordinator_Section = model.CoordinatorSection;
                data.Decision_Status = model.DecisionStatus;
                data.Disposal_Responsible = model.DisposalResponsible;

                // audit update
                data.UpdateUserId = model.NIKLogin;
                data.UpdateDateTime = DateTime.Now;
                data.UpdateIP = Request.UserHostAddress;

                db_AFD.SaveChanges();

                // =====================================================================
                //  Hapus detail payment lama
                // =====================================================================
                var oldPayments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterID).ToList();
                db_AFD.T_Payment.RemoveRange(oldPayments);
                db_AFD.SaveChanges();




                // =====================================================================
                //   Insert kembali payment FY1–FY3(12 baris)
                // =====================================================================

                var FY = int.Parse(model.FiscalYear);

                var payments = new List<T_Payment>();

                for (int fy = 1; fy <= 3; fy++)
                {
                    for (int q = 1; q <= 4; q++)
                    {
                        decimal capex = 0;
                        decimal expense = 0;
                        int fiscalyear = FY;   // <-- default agar tidak unassigned


                        if (fy == 1)
                        {
                            if (q == 1) { capex = model.Payment.CAPEX.FY1.Q1; expense = model.Payment.EXPENSE.FY1.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY1.Q2; expense = model.Payment.EXPENSE.FY1.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY1.Q3; expense = model.Payment.EXPENSE.FY1.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY1.Q4; expense = model.Payment.EXPENSE.FY1.Q4; }
                        }

                        if (fy == 2)
                        {
                            fiscalyear = FY + 1;
                            if (q == 1) { capex = model.Payment.CAPEX.FY2.Q1; expense = model.Payment.EXPENSE.FY2.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY2.Q2; expense = model.Payment.EXPENSE.FY2.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY2.Q3; expense = model.Payment.EXPENSE.FY2.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY2.Q4; expense = model.Payment.EXPENSE.FY2.Q4; }
                        }

                        if (fy == 3)
                        {
                            fiscalyear = FY + 2;
                            if (q == 1) { capex = model.Payment.CAPEX.FY3.Q1; expense = model.Payment.EXPENSE.FY3.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY3.Q2; expense = model.Payment.EXPENSE.FY3.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY3.Q3; expense = model.Payment.EXPENSE.FY3.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY3.Q4; expense = model.Payment.EXPENSE.FY3.Q4; }
                        }

                        payments.Add(new T_Payment
                        {
                            AFD_ID = CoverLetterID,
                            Fiscal_Year = fiscalyear.ToString(),
                            Fiscal_Quarter = $"Q{q}",
                            Capital_Expense_Amount = capex,
                            Expense_Amount = expense
                        });
                    }
                }

                db_AFD.T_Payment.AddRange(payments);
                db_AFD.SaveChanges();


                // =====================================================================
                //   Update total
                // =====================================================================
                data.Capital_Expense_Amount = payments.Sum(x => (double?)x.Capital_Expense_Amount);
                data.Expense_Amount = payments.Sum(x => (double?)x.Expense_Amount);
                data.Budget_Amount = data.Capital_Expense_Amount + data.Expense_Amount;

                db_AFD.SaveChanges();



                // =====================================================================
                //   Update file (overwrite)
                // =====================================================================

                // =====================================================================
                //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
                // ===================================================================== 

                string SaveAndRename(string base64, string originalName, string folderPath, string prefix)
                {
                    if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
                        return "";

                    string cleanName = Path.GetFileName(originalName);
                    string originalPath = Path.Combine(folderPath, cleanName);

                    byte[] fileBytes = Convert.FromBase64String(base64);

                    // Pastikan jika file lama masih ada → hapus (unlock friendly)
                    if (System.IO.File.Exists(originalPath))
                    {
                        System.IO.File.SetAttributes(originalPath, FileAttributes.Normal);
                        System.IO.File.Delete(originalPath);
                    }

                    // SAVE FILE TANPA LOCK
                    using (var fs = new FileStream(originalPath, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        fs.Write(fileBytes, 0, fileBytes.Length);
                    } // <-- file dijamin tertutup 100%

                    // Rename
                    string newFileName = $"{prefix}_{cleanName}";
                    string newFilePath = Path.Combine(folderPath, newFileName);

                    if (System.IO.File.Exists(newFilePath))
                    {
                        System.IO.File.SetAttributes(newFilePath, FileAttributes.Normal);
                        System.IO.File.Delete(newFilePath);
                    }

                    // MOVE TANPA LOCK
                    System.IO.File.Move(originalPath, newFilePath);

                    return newFileName;
                }
                 
                string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";
                if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

                // Save + Rename fisik:
                string overviewFile = SaveAndRename(
                    model.FileContentOverview,
                    model.FileNameContentOverview,
                    xFolder,
                    CoverLetterID + "_ContentOverview"
                );

                string scheduleFile = SaveAndRename(
                    model.FileSchedule,
                    model.FileNameSchedule,
                    xFolder,
                    CoverLetterID + "_Schedule"
                );

                string biddingFile = SaveAndRename(
                    model.FileBiddingDocument,
                    model.FileNameBiddingDocument,
                    xFolder,
                    CoverLetterID + "_Bidding"
                );

                var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);

                if (afdAttachFile != null)
                {
                    if (!string.IsNullOrEmpty(overviewFile))
                        afdAttachFile.Content_Overview = overviewFile; 

                    if (!string.IsNullOrEmpty(scheduleFile))
                        afdAttachFile.Schedule = scheduleFile;

                    if (!string.IsNullOrEmpty(biddingFile))
                        afdAttachFile.Bidding_Document = biddingFile;

                    db_AFD.SaveChanges();

 
                }


                return Json(new { success = true, afd_id = CoverLetterID, attch1 = overviewFile, attch3 = scheduleFile, attch5 = biddingFile, }); 

            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = ex.Message });
            }
        }

        public JsonResult DeleteData(int CoverLetterId)
        {

            var result = (from x in db_AFD.T_AFD
                          where x.Flag_Reapplication == null
                             && x.Flag_Draft == 1
                             && x.AFD_ID == CoverLetterId
                          select x).ToList();

            if (result == null || result.Count == 0)
            {
                return Json(new
                {
                    status = "error",
                    message = "Data cannot be deleted",
                    solution = "please contact the IS staff"
                }, JsonRequestBehavior.AllowGet);
            }
             

            var payments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterId).ToList();
            if (payments.Any())
            {
                db_AFD.T_Payment.RemoveRange(payments);
            }

            var afd = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterId);
            if (afd != null)
            {
                db_AFD.T_AFD.Remove(afd);
            }

            db_AFD.SaveChanges();




            return Json(new
            {
                status = "success",
                message = "The data has been deleted successfully.",
                solution = ""
            }, JsonRequestBehavior.AllowGet);
        }
         
        public ActionResult PrintCoverLetter(string CoverLetterId)
        {
            ViewBag.xCoverLetterID = CoverLetterId.ToString();

            List<PrintCoverLetter> DataHeaderCoverLetter = new List<PrintCoverLetter>();
            var xDataHeaderCoverLetter = "EXEC SP_PrintCoverLetter " + CoverLetterId + ", 'Header'";
            DataHeaderCoverLetter = db_AFD.Database.SqlQuery<PrintCoverLetter>(xDataHeaderCoverLetter).ToList(); 
            ViewBag.HeaderCoverLetter = DataHeaderCoverLetter;


            List<PrintSignature> DataSignature = new List<PrintSignature>();
            var xDataSignature = "EXEC SP_PrintCoverLetter " + CoverLetterId + ", 'Signature'";
            DataSignature = db_AFD.Database.SqlQuery<PrintSignature>(xDataSignature).ToList();
            ViewBag.Signature = DataSignature;


            return View();
        }


        [HttpPost]
        public JsonResult SubmitApproval(AFDCreateModel model)
        {
            try
            {

                int CoverLetterID = Convert.ToInt32(model.CoverLetterID);


                // Ambil data lama
                var data = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);


                if (data == null)
                {
                    return Json(new { success = false, message = "Data not found" });
                }

                // =====================================================================
                //  UPDATE HEADER
                // =====================================================================
                data.Form_AFD_ID = model.FormAFDID;
                data.Budget_Final_ID = model.AmountBudgetID;
                data.Proposal_Date = model.DateOfProposal;
                data.AFD_Title = model.Title;
                data.AFD_SubType = model.AFDSubType;

                data.ExchangeRate_USD = (double)model.Rate;
                data.Place = model.Place;
                data.Period_Commencement = model.PeriodeCommencement;
                data.Period_Completion = model.PeriodeCompletion;
                data.Purpose_Description = model.PurposeDescription;
                data.Specification_Requisite = model.RequisiteSpecification;
                data.Expected_Effect = model.ExpectedEffect;
                data.Coordinator_Name = model.CoordinatorName;
                data.Coordinator_Section = model.CoordinatorSection;
                data.Decision_Status = model.DecisionStatus;
                data.Disposal_Responsible = model.DisposalResponsible;

                // audit update
                data.UpdateUserId = model.NIKLogin;
                data.UpdateDateTime = DateTime.Now;
                data.UpdateIP = Request.UserHostAddress;

                db_AFD.SaveChanges();

                // =====================================================================
                //  Hapus detail payment lama
                // =====================================================================
                var oldPayments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterID).ToList();
                db_AFD.T_Payment.RemoveRange(oldPayments);
                db_AFD.SaveChanges();




                // =====================================================================
                //   Insert kembali payment FY1–FY3(12 baris)
                // =====================================================================

                var FY = int.Parse(model.FiscalYear);

                var payments = new List<T_Payment>();

                for (int fy = 1; fy <= 3; fy++)
                {
                    for (int q = 1; q <= 4; q++)
                    {
                        decimal capex = 0;
                        decimal expense = 0;
                        int fiscalyear = FY;   // <-- default agar tidak unassigned


                        if (fy == 1)
                        {
                            if (q == 1) { capex = model.Payment.CAPEX.FY1.Q1; expense = model.Payment.EXPENSE.FY1.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY1.Q2; expense = model.Payment.EXPENSE.FY1.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY1.Q3; expense = model.Payment.EXPENSE.FY1.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY1.Q4; expense = model.Payment.EXPENSE.FY1.Q4; }
                        }

                        if (fy == 2)
                        {
                            fiscalyear = FY + 1;
                            if (q == 1) { capex = model.Payment.CAPEX.FY2.Q1; expense = model.Payment.EXPENSE.FY2.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY2.Q2; expense = model.Payment.EXPENSE.FY2.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY2.Q3; expense = model.Payment.EXPENSE.FY2.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY2.Q4; expense = model.Payment.EXPENSE.FY2.Q4; }
                        }

                        if (fy == 3)
                        {
                            fiscalyear = FY + 2;
                            if (q == 1) { capex = model.Payment.CAPEX.FY3.Q1; expense = model.Payment.EXPENSE.FY3.Q1; }
                            if (q == 2) { capex = model.Payment.CAPEX.FY3.Q2; expense = model.Payment.EXPENSE.FY3.Q2; }
                            if (q == 3) { capex = model.Payment.CAPEX.FY3.Q3; expense = model.Payment.EXPENSE.FY3.Q3; }
                            if (q == 4) { capex = model.Payment.CAPEX.FY3.Q4; expense = model.Payment.EXPENSE.FY3.Q4; }
                        }

                        payments.Add(new T_Payment
                        {
                            AFD_ID = CoverLetterID,
                            Fiscal_Year = fiscalyear.ToString(),
                            Fiscal_Quarter = $"Q{q}",
                            Capital_Expense_Amount = capex,
                            Expense_Amount = expense
                        });
                    }
                }

                db_AFD.T_Payment.AddRange(payments);
                db_AFD.SaveChanges();


                // =====================================================================
                //   Update total
                // =====================================================================
                data.Capital_Expense_Amount = payments.Sum(x => (double?)x.Capital_Expense_Amount);
                data.Expense_Amount = payments.Sum(x => (double?)x.Expense_Amount);
                data.Budget_Amount = data.Capital_Expense_Amount + data.Expense_Amount;

                db_AFD.SaveChanges();



                // =====================================================================
                //   Update file (overwrite)
                // =====================================================================

                // =====================================================================
                //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
                // ===================================================================== 

                string SaveAndRename(string base64, string originalName, string folderPath, string prefix)
                {
                    if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
                        return "";

                    string cleanName = Path.GetFileName(originalName);
                    string originalPath = Path.Combine(folderPath, cleanName);

                    byte[] fileBytes = Convert.FromBase64String(base64);

                    // Pastikan jika file lama masih ada → hapus (unlock friendly)
                    if (System.IO.File.Exists(originalPath))
                    {
                        System.IO.File.SetAttributes(originalPath, FileAttributes.Normal);
                        System.IO.File.Delete(originalPath);
                    }

                    // SAVE FILE TANPA LOCK
                    using (var fs = new FileStream(originalPath, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        fs.Write(fileBytes, 0, fileBytes.Length);
                    } // <-- file dijamin tertutup 100%

                    // Rename
                    string newFileName = $"{prefix}_{cleanName}";
                    string newFilePath = Path.Combine(folderPath, newFileName);

                    if (System.IO.File.Exists(newFilePath))
                    {
                        System.IO.File.SetAttributes(newFilePath, FileAttributes.Normal);
                        System.IO.File.Delete(newFilePath);
                    }

                    // MOVE TANPA LOCK
                    System.IO.File.Move(originalPath, newFilePath);

                    return newFileName;
                }

                string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";
                if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

                // Save + Rename fisik:
                string overviewFile = SaveAndRename(
                    model.FileContentOverview,
                    model.FileNameContentOverview,
                    xFolder,
                    CoverLetterID + "_ContentOverview"
                );

                string scheduleFile = SaveAndRename(
                    model.FileSchedule,
                    model.FileNameSchedule,
                    xFolder,
                    CoverLetterID + "_Schedule"
                );

                string biddingFile = SaveAndRename(
                    model.FileBiddingDocument,
                    model.FileNameBiddingDocument,
                    xFolder,
                    CoverLetterID + "_Bidding"
                );

                var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);

                if (afdAttachFile != null)
                {
                    if (!string.IsNullOrEmpty(overviewFile))
                        afdAttachFile.Content_Overview = overviewFile;

                    if (!string.IsNullOrEmpty(scheduleFile))
                        afdAttachFile.Schedule = scheduleFile;

                    if (!string.IsNullOrEmpty(biddingFile))
                        afdAttachFile.Bidding_Document = biddingFile;

                    db_AFD.SaveChanges();


                }


                return Json(new { success = true, afd_id = CoverLetterID, attch1 = overviewFile, attch3 = scheduleFile, attch5 = biddingFile, });

            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = ex.Message });
            }
        }
        //end of
    }
}