﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using System.IO;
using System.Data.SqlClient;

namespace Web_Portal.Controllers
{
    public class AFDMasterController : Controller
    {
         
        private WebPortalEntities db = new WebPortalEntities();
        private AFDEntities db_AFD = new AFDEntities();
        private Attendance_MGREntities db_Att = new Attendance_MGREntities();



        // GET: AFDMaster
        public ActionResult IndexApproval()
        {
            return View();
        }
         
        public JsonResult GetDept()
        {
            var data = db_AFD.M_Cost_Section 
                .Select(x => x.Dept_Name)
                .Distinct()
                .Select(x => new
                {
                    Value = x,
                    Text = x
                })
                .ToList();


            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCostSection(string Dept)
        {
            var data = db_AFD.M_Cost_Section
                        .Where(x => x.Dept_Name == Dept)
                        .Distinct()
                        .Select(g => new
                        {
                            Value = g.Cost_Section,
                            Text = g.Cost_Section
                        })
                        .ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEmployee()
        {
            var data = db_AFD.M_User_Access
                       .Distinct()
                .Select(x => new
                {
                    x.NIK,
                    x.Sign_Name,
                    x.Sign_Title
                }).ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetNewStep()
        {
            var data = db_AFD.M_User_Access
                       .Distinct()
                .Select(x => new
                {
                    x.NIK,
                    x.Sign_Name,
                    x.Sign_Title
                }).ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult GetRuleApproval(string param1, string param2, string param3, string param4, string param5)
        {

            int FormAFDId =
      (from a in db_AFD.M_Rule_Approval
       join c in db_AFD.M_Form_AFD
          on a.Form_AFD_ID equals c.Form_AFD_ID
       where c.AFD_Type == param3
          && a.Cost_Section == param1
          && c.Form_AFD_Type == param2
          && c.Form_AFD_Category == param4
          && c.AFD_SubType == param5
       orderby a.Approval_Step
       select c.Form_AFD_ID
      ).FirstOrDefault();

            ViewBag.xFormAFDID = FormAFDId;


            var result = (
       from a in db_AFD.M_Rule_Approval
       join c in db_AFD.M_Form_AFD
           on a.Form_AFD_ID equals c.Form_AFD_ID
       join b in db_AFD.M_User_Access
           on a.Approver_NIK equals b.NIK into userJoin
       from b in userJoin.DefaultIfEmpty()
       where c.AFD_Type == param3
           && a.Cost_Section == param1
           && c.Form_AFD_Type == param2
           && c.Form_AFD_Category == param4
       orderby a.Approval_Step ascending
       select new
       {
           a.Form_AFD_ID,
           a.Approval_Step,
           b.NIK,
           b.Sign_Name,
           b.Sign_Title
       }
   ).ToList();


            return Json(result, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult SaveRuleApproval(MasterRuleApproval model)
        {
            if (model.Items == null || !model.Items.Any())
            {
                return Json(new { success = false, message = "No data to save" });
            }

            using (var trx = db_AFD.Database.BeginTransaction())
            {
                try
                {
                    string NIKlogin = Session["NIK"]?.ToString();

                    if (string.IsNullOrEmpty(NIKlogin))
                        throw new Exception("Session expired");

                    string costSection = model.CostSection;
                    int formAFDID = model.Items.First().FormAFDID;

                    // 1️⃣ DELETE DATA LAMA
                    var oldData = db_AFD.M_Rule_Approval
                                .Where(x => x.Form_AFD_ID == formAFDID
                                         && x.Cost_Section == costSection)
                                .ToList();

                    db_AFD.M_Rule_Approval.RemoveRange(oldData);
                    db_AFD.SaveChanges();


                    // 2️⃣ INSERT DATA BARU
                    foreach (var item in model.Items)
                    {
                        M_Rule_Approval data = new M_Rule_Approval
                        {
                            Form_AFD_ID = formAFDID,
                            Cost_Section = costSection,
                            Approval_Step = item.Step,
                            Approver_NIK = item.NIK  
                        };

                        db_AFD.M_Rule_Approval.Add(data);
                    }

                    db_AFD.SaveChanges();

                    trx.Commit();

                    return Json(new { success = true });
                }
                catch (Exception ex)
                {
                    trx.Rollback();
                    return Json(new { success = false, message = ex.Message });
                }
            }
        }



    }
}