﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using System.IO;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace Web_Portal.Controllers
{ 

    public class AFDCoverLetterController : Controller
    {

        private WebPortalEntities db = new WebPortalEntities();
        private AFDEntities db_AFD = new AFDEntities();
        private Attendance_MGREntities db_Att = new Attendance_MGREntities();


        // GET: AFDCoverLetter
        public ActionResult Index(string mode, string CoverLetterId)
        { 
            db.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db.Configuration.ProxyCreationEnabled = false;

            db_Att.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db_Att.Configuration.ProxyCreationEnabled = false;

            db_AFD.Configuration.LazyLoadingEnabled = false; // if your table is relational, contain foreign key
            db_AFD.Configuration.ProxyCreationEnabled = false;
             
            string NIKlogin = Session["NIK"].ToString();    
            ViewBag.NIKLogin = NIKlogin;

            int AFD_id = Convert.ToInt32(CoverLetterId);


            string flagPICCurrent = db_AFD.T_Approval
                                    .Any(x => x.AFD_ID == AFD_id && x.Approver_NIK == NIKlogin)
                                    ? "YES"
                                    : "NO";
            ViewBag.xflagPICCurrent = flagPICCurrent;


            


            var flagCreate = db_AFD.M_User_Access
                            .Where(x => x.NIK == NIKlogin)
                            .Select(x => (int?)x.Flag_Create)
                            .FirstOrDefault() ?? 0;
            ViewBag.xflagcreate = flagCreate;




            //untuk set attribute disabled
            if (flagCreate == 1)
            {
                ViewBag.xReadOnly = "";
            }
            else
            {
                ViewBag.xReadOnly = "disabled";
            }



            var flagDecisionNumber = db_AFD.M_User_Access
                                    .Where(x => x.NIK == NIKlogin)
                                    .Select(x => (int?)x.Flag_Decision_Number)
                                    .FirstOrDefault() ?? 0;
            ViewBag.xflagDecisionNumber = flagDecisionNumber;




            var prevSteps = db_AFD.T_Approval
               .Where(x => x.AFD_ID == AFD_id && x.Approver_NIK == NIKlogin)
               .Select(x => x.Approval_Step - 1); 
            var approverNIKs = db_AFD.T_Approval
                .Where(x => prevSteps.Contains(x.Approval_Step))
                .Select(x => x.Approver_NIK);




            var maxStep = db_AFD.T_Approval
            .Where(x => x.AFD_ID == AFD_id)
            .Select(x => (int?)x.Approval_Step)
            .Max();

            bool isPIC = false;

            if (maxStep.HasValue)
            {
                isPIC = db_AFD.T_Approval
                    .Any(x => x.AFD_ID == AFD_id
                           && x.Approval_Step == (maxStep.Value - 1)
                           && x.Approver_NIK == NIKlogin);
            }

            ViewBag.xflagDecisionStatus = isPIC ? "" : "disabled";


             

            var cekApprovalStepNow = db_AFD.T_Approval
                                    .Where(x => x.AFD_ID == AFD_id && x.Approver_NIK == NIKlogin)
                                    .Select(x => x.Updated_DateTime)
                                    .FirstOrDefault();


            var cekApprovalStepBefore = db_AFD.T_Approval
                                       .Where(a => a.AFD_ID == AFD_id &&
                                       db_AFD.T_Approval
                                       .Where(b => b.AFD_ID == AFD_id && b.Approver_NIK == NIKlogin)
                                       .Select(b => b.Approval_Step - 1)
                                       .Contains(a.Approval_Step)
                                        )
                                        .Select(a => a.Updated_DateTime)
                                        .FirstOrDefault();

            var flagDraft = db_AFD.T_AFD
                            .Where(a => a.AFD_ID == AFD_id)
                            .Select(a => a.Flag_Draft)
                            .FirstOrDefault();



            //kalau masih null, berarti blm selesai approval terakhirnya 
            var cekProgressApproval = db_AFD.T_Approval
                .Where(x => x.AFD_ID == AFD_id)
                .Where(x => x.Approval_Step == db_AFD.T_Approval
                .Where(y => y.AFD_ID == AFD_id)
                .Max(y => y.Approval_Step) - 1
                )
                .Select(x => x.Updated_DateTime)
                .FirstOrDefault();

     
                //logic untuk akses input decision number & date 
                if (cekProgressApproval != null && flagDecisionNumber == 1)
            {
                ViewBag.xdisabled_DecisionNumber = ""; 
                ViewBag.btnNameSubmit = "Close";
            }
            else {
                ViewBag.xdisabled_DecisionNumber = "disabled";
                ViewBag.btnNameSubmit = "Submit";
            }

            //end of



            //untuk tampilin log history  
            List<LogHistory> DataLogHistory = new List<LogHistory>();
            var xDataHeaderCoverLetter = "EXEC SP_LogHistory " + AFD_id + "";
            DataLogHistory = db_AFD.Database.SqlQuery<LogHistory>(xDataHeaderCoverLetter).ToList();
            ViewBag.xListLogHistory = DataLogHistory;







            if (flagDraft == null)
            {
                ViewBag.StatusData = "new";
            }

            else if (flagDraft == 1 && flagCreate == 1) //untuk nampilin kalau status masih draft dan yg login PICnya
            {
                ViewBag.StatusData = "draft";
            }

            else if (cekApprovalStepNow == null &&  cekApprovalStepBefore != null)  //untuk nampilin dengan syarat approval sebelumnnya sudah OK
            {
                ViewBag.StatusData = "inprogress";
            }
            else {
                ViewBag.StatusData = "not found";
            }


            return View(); 
        }


        // /AFDCoverLetter/BudgetSheet?id=123
        public ActionResult BudgetSheet(int id)
        {
            // ID yang dikirim dari tombol masuk ke sini ✅
            ViewBag.BudgetId = id;

            // Jika kamu butuh data dari DB, query di sini:
            // var data = db.TableBudget.FirstOrDefault(x => x.Id == id);
            // return View(data);



            return View(); // atau return View(data);
        }


        public JsonResult GetAFDType()
        {
            var data = db_AFD.M_Form_AFD
            .Select(a => a.AFD_Type)
            .Distinct()
            .Select(x => new {
                Value = x,
                Text = x
            })
            .ToList(); 

            return Json(data, JsonRequestBehavior.AllowGet);
        }




        public JsonResult GetAmountRange(
       string decisionLevel,
       string afdType,
       string afdSubType,
       string category)
        {


            string NIKlogin = Session["NIK"].ToString();

            var data =
                    (from a in db_AFD.M_Form_AFD
                     join r in db_AFD.M_Rule_Approval
                     on a.Form_AFD_ID equals r.Form_AFD_ID
                     where a.AFD_Type == afdType
                     && a.Decision_By == decisionLevel
                     && a.Form_AFD_Category == category
                     && r.Approver_NIK == NIKlogin
                     && r.Approval_Step == 0
                     select new
                     {
                         a.Approval_Min_Amount,
                         a.Approval_Max_Amount,
                         a.View_Amount,
                         a.Form_AFD_ID
                     })
                    .FirstOrDefault();
             

            if (data == null)
            {
                return Json(new
                {
                    status = "error"
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
            return Json(new
            {
                status = "ok",
                minAmount = data.Approval_Min_Amount,
                maxAmount = data.Approval_Max_Amount,
                viewAmount = data.View_Amount,
                idAFDForm = data.Form_AFD_ID
            }, JsonRequestBehavior.AllowGet);

            }




        }



        public JsonResult SetDecisionLevel( 
       string afdType,
       string afdSubType,
       string category,
       decimal amountBudget
       )
 
        { 
            string NIKlogin = Session["NIK"].ToString();

            var data =
                             (from a in db_AFD.M_Form_AFD
                              join b in db_AFD.M_Rule_Approval
                                  on a.Form_AFD_ID equals b.Form_AFD_ID
                              where a.AFD_Type == afdType
                                 && a.AFD_SubType == afdSubType
                                 && b.Approver_NIK == NIKlogin
                                 && amountBudget >= a.Approval_Min_Amount
                                 && amountBudget <= a.Approval_Max_Amount
                                 && a.Form_AFD_Category == category
                              select new
                              {
                                  a.Approval_Min_Amount,
                                  a.Approval_Max_Amount,
                                  a.View_Amount,
                                  a.Form_AFD_ID,
                                  a.Decision_By
                              }
                             ).FirstOrDefault();
             
            if (data == null)
            {
                return Json(new
                {
                    status = "error"
                }, JsonRequestBehavior.AllowGet);
            }
            return Json(new
            {
                status = "ok",
                minAmount = data.Approval_Min_Amount,
                maxAmount = data.Approval_Max_Amount,
                viewAmount = data.View_Amount,
                idAFDForm = data.Form_AFD_ID,
                DecisionBy = data.Decision_By
            }, JsonRequestBehavior.AllowGet);




        }




        public JsonResult GetRate(string FiscalYear, string CurrencyCode)
        {
            // Cek session user
            if (Session["NIK"] == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Session Expired",
                    solution = "Please login in fisrt"
                }, JsonRequestBehavior.AllowGet);
            }

            string NIKlogin = Session["NIK"].ToString();

            var data = db_AFD.M_Rate_AFD
                .Where(x => x.Fiscal_Year == FiscalYear && x.Currency_Code == CurrencyCode)
                .Select(x => x.Rate)
                .FirstOrDefault();

            if (data == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Rate is not available",
                    solution = "please check in table M_Rate_AFD"
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                Rate = data
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCostSection(string NIKLogin)
        { 
          
            var result = db_AFD.M_Coordinator_Section
               .Where(x => x.NIK_Login == NIKLogin)
               .Select(x => x.Cost_Section)
               .Distinct()
               .ToList();


            if (!result.Any())
            {
                return Json(new
                {
                    status = "error",
                    message = "Cost Section is not available",
                    solution = "please check in table M Coordinator Section",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                CostSection = result
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCoordinator(string NIKLogin, string CostSection)
        {
            var result = db_AFD.M_Coordinator_Section
                     .Where(x => x.NIK_Login == NIKLogin
                              && x.Cost_Section == CostSection)
                     .Select(x => new
                     {
                         x.Coordinator_Name,
                         x.Coordinator_Section
                     })
                     .Distinct()
                     .ToList();

            if (!result.Any())
            {
                return Json(new
                {
                    status = "error",
                    message = "Coordinator Name & CoordinatorSection is not available.",
                    solution =  "please check in table M_Coordinator_Section",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                data = result
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMasterBudgetFinal(string CostSection, string FiscalYear, string AFDSubType)
        {
             
    //        var data =
    //(from a in db_AFD.M_Budget_Final
    // join b in db_AFD.T_AFD
    //     on a.Budget_Final_ID equals b.Budget_Final_ID into temp
    // from b in temp.DefaultIfEmpty()
    // where a.Fiscal_Year == FiscalYear
    //    && a.Cost_Section == CostSection
    //     && a.Classification == AFDSubType
    //    && b == null
    //    && a.Budget_Amount >= MinAmount
    //    && a.Budget_Amount <= MaxAmount
    // select a
    //).ToList();

    var data =
    (from x in db_AFD.M_Budget_Final
    where x.Fiscal_Year == FiscalYear
    && x.Cost_Section == CostSection
    && x.Classification == AFDSubType
    select x
    ).ToList();


            // Cek jika data kosong
            if (!data.Any())
            {
                return Json(new
                {
                    status = "error",
                    message = "Master Budget not found",
                    solution = "Please check or create a new data in Master",
                }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                status = "ok",
                data = data
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CheckBudgetIDinTransaction(int BudgetFinalID)
        {
            // Ambil data T_AFD berdasarkan BudgetFinalID
            var data = db_AFD.T_AFD
                             .Where(x => x.Budget_Final_ID == BudgetFinalID)
                             .ToList();

            // Jika tidak ada data sama sekali
            if (data == null || data.Count == 0)
            {
                // Maka ambil data dari M_Budget_Final
                var dataMaster = db_AFD.M_Budget_Final
                                       .Where(x => x.Budget_Final_ID == BudgetFinalID)
                                       .ToList();
                 
                return Json(new
                {
                    status = "ok",
                    message = "Budget Final ID has not been used before in this system",
                    data = dataMaster
                }, JsonRequestBehavior.AllowGet);
                
            }
            else
            {
                // Jika ada data master di T_AFD, tidak boleh pilih master
                return Json(new
                {
                    status = "exists",
                    message = "This Budget Final ID is already used",
                    data = (object)null   // <== kirim seluruh object
                }, JsonRequestBehavior.AllowGet);

            }

        }

 



        public JsonResult GetCoverLetter(int CoverLetterId)
        { 
            var data =
(
    from a in db_AFD.T_AFD

    join c in db_AFD.M_Form_AFD
        on a.Form_AFD_ID equals c.Form_AFD_ID into jc
    from c in jc.DefaultIfEmpty() // LEFT JOIN

    join d in db_AFD.M_Rule_Approval
        on a.Form_AFD_ID equals d.Form_AFD_ID into jd
    from d in jd.DefaultIfEmpty() // LEFT JOIN

    where a.AFD_ID == CoverLetterId
    select new
    {
        a.AFD_ID,
        a.Form_AFD_ID,
        a.Budget_Final_ID,
        c.AFD_Type,
        c.AFD_SubType,
        a.Proposal_Date,
        a.Cost_Section,
        a.AFD_Title,
        a.Capital_Expense_Amount,
        a.Expense_Amount,
        a.ExchangeRate_USD,
        a.Place,
        a.Period_Commencement,
        a.Period_Completion,
        a.Purpose_Description,
        a.Purpose_Type,
        a.Specification_Requisite,
        a.Expected_Effect,
        a.Coordinator_Name,
        a.Coordinator_Section,
        a.Disposal_Responsible,
        c.Decision_By,
        a.Decision_Status,
        a.Decision_Number,
        a.Decision_Date,
        a.Content_Overview,
        a.Schedule,
        a.Bidding_Document,
        a.Flag_Reapplication,
        a.Flag_Close_Approval,
        a.Flag_Draft,
        a.History_Return,
        a.Budget_Amount,
        a.Fiscal_Year,
         
        a.Budget_Type,
        a.Remark_Budget_Amount, 

        // Data Master Form
        c.Form_AFD_Category,

        // Path Document (null-safe)
        Path_Content_Overview =
            "FY" + a.Fiscal_Year +
            "/" + (c.AFD_Type ?? "") +
            "/" + (c.AFD_SubType ?? "") + 
            "/" + (a.Content_Overview ?? ""),

        Path_Schedule =
            "FY" + a.Fiscal_Year +
            "/" + (c.AFD_Type ?? "") +
            "/" + (c.AFD_SubType ?? "") + 
            "/" + (a.Schedule ?? ""),

        Path_Bidding_Document =
            "FY" + a.Fiscal_Year +
            "/" + (c.AFD_Type ?? "") +
            "/" + (c.AFD_SubType ?? "") + 
            "/" + (a.Bidding_Document ?? "")
    }
).FirstOrDefault();





            if (data == null)
            {
                return Json(new
                {
                    status = "warning",
                    message = "No data available.",
                    solution = ""
                }, JsonRequestBehavior.AllowGet);
            }


            // Get config path di webconfig 
            string SourceViewDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceViewDocumentAFD"];


       
            
            var resultAFD = new
            {
                xAFD_ID = data.AFD_ID,
                xForm_AFD_ID = data.Form_AFD_ID,
                xBudget_Final_ID = data.Budget_Final_ID,
                xAFD_Type = data.AFD_Type,
                xAFD_SubType = data.AFD_SubType,
                xProposal_Date = data.Proposal_Date?.ToString("yyyy-MM-dd") ?? "",
                xAFD_Title = data.AFD_Title,
                xBudget_Amount = data.Budget_Amount,
                xCapital_Expense_Amount = data.Capital_Expense_Amount,
                xExpense_Amount = data.Expense_Amount,
                xExchangeRate_USD = data.ExchangeRate_USD,
                xPlace = data.Place,
                xPeriod_Commencement = data.Period_Commencement?.ToString("yyyy-MM-dd") ?? "",
                xPeriod_Completion = data.Period_Completion?.ToString("yyyy-MM-dd") ?? "",
                xPurpose_Description = data.Purpose_Description,
                xSpecification_Requisite = data.Specification_Requisite,
                xExpected_Effect = data.Expected_Effect,
                xCoordinator_Name = data.Coordinator_Name,
                xCoordinator_Section = data.Coordinator_Section,
                xDisposal_Responsible = data.Disposal_Responsible,
                xDecision_By = data.Decision_By,
                xDecision_Status = data.Decision_Status,
                xDecision_Number = data.Decision_Number,
                xDecision_Date = data.Decision_Date?.ToString("yyyy-MM-dd") ?? "",
                xContent_Overview = data.Content_Overview,
                xSchedule = data.Schedule,
                xBidding_Document = data.Bidding_Document,
                xFlag_Reapplication = data.Flag_Reapplication,
                xFlag_Close_Approval = data.Flag_Close_Approval,
                xFlag_Draft = data.Flag_Draft,
                xHistory_Return = data.History_Return,

                // Data Budget Final
                xClassification = data.AFD_SubType,
                xBudget_Type = data.Budget_Type,
                xTitle = data.AFD_Title,
                xCost_Section = data.Cost_Section,
                xFiscal_Year = data.Fiscal_Year,
                xBudget_Amount_Master = data.Budget_Amount,  
                xPurpose_Type = data.Purpose_Type,

                // Data Master Form
                 xForm_AFD_Category = data.Form_AFD_Category,
                  
                //Path Document 
                xPath_Content_Overview = SourceViewDocumentAFD +  data.Path_Content_Overview, 
                xPath_Schedule = SourceViewDocumentAFD + data.Path_Schedule,
                xPath_Bidding_Document = SourceViewDocumentAFD + data.Path_Bidding_Document

            };
             


            var resultPayment = (from a in db_AFD.T_Payment
                                 where a.AFD_ID == CoverLetterId
                                 select new PaymentViewModel
                                 {
                                     FiscalYear = a.Fiscal_Year,
                                     Quarter = a.Fiscal_Quarter,
                                     CapitalExpense = a.Capital_Expense_Amount ?? 0,
                                     Expense = a.Expense_Amount ?? 0
                                 }).ToList();


            return Json(new
            {
                status = "success",
                message = "Data Found",
                solution = "",
                AFD = resultAFD,
                Payment = resultPayment
            }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDraft(AFDCreateModel model)
        {
            using (var transaction = db_AFD.Database.BeginTransaction())
            {

                try
                {
                    // --- INSERT HEADER ---
                    T_AFD data = new T_AFD()
                    {
                        Form_AFD_ID = model.FormAFDID,
                        Budget_Final_ID = model.AmountBudgetID,
                        Proposal_Date = model.DateOfProposal,
                        AFD_Title = model.Title,
                        Fiscal_Year = model.FiscalYear,
                        Cost_Section = model.CostSection,
                        Budget_Amount = model.AmountBudget,

                        ExchangeRate_USD = (double)model.Rate,
                        Place = model.Place,
                        Period_Commencement = model.PeriodeCommencement,
                        Period_Completion = model.PeriodeCompletion,
                        Purpose_Description = model.PurposeDescription,
                        Purpose_Type = model.PurposeFor,
                        Specification_Requisite = model.RequisiteSpecification,
                        Expected_Effect = model.ExpectedEffect,
                        Coordinator_Name = model.CoordinatorName,
                        Coordinator_Section = model.CoordinatorSection,
                        Decision_Status = model.DecisionStatus,
                        Disposal_Responsible = model.DisposalResponsible,
                         
                        Budget_Type=model.BudgetType,

                        CreateUserId = model.NIKLogin,
                        CreateDateTime = DateTime.Now,
                        CreateIP = Request.UserHostAddress,

                        Flag_Draft = 1
                    };

                    db_AFD.T_AFD.Add(data);
                    db_AFD.SaveChanges();

                    int newAFDID = data.AFD_ID;   // <-- ID berhasil terbentuk


                    // =====================================================================
                    //  INSERT DETAIL PAYMENT FY1–FY3
                    // =====================================================================


                    var FY = int.Parse(model.FiscalYear);

                    var payments = new List<T_Payment>();

                    for (int fy = 1; fy <= 3; fy++)
                    {
                        for (int q = 1; q <= 4; q++)
                        {
                            decimal capex = 0;
                            decimal expense = 0;
                            int fiscalyear = FY;   // <-- default agar tidak unassigned

                            if (fy == 1)
                            {
                                if (q == 1) { capex = model.Payment.CAPEX.FY1.Q1 ?? 0; expense = model.Payment.EXPENSE.FY1.Q1 ?? 0; }
                                if (q == 2) { capex = model.Payment.CAPEX.FY1.Q2 ?? 0; expense = model.Payment.EXPENSE.FY1.Q2 ?? 0; }
                                if (q == 3) { capex = model.Payment.CAPEX.FY1.Q3 ?? 0; expense = model.Payment.EXPENSE.FY1.Q3 ?? 0; }
                                if (q == 4) { capex = model.Payment.CAPEX.FY1.Q4 ?? 0; expense = model.Payment.EXPENSE.FY1.Q4 ?? 0; }
                            }

                            if (fy == 2)
                            {
                                fiscalyear = FY + 1;
                                if (q == 1) { capex = model.Payment.CAPEX.FY2.Q1 ?? 0; expense = model.Payment.EXPENSE.FY2.Q1 ?? 0; }
                                if (q == 2) { capex = model.Payment.CAPEX.FY2.Q2 ?? 0; expense = model.Payment.EXPENSE.FY2.Q2 ?? 0; }
                                if (q == 3) { capex = model.Payment.CAPEX.FY2.Q3 ?? 0; expense = model.Payment.EXPENSE.FY2.Q3 ?? 0; }
                                if (q == 4) { capex = model.Payment.CAPEX.FY2.Q4 ?? 0; expense = model.Payment.EXPENSE.FY2.Q4 ?? 0; }
                            }

                            if (fy == 3)
                            {
                                fiscalyear = FY + 2;
                                if (q == 1) { capex = model.Payment.CAPEX.FY3.Q1 ?? 0; expense = model.Payment.EXPENSE.FY3.Q1 ?? 0; }
                                if (q == 2) { capex = model.Payment.CAPEX.FY3.Q2 ?? 0; expense = model.Payment.EXPENSE.FY3.Q2 ?? 0; }
                                if (q == 3) { capex = model.Payment.CAPEX.FY3.Q3 ?? 0; expense = model.Payment.EXPENSE.FY3.Q3 ?? 0; }
                                if (q == 4) { capex = model.Payment.CAPEX.FY3.Q4 ?? 0; expense = model.Payment.EXPENSE.FY3.Q4 ?? 0; }
                            }

                            payments.Add(new T_Payment
                            {
                                AFD_ID = newAFDID,
                                Fiscal_Year = fiscalyear.ToString(),
                                Fiscal_Quarter = $"Q{q}",
                                Capital_Expense_Amount = capex,
                                Expense_Amount = expense
                            });
                        }
                    }

                    db_AFD.T_Payment.AddRange(payments);
                    db_AFD.SaveChanges();





                    // =====================================================================
                    //  GENERATE APPROVAL
                    // =====================================================================




                    // Ambil Form_AFD_ID berdasarkan AFD_ID
                    var formAfdIds = db_AFD.T_AFD
                                       .Where(x => x.AFD_ID == newAFDID)
                                       .Select(x => x.Form_AFD_ID);


                    var approvalSource = (
                                            from a in db_AFD.M_Rule_Approval
                                            join b in db_AFD.M_User_Access
                                               on a.Approver_NIK equals b.NIK into ab
                                            from b in ab.DefaultIfEmpty()
                                            where formAfdIds.Contains(a.Form_AFD_ID) && a.Cost_Section == model.CostSection
                                            orderby a.Approval_Step
                                            select new
                                            {
                                                a.Approval_Step,
                                                a.Approver_NIK
                                            }
                                            ).ToList();   // ⬅️ QUERY SELESAI DI DATABASE


                    var approvalData = approvalSource.Select(x => new T_Approval
                    {
                        AFD_ID = newAFDID,
                        Approval_Step = x.Approval_Step,
                        Approver_NIK = x.Approver_NIK
                    }).ToList();

                    // Insert ke T_Approval
                    db_AFD.T_Approval.AddRange(approvalData);
                    db_AFD.SaveChanges();




                    // =====================================================================
                    //  UPDATE TOTAL
                    // =====================================================================

                    decimal? totalCapex = payments.Sum(x => x.Capital_Expense_Amount);
                    decimal? totalExpense = payments.Sum(x => x.Expense_Amount);

                    var afd = db_AFD.T_AFD.Find(newAFDID);

                    afd.Capital_Expense_Amount = (double?)totalCapex;
                    afd.Expense_Amount = (double?)totalExpense;
                    //afd.Budget_Amount = (double?)totalCapex + (double?)totalExpense;


                    db_AFD.SaveChanges();



                    // =====================================================================
                    //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
                    // =====================================================================

                    string SaveAndRename(string base64, string originalName, string folderPath, string prefix)
                    {
                        if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
                            return "";

                        string cleanName = Path.GetFileName(originalName);
                        string originalPath = Path.Combine(folderPath, cleanName);

                        byte[] fileBytes = Convert.FromBase64String(base64);

                        // Pastikan jika file lama masih ada → hapus (unlock friendly)
                        if (System.IO.File.Exists(originalPath))
                        {
                            System.IO.File.SetAttributes(originalPath, FileAttributes.Normal);
                            System.IO.File.Delete(originalPath);
                        }

                        // SAVE FILE TANPA LOCK
                        using (var fs = new FileStream(originalPath, FileMode.Create, FileAccess.Write, FileShare.None))
                        {
                            fs.Write(fileBytes, 0, fileBytes.Length);
                        } // <-- file dijamin tertutup 100%

                        // Rename
                        string newFileName = $"{prefix}_{cleanName}";
                        string newFilePath = Path.Combine(folderPath, newFileName);

                        if (System.IO.File.Exists(newFilePath))
                        {
                            System.IO.File.SetAttributes(newFilePath, FileAttributes.Normal);
                            System.IO.File.Delete(newFilePath);
                        }

                        // MOVE TANPA LOCK
                        System.IO.File.Move(originalPath, newFilePath);

                        return newFileName;
                    }




                    string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                    var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";
                    if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

                    // Save + Rename fisik:
                    string overviewFile = SaveAndRename(
                        model.FileContentOverview,
                        model.FileNameContentOverview,
                        xFolder,
                        newAFDID + "_ContentOverview"
                    );

                    string scheduleFile = SaveAndRename(
                        model.FileSchedule,
                        model.FileNameSchedule,
                        xFolder,
                        newAFDID + "_Schedule"
                    );

                    string biddingFile = SaveAndRename(
                        model.FileBiddingDocument,
                        model.FileNameBiddingDocument,
                        xFolder,
                        newAFDID + "_Bidding"
                    );

                    var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == newAFDID);

                    if (afdAttachFile != null)
                    {
                        if (!string.IsNullOrEmpty(overviewFile))
                            afdAttachFile.Content_Overview = overviewFile;

                        if (!string.IsNullOrEmpty(scheduleFile))
                            afdAttachFile.Schedule = scheduleFile;

                        if (!string.IsNullOrEmpty(biddingFile))
                            afdAttachFile.Bidding_Document = biddingFile;

                        db_AFD.SaveChanges();
                    }
                     
                    // =====================================================================
                    //  INSERT HEADER BUDGET SHEET
                    // =====================================================================
                    //var dataHeaderBudgetSheet = new List<T_Budget_Sheet>
                    //{
                    //    new T_Budget_Sheet
                    //    {
                    //        AFD_ID = newAFDID,
                    //        Budget_Classification = "CAPITAL EXPENDITURE"
                    //    },
                    //    new T_Budget_Sheet
                    //    {
                    //        AFD_ID = newAFDID,
                    //        Budget_Classification = "EXPENSE"
                    //    }
                    //};

                    //db_AFD.T_Budget_Sheet.AddRange(dataHeaderBudgetSheet);
                    //db_AFD.SaveChanges();



                    // =====================================================================
                    //  INSERT LOG
                    // =====================================================================
                    T_Log dataLog = new T_Log()
                    {
                        AFD_ID = newAFDID,
                        Log_Action = "Save Draft",
                        Log_Date_Time = DateTime.Now,
                        Log_User_Id = model.NIKLogin,
                        Log_User_Ip = Request.UserHostAddress
                    };

                    db_AFD.T_Log.Add(dataLog);
                    db_AFD.SaveChanges();




                    // =====================================================================
                    //  RETURN + KIRIM AFD_ID KE FRONTEND
                    // =====================================================================

                    ViewBag.StatusData = "draft";
                    ViewBag.CoverLetterID = newAFDID;


                    // =====================================================================
                    //  COMMIT SEMUA PERUBAHAN
                    // =====================================================================
                    transaction.Commit();

                    return Json(new {
                        success = true, 
                        afd_id = newAFDID, 
                        status = "saved" 
                    });

                }
                catch (Exception ex)
                {
                    // ❌ ROLLBACK SEMUA
                    transaction.Rollback();

                    Response.StatusCode = 500;
                    return Json(new
                    {
                        success = false,
                        message = ex.Message
                    });
                }
            }
      }

 
        //[HttpPost]
        //public JsonResult SaveDataChanges(AFDCreateModel model)
        //{

            [HttpPost]
            public JsonResult SaveDataChanges(string model,
                                  HttpPostedFileBase fileContentOverview,
                                  HttpPostedFileBase fileSchedule,
                                  HttpPostedFileBase fileBiddingDocument)
            {
                var dataModel = JsonConvert.DeserializeObject<AFDCreateModel>(model);
           

            try
            {

                if (Session["NIK"] == null)
                {
                    return Json(new
                    {
                        status = "error",
                        message = "Session expired",
                        solution = "Please login again"
                    }, JsonRequestBehavior.AllowGet);
                }


                int CoverLetterID = Convert.ToInt32(dataModel.CoverLetterID);


                // Ambil data lama
                var data = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);


                if (data == null)
                {
                    return Json(new { success = false, message = "Data not found" });
                }

                // =====================================================================
                //  UPDATE HEADER
                // =====================================================================
                //data.Form_AFD_ID = model.FormAFDID;
                //data.Budget_Final_ID = model.AmountBudgetID;
                //data.Proposal_Date = model.DateOfProposal;
                //data.ExchangeRate_USD = (double)model.Rate;


                data.AFD_Title = dataModel.Title;  
                data.Place = dataModel.Place;
                data.Period_Commencement = dataModel.PeriodeCommencement;
                data.Period_Completion = dataModel.PeriodeCompletion;
                data.Purpose_Description = dataModel.PurposeDescription;
                data.Purpose_Type = dataModel.PurposeFor;
                data.Specification_Requisite = dataModel.RequisiteSpecification;
                data.Expected_Effect = dataModel.ExpectedEffect; 
                data.Decision_Status = dataModel.DecisionStatus;
                data.Disposal_Responsible = dataModel.DisposalResponsible;
                data.Budget_Type = dataModel.BudgetType;
                data.Budget_Amount = dataModel.AmountBudget;


                // audit update
                data.UpdateUserId = dataModel.NIKLogin;
                data.UpdateDateTime = DateTime.Now;
                data.UpdateIP = Request.UserHostAddress;

                db_AFD.SaveChanges();

                // =====================================================================
                //  Hapus detail payment lama
                // =====================================================================
                var oldPayments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterID).ToList();
                db_AFD.T_Payment.RemoveRange(oldPayments);
                db_AFD.SaveChanges();




                // =====================================================================
                //   Insert kembali payment FY1–FY3(12 baris)
                // =====================================================================

                var FY = int.Parse(dataModel.FiscalYear);

                var payments = new List<T_Payment>();

                for (int fy = 1; fy <= 3; fy++)
                {
                    for (int q = 1; q <= 4; q++)
                    {
                        decimal capex = 0;
                        decimal expense = 0;
                        int fiscalyear = FY;   // <-- default agar tidak unassigned


                        if (fy == 1)
                        {
                            if (q == 1) { capex = dataModel.Payment.CAPEX.FY1.Q1 ?? 0; expense = dataModel.Payment.EXPENSE.FY1.Q1 ?? 0; }
                            if (q == 2) { capex = dataModel.Payment.CAPEX.FY1.Q2 ?? 0; expense = dataModel.Payment.EXPENSE.FY1.Q2 ?? 0; }
                            if (q == 3) { capex = dataModel.Payment.CAPEX.FY1.Q3 ?? 0; expense = dataModel.Payment.EXPENSE.FY1.Q3 ?? 0; }
                            if (q == 4) { capex = dataModel.Payment.CAPEX.FY1.Q4 ?? 0; expense = dataModel.Payment.EXPENSE.FY1.Q4 ?? 0; }
                        }

                        if (fy == 2)
                        {
                            fiscalyear = FY + 1;
                            if (q == 1) { capex = dataModel.Payment.CAPEX.FY2.Q1 ?? 0; expense = dataModel.Payment.EXPENSE.FY2.Q1 ?? 0; }
                            if (q == 2) { capex = dataModel.Payment.CAPEX.FY2.Q2 ?? 0; expense = dataModel.Payment.EXPENSE.FY2.Q2 ?? 0; }
                            if (q == 3) { capex = dataModel.Payment.CAPEX.FY2.Q3 ?? 0; expense = dataModel.Payment.EXPENSE.FY2.Q3 ?? 0; }
                            if (q == 4) { capex = dataModel.Payment.CAPEX.FY2.Q4 ?? 0; expense = dataModel.Payment.EXPENSE.FY2.Q4 ?? 0; }
                        }

                        if (fy == 3)
                        {
                            fiscalyear = FY + 2;
                            if (q == 1) { capex = dataModel.Payment.CAPEX.FY3.Q1 ?? 0; expense = dataModel.Payment.EXPENSE.FY3.Q1 ?? 0; }
                            if (q == 2) { capex = dataModel.Payment.CAPEX.FY3.Q2 ?? 0; expense = dataModel.Payment.EXPENSE.FY3.Q2 ?? 0; }
                            if (q == 3) { capex = dataModel.Payment.CAPEX.FY3.Q3 ?? 0; expense = dataModel.Payment.EXPENSE.FY3.Q3 ?? 0; }
                            if (q == 4) { capex = dataModel.Payment.CAPEX.FY3.Q4 ?? 0; expense = dataModel.Payment.EXPENSE.FY3.Q4 ?? 0; }
                        }

                        payments.Add(new T_Payment
                        {
                            AFD_ID = CoverLetterID,
                            Fiscal_Year = fiscalyear.ToString(),
                            Fiscal_Quarter = $"Q{q}",
                            Capital_Expense_Amount = capex,
                            Expense_Amount = expense
                        });
                    }
                }

                db_AFD.T_Payment.AddRange(payments);
                db_AFD.SaveChanges();


                // =====================================================================
                //   Update total
                // ===================================================================== 
                data.Capital_Expense_Amount = (double?)(payments.Sum(x => x.Capital_Expense_Amount) ?? 0);
                data.Expense_Amount = (double?)(payments.Sum(x => x.Expense_Amount) ?? 0);
                //data.Budget_Amount = (decimal?)(data.Capital_Expense_Amount + data.Expense_Amount);
                 
                 


                db_AFD.SaveChanges();


                // =====================================================================
                //  INSERT LOG
                // =====================================================================
                T_Log dataLog = new T_Log()
                {
                    AFD_ID = CoverLetterID,
                    Log_Action = "Save Changes",
                    Log_Date_Time = DateTime.Now,
                    Log_User_Id = dataModel.NIKLogin,
                    Log_User_Ip = Request.UserHostAddress
                };

                db_AFD.T_Log.Add(dataLog);
                db_AFD.SaveChanges();


                // =====================================================================
                //   Update file (overwrite)
                // =====================================================================

                // =====================================================================
                //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
                // ===================================================================== 

                string SaveFile(HttpPostedFileBase file, string folderPath, string prefix)
                {
                    if (file == null || file.ContentLength == 0)
                        return "";

                    string cleanName = Path.GetFileName(file.FileName);
                    string newFileName = $"{prefix}_{cleanName}";
                    string fullPath = Path.Combine(folderPath, newFileName);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }

                    file.SaveAs(fullPath);

                    return newFileName;
                }




                string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                //var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";

                var xFolder = $"{SourceUploadDocumentAFD}\\FY{dataModel.FiscalYear}\\{dataModel.AFDType}\\{dataModel.AFDSubType}";
                if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

                // Save + Rename fisik: 
                String AttachUpload_1 = null;
                String AttachUpload_2 = null;
                String AttachUpload_3 = null;

                var afdType = (
                                from a in db_AFD.M_Form_AFD
                                where a.Form_AFD_ID == dataModel.FormAFDID
                                select a.AFD_Type
                                ).FirstOrDefault();


                if (afdType == "CAPITAL INVESTMENT")
                {
                    AttachUpload_1 = "_ContentOverview";
                    AttachUpload_2 = "_Schedule";
                    AttachUpload_3 = "_Bidding";
                }
                else if (afdType == "DISPOSAL")
                {
                    AttachUpload_1 = "_ListFixAsset";
                    AttachUpload_2 = "_Schedule";
                    AttachUpload_3 = "_Foto";
                }



                //if (fileContentOverview == null)
                //{
                //    throw new Exception("fileContentOverview tidak terkirim");
                //}

                string overviewFile = SaveFile(
                     fileContentOverview,
                     xFolder,
                     CoverLetterID + AttachUpload_1
                 );

                string scheduleFile = SaveFile(
                    fileSchedule,
                    xFolder,
                    CoverLetterID + AttachUpload_2
                );

                string biddingFile = SaveFile(
                    fileBiddingDocument,
                    xFolder,
                    CoverLetterID + AttachUpload_3
                );



                var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);

                if (afdAttachFile != null)
                {
                    if (!string.IsNullOrEmpty(overviewFile))
                        afdAttachFile.Content_Overview = overviewFile; 

                    if (!string.IsNullOrEmpty(scheduleFile))
                        afdAttachFile.Schedule = scheduleFile;

                    if (!string.IsNullOrEmpty(biddingFile))
                        afdAttachFile.Bidding_Document = biddingFile;

                    db_AFD.SaveChanges();

 
                }


                return Json(new { success = true, afd_id = CoverLetterID, attch1 = overviewFile, attch3 = scheduleFile, attch5 = biddingFile, }); 

            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = ex.Message });
            }
        }

        public JsonResult DeleteData(int CoverLetterId)
        {

            if (Session["NIK"] == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Session expired",
                    solution = "Please login again"
                }, JsonRequestBehavior.AllowGet);
            }



            var result = (from x in db_AFD.T_AFD
                          where x.Flag_Reapplication == null
                             && x.Flag_Draft == 1
                             && x.AFD_ID == CoverLetterId
                          select x).ToList();

            if (result == null || result.Count == 0)
            {
                return Json(new
                {
                    status = "error",
                    message = "Data cannot be deleted",
                    solution = "please contact the IS staff"
                }, JsonRequestBehavior.AllowGet);
            }

            // =====================================================================
            //  DELETE DATA PAYMENT
            // =====================================================================
            var payments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterId).ToList();
            if (payments.Any())
            {
                db_AFD.T_Payment.RemoveRange(payments);
            }



            // =====================================================================
            //  DELETE DATA AFD
            // =====================================================================
            var afd = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterId);
            if (afd != null)
            {
                db_AFD.T_AFD.Remove(afd);
            }

            // =====================================================================
            // DELETE DATA APPROVAL STEP
            // =====================================================================
            var approvalsteps = db_AFD.T_Approval
                                .Where(x => x.AFD_ID == CoverLetterId)
                                .ToList();

            if (approvalsteps.Any())
            {
                db_AFD.T_Approval.RemoveRange(approvalsteps);
            }


            // =====================================================================
            //  DELETE DATA BUDGET SHEET
            // =====================================================================
            var budgetsheet = (from a in db_AFD.T_Budget_Sheet
                        join b in db_AFD.T_Budget_Sheet_Detail
                            on a.Budget_Sheet_ID equals b.Budget_Sheet_ID into gj
                        from b in gj.DefaultIfEmpty()
                        where a.AFD_ID == 130
                        select a).Distinct().ToList();

            db_AFD.T_Budget_Sheet.RemoveRange(budgetsheet);
            db.SaveChanges();



            // =====================================================================
            //  INSERT LOG
            // =====================================================================
            T_Log dataLog = new T_Log()
            {
                AFD_ID = CoverLetterId,
                Log_Action = "Delete Data",
                Log_Date_Time = DateTime.Now,
                Log_User_Id = Session["NIK"].ToString(),
                Log_User_Ip = Request.UserHostAddress
            };

            db_AFD.T_Log.Add(dataLog);
            db_AFD.SaveChanges();








            db_AFD.SaveChanges();




            return Json(new
            {
                status = "success",
                message = "The data has been deleted successfully.",
                solution = ""
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SubmitData(int CoverLetterId, string DecisionDate, string DecisionNumber,string DecisionStatus)
        {
            var messageAlert = "";

            if (Session["NIK"] == null)
            {
                return Json(new
                {
                    status = "error",
                    message = "Session expired",
                    solution = "Please login again"
                }, JsonRequestBehavior.AllowGet);
            }

            var ExecuteSendEmailNotification = "";
            string NIKlogin = Session["NIK"]?.ToString();
            var data = db_AFD.T_Approval .FirstOrDefault(x => x.AFD_ID == CoverLetterId && x.Approver_NIK == NIKlogin);
            if (data == null)
            {
                return Json(new { success = false, message = "Data not found" });
            }
             
            if (string.IsNullOrEmpty(NIKlogin))
            {
                return Json(new { success = false, message = "Session expired" });
            }

            string userIP = Request.UserHostAddress ?? "";

            // UPDATE APPROVAL

            data.Updated_DateTime = DateTime.Now;
            data.Updated_User_Id = NIKlogin;
            data.Updated_User_IP = userIP;


            // =====================================================================
            //  UPDATE FLAG DRAFT
            // =====================================================================

            var data2 = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterId);

            var Flag_Create = db_AFD.M_User_Access
            .Where(x => x.NIK == NIKlogin)
            .Select(x => (int?)x.Flag_Create)
            .FirstOrDefault() ?? 0;

            if (Flag_Create == 1 ) { 
             
                if (data2 == null)
                {
                    return Json(new { success = false, message = "Data not found" });
                } 
                data2.Flag_Draft = 0;
                  
            }
            //end of  

            // =====================================================================
            //  UPDATE DECISION NUMBER & DATE
            // =====================================================================
              
            if (!string.IsNullOrEmpty(DecisionNumber) &&  !DecisionNumber.Equals("NOT USE", StringComparison.OrdinalIgnoreCase))
            {
                data2.Decision_Number = DecisionNumber;
                data2.Flag_Close_Approval = 1;

                if (!string.IsNullOrEmpty(DecisionDate))
                {
                    if (DateTime.TryParse(DecisionDate, out DateTime dt))
                    {
                        data2.Decision_Date = dt;
                    }
                    else
                    {
                        data2.Decision_Date = null; // atau handle error
                    }
                }

                messageAlert = "Approval has been successfully closed";
            }


            //end of


            // =====================================================================
            //  UPDATE DECISION STATUS
            // =====================================================================

            if (!string.IsNullOrEmpty(DecisionStatus) && !DecisionStatus.Equals("NOT USE", StringComparison.OrdinalIgnoreCase))
            {
                data2.Decision_Status = DecisionStatus;
                messageAlert = "Data successfully sent for approval";


                //=====================================================
                //SEND NOTIFICATION
                //=====================================================
                ExecuteSendEmailNotification = "EXEC [dbo].[SP_SendMailNotification]   " + CoverLetterId + ",'Set Decision Number','" + NIKlogin + "'";
                db_AFD.Database.ExecuteSqlCommand(ExecuteSendEmailNotification);
            }
            else {



                //=====================================================
                //SEND NOTIFICATION
                //=====================================================
                ExecuteSendEmailNotification = "EXEC [dbo].[SP_SendMailNotification]   " + CoverLetterId + ",'Submit Approval','" + NIKlogin + "'";
                db_AFD.Database.ExecuteSqlCommand(ExecuteSendEmailNotification);

            }

            //end of




            // =====================================================================
            //  INSERT LOG
            // =====================================================================
            T_Log dataLog = new T_Log()
            {
                AFD_ID = CoverLetterId,
                Log_Action = "Submit Approval",
                Log_Date_Time = DateTime.Now,
                Log_User_Id = NIKlogin,
                Log_User_Ip = Request.UserHostAddress
            };

            db_AFD.T_Log.Add(dataLog);

            db_AFD.SaveChanges();




            if (messageAlert == "") {
                messageAlert = "Data successfully sent for approval";
            }

            return Json(new
            {
                status = "success",
                message = messageAlert,
                solution = ""
            }, JsonRequestBehavior.AllowGet);
        }

          

        [HttpPost]
        public JsonResult ReturnData(Return model)
        {
            try
            {
                if (Session["NIK"] == null)
                {
                    return Json(new
                    {
                        status = "error",
                        message = "Session expired",
                        solution = "Please login again"
                    });
                }

                string NIKlogin = Session["NIK"].ToString();
                string userIP = Request?.UserHostAddress ?? "";

                using (var trx = db_AFD.Database.BeginTransaction())
                {
                    try
                    {
                        // =====================================================
                        // UPDATE DATA APPROVAL
                        // =====================================================
                        var listApproval = db_AFD.T_Approval
                            .Where(x => x.AFD_ID == model.CoverLetterId)
                            .ToList();

                        if (!listApproval.Any())
                        {
                            return Json(new { status = "error", message = "Approval data not found" });
                        }

                        foreach (var approval in listApproval)
                        {
                            approval.Updated_DateTime = null;
                            approval.Updated_User_Id = null;
                            approval.Updated_User_IP = null;
                        }

                        // =====================================================
                        // UPDATE FLAG DRAFT
                        // =====================================================
                        var dataAFD = db_AFD.T_AFD
                            .FirstOrDefault(x => x.AFD_ID == model.CoverLetterId);

                        if (dataAFD == null)
                        {
                            return Json(new { status = "error", message = "Data not found" });
                        }

                        dataAFD.Flag_Draft = 1;
                        dataAFD.Decision_Status = null;

                        // =====================================================
                        // INSERT LOG
                        // =====================================================
                        T_Log dataLog = new T_Log()
                        {
                            AFD_ID = model.CoverLetterId,
                            Log_Action = "Return",
                            Log_Date_Time = DateTime.Now,
                            Log_User_Id = NIKlogin,
                            Log_User_Ip = userIP
                        };

                        db_AFD.T_Log.Add(dataLog);
                        db_AFD.SaveChanges(); // supaya Log_Activity_ID ter-generate

                      

                        // =====================================================
                        // SAVE FILE & RENAME
                        // =====================================================
                        string SaveAndRename(
                            string base64,
                            string originalName,
                            string folderPath,
                            string prefix)
                        {
                            if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
                                return "";

                            // bersihkan prefix base64
                            if (base64.Contains(","))
                                base64 = base64.Substring(base64.IndexOf(",") + 1);

                            string cleanName = Path.GetFileName(originalName);
                            byte[] fileBytes = Convert.FromBase64String(base64);

                            if (!Directory.Exists(folderPath))
                                Directory.CreateDirectory(folderPath);

                            string newFileName = $"{prefix}_{cleanName}";
                            string fullPath = Path.Combine(folderPath, newFileName);

                            if (System.IO.File.Exists(fullPath))
                            {
                                System.IO.File.SetAttributes(fullPath, FileAttributes.Normal);
                                System.IO.File.Delete(fullPath);
                            }

                            using (var fs = new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                fs.Write(fileBytes, 0, fileBytes.Length);
                            }

                            return newFileName;
                        }

                        string SourceUploadDocumentAFD =
                            System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

                        string xFolder = Path.Combine(
                            SourceUploadDocumentAFD,
                            $"FY{model.FiscalYear}",
                            model.AFDType,
                            model.AFDSubType
                        );

                        string returnFile = SaveAndRename(
                            model.FileBase64Return,
                            model.FileNameReturn,
                            xFolder,
                            model.CoverLetterId + "_Return"
                        );

                        if (!string.IsNullOrEmpty(returnFile))
                        {
                            // =====================================================
                            // INSERT RETURN DATA
                            // =====================================================
                            T_Return dataReturn = new T_Return()
                            {
                                Log_Activity_ID = dataLog.Log_Activity_ID,
                                Description = model.ReturnReason,
                                Return_Document = returnFile
                            };

                            db_AFD.T_Return.Add(dataReturn);
                        }

                        db_AFD.SaveChanges();


                        // =====================================================
                        // SEND NOTIFICATION
                        // =====================================================
                        var ExecuteSendEmailNotification = "EXEC [dbo].[SP_SendMailNotification]   " + model.CoverLetterId + ",'Return','" + NIKlogin + "'";
                        db_AFD.Database.ExecuteSqlCommand(ExecuteSendEmailNotification);


                        trx.Commit();

                        return Json(new
                        {
                            status = "success",
                            message = "The reason for your return has been informed to the coordinator",
                            solution = ""
                        });
                    }
                    catch
                    {
                        trx.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    status = "error",
                    message = "Internal Server Error",
                    solution = ex.Message
                });
            }
        }


        public ActionResult PrintCoverLetter(string CoverLetterId)
        {
            ViewBag.xCoverLetterID = CoverLetterId.ToString();

            List<PrintCoverLetter> DataHeaderCoverLetter = new List<PrintCoverLetter>();
            var xDataHeaderCoverLetter = "EXEC SP_PrintCoverLetter " + CoverLetterId + ", 'Main'";
            DataHeaderCoverLetter = db_AFD.Database.SqlQuery<PrintCoverLetter>(xDataHeaderCoverLetter).ToList(); 
            ViewBag.HeaderCoverLetter = DataHeaderCoverLetter;


            List<PrintSignature> DataSignature = new List<PrintSignature>();
            var xDataSignature = "EXEC SP_PrintCoverLetter " + CoverLetterId + ", 'Signature'";
            DataSignature = db_AFD.Database.SqlQuery<PrintSignature>(xDataSignature).ToList();
            ViewBag.Signature = DataSignature;

             
            List<PrintPayment> DataPayment = new List<PrintPayment>(); 
            var xDataPayment = "EXEC SP_PrintCoverLetter " + CoverLetterId + ", 'Payment'";
            DataPayment = db_AFD.Database
                                .SqlQuery<PrintPayment>(xDataPayment)
                                .ToList();

            // simpan ke ViewBag
            ViewBag.PaymentData = DataPayment;

            // ambil Fiscal Year unik (BENAR)
            ViewBag.Years = DataPayment
                            .Select(x => x.Fiscal_Year)
                            .Distinct()
                            .OrderBy(x => x)
                            .ToList();

            return View();
        }


  

        //==**
        //==*******
        //==*********
        //==***********
        //==************* 
        //==*************** 
        //==******************************************************************************************************************************************==// 
        //==============================================================List OF STATUS PROGRESS========================================================//
        //==******************************************************************************************************************************************==// 


        public ActionResult IndexListStatusAFD(string mode)
        {
             
            var fiscalYears = db_AFD.T_AFD
                .Select(x => x.Fiscal_Year)
                .Distinct()
                .OrderByDescending(x => x)
                .ToList();

            var AFDType = db_AFD.M_Form_AFD
            .Select(x => x.AFD_Type)
            .Distinct() 
            .ToList();



            string sqldeptNames = @"  SELECT DISTINCT m.dept_name FROM DATA_WH..M_Fix_Cost_Matrix m WHERE m.cost_section_code IN (SELECT Cost_Section FROM T_AFD)";
            var deptNames = db_AFD.Database
                .SqlQuery<string>(sqldeptNames)
                .ToList();

            ViewBag.LastFiscalYear = fiscalYears.Last(); 
            ViewBag.FiscalYears = fiscalYears;
            ViewBag.AFDType = AFDType;
            ViewBag.deptNames = deptNames;

            return View();
        }

        public JsonResult DDLCostSection(string dept)
        {

            string sqldeptNames = @" SELECT DISTINCT Cost_Section FROM T_AFD WHERE Cost_Section IN (SELECT DISTINCT cost_section_code FROM DATA_WH ..M_Fix_Cost_Matrix WHERE dept_name = '" + dept + "')";
            var data = db_AFD.Database
                .SqlQuery<string>(sqldeptNames)
                .ToList();



            return Json(data, JsonRequestBehavior.AllowGet);


        }
 
        public JsonResult GetListProgressAFD(string fiscalYear,string typeAFD, string department,string costSection)
        {

       string NIKlogin = Session["NIK"].ToString();

       var data = db_AFD.Database.SqlQuery<ListProgressAFD>(
       "EXEC SP_ListOfStatus @FiscalYear, @TypeAFD, @Department, @CostSection, @NIKLogin",
       new SqlParameter("@FiscalYear", (object)fiscalYear ?? DBNull.Value),
       new SqlParameter("@TypeAFD", (object)typeAFD ?? DBNull.Value),
       new SqlParameter("@Department", (object)department ?? DBNull.Value),
       new SqlParameter("@CostSection", (object)costSection ?? DBNull.Value),
       new SqlParameter("@NIKLogin", (object)NIKlogin ?? DBNull.Value)
       ).ToList();



            return Json(data, JsonRequestBehavior.AllowGet);
             
        }
        
        
        [HttpPost]
        public JsonResult ReApplication(int coverLetterId,string title)
        {
            try
            {

                string NIKlogin = Session["NIK"].ToString();

                var dataAFD = db_AFD.T_AFD
                    .FirstOrDefault(x => x.AFD_ID == coverLetterId);

                if (dataAFD == null)
                {
                    return Json(new { success = false, message = "Data not found" });
                }

                // Set flag reapplication
                dataAFD.AFD_Title = "REAPPLICATION " + title;
                dataAFD.Flag_Reapplication = 1;
                dataAFD.Flag_Draft = 1; 
                dataAFD.Flag_Close_Approval = 0;
                dataAFD.Decision_Status = null;

                // Ambil semua approval
                var listApproval = db_AFD.T_Approval
                    .Where(x => x.AFD_ID == coverLetterId)
                    .ToList();

                if (!listApproval.Any())
                {
                    return Json(new { success = false, message = "Approval data not found" });
                }

                // Reset approval data
                foreach (var approval in listApproval)
                {
                    approval.Updated_DateTime = null;
                    approval.Updated_User_Id = null;
                    approval.Updated_User_IP = null;
                }

                db_AFD.SaveChanges();

                // =====================================================
                // SEND NOTIFICATION
                // =====================================================
                var ExecuteSendEmailNotification = "EXEC [dbo].[SP_SendMailNotification]   " + coverLetterId + ",'Re-Application','" + NIKlogin + "'";
                db_AFD.Database.ExecuteSqlCommand(ExecuteSendEmailNotification);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = ex.Message });
            }
        }



        //==**
        //==*******
        //==*********
        //==***********
        //==************* 
        //==*************** 
        //==******************************************************************************************************************************************==// 
        //==============================================================Budget Sheet========================================================//
        //==******************************************************************************************************************************************==// 

        public ActionResult IndexBudgetSheet(int CoverLetterId)
        {

            string NIKlogin = Session["NIK"].ToString();
            ViewBag.NIKLogin = NIKlogin; 
  

            var flagCreate = db_AFD.T_AFD
            .Where(x => x.AFD_ID == CoverLetterId
            && x.CreateUserId == NIKlogin)
            .ToList(); 
            ViewBag.xflagcreate = flagCreate.Count > 0 ? 1 : 0;





            var flagDraft = db_AFD.T_AFD
                         .Where(x => x.AFD_ID == CoverLetterId)
                         .Select(x => (int?)x.Flag_Draft)
                         .FirstOrDefault() ?? 0;
            ViewBag.xflagdraft = flagDraft;



            var afdData = db_AFD.T_AFD
                .Where(x => x.AFD_ID == CoverLetterId)
                .Select(x => new
                {
                    AFD_ID = x.AFD_ID,
                    AFD_Title = x.AFD_Title,
                    Budget_Amount = x.Budget_Amount,
                    Budget_Used = (x.Capital_Expense_Amount ?? 0)
                                  + (x.Expense_Amount ?? 0)
                })
                .FirstOrDefault();


            var dataBudgetSheetAmount =
     from a in db_AFD.T_Budget_Sheet
     join b in db_AFD.T_Budget_Sheet_Detail
         on a.Budget_Sheet_ID equals b.Budget_Sheet_ID into bs
     from b in bs.DefaultIfEmpty()
     where a.AFD_ID == CoverLetterId
     group b by a.Budget_Classification into g
     select new
     {
         Budget_Classification = g.Key,
         Amount =
             g.Sum(x => (x.Mech_Machine_Import ?? 0)) +
             g.Sum(x => (x.Mech_Machine_Local ?? 0)) +
             g.Sum(x => (x.Mech_Construction ?? 0)) +
             g.Sum(x => (x.Elec_Machine_Import ?? 0)) +
             g.Sum(x => (x.Elec_Machine_Local ?? 0)) +
             g.Sum(x => (x.Elec_Construction ?? 0)) +
             g.Sum(x => (x.Inst_Machine_Import ?? 0)) +
             g.Sum(x => (x.Inst_Machine_Local ?? 0)) +
             g.Sum(x => (x.Inst_Construction ?? 0)) +
             g.Sum(x => (x.Civil_Construction ?? 0))
     };





            if (afdData != null)
            {
                ViewBag.AFD_ID = afdData.AFD_ID;
                ViewBag.AFD_Title = afdData.AFD_Title;
                ViewBag.AFD_AmountBudgetFinal = afdData.Budget_Amount;
                ViewBag.Budget_Used = afdData.Budget_Used;

                ViewBag.EXPENSE = dataBudgetSheetAmount
                                .Where(x => x.Budget_Classification == "EXPENSE")
                                .Select(x => x.Amount)
                                .FirstOrDefault();

                ViewBag.CAPITAL_EXPENDITURE = dataBudgetSheetAmount
                                            .Where(x => x.Budget_Classification == "CAPITAL EXPENDITURE")
                                            .Select(x => x.Amount)
                                            .FirstOrDefault(); 
            }





            var result =
           (
               from A in db_AFD.T_Budget_Sheet
               join B in db_AFD.T_Budget_Sheet_Detail
                   on A.Budget_Sheet_ID equals B.Budget_Sheet_ID into gj
               from B in gj.DefaultIfEmpty() // LEFT JOIN
               where A.AFD_ID == CoverLetterId
               select new
               {
                   BudgetSheet = A,
                   BudgetSheetDetail = B
               }
           ).FirstOrDefault();

            return View();
        }


        [HttpPost]
        public ActionResult GetBudgetSheetByClassification(BudgetSheetRequestByClassification model)
        {
            int afdId = model.AfdId;
            string classification = model.BudgetClassification;

            var data = (
                        from h in db_AFD.T_Budget_Sheet
                        join d in db_AFD.T_Budget_Sheet_Detail
                            on h.Budget_Sheet_ID equals d.Budget_Sheet_ID
                        where h.AFD_ID == afdId
                           && h.Budget_Classification == classification
                        select new
                        {
                            d.Budget_Sheet_Detail_ID,
                            d.Budget_Sheet_ID,
                            d.Budget_Item,

                            d.Mech_Machine_Import,
                            d.Mech_Machine_Local,
                            d.Mech_Construction,

                            d.Elec_Machine_Import,
                            d.Elec_Machine_Local,
                            d.Elec_Construction,

                            d.Inst_Machine_Import,
                            d.Inst_Machine_Local,
                            d.Inst_Construction,

                            d.Civil_Construction,
                            d.Remark
                        }
                    ).ToList();



            return Json(data, JsonRequestBehavior.AllowGet);

        }

         
        [HttpPost]
        public ActionResult SaveBudgetSheet(BudgetSheetSave model)
        {
            if (model.Items == null || !model.Items.Any())
            {
                return Json(new { success = false, message = "No data to save" });
            }

            int afdId = model.AfdId;
            string budgetClassification = model.BudgetClassification;
            var budgetItems = model.Items;

            using (var trx = db_AFD.Database.BeginTransaction())
            {
                try
                {
                    string NIKlogin = Session["NIK"]?.ToString();

                    if (string.IsNullOrEmpty(NIKlogin))
                        throw new Exception("Session expired");

                    // DELETE
                    //var budgetSheetIds = db_AFD.T_Budget_Sheet
                    //    .Where(x => x.AFD_ID == afdId)
                    //    .Select(x => x.Budget_Sheet_ID)
                    //    .ToList();

                    var budgetSheetIds = db_AFD.T_Budget_Sheet
                                        .Where(x => x.AFD_ID == afdId &&  x.Budget_Classification == budgetClassification)
                                        .Select(x => x.Budget_Sheet_ID)
                                        .ToList();



                    var details = db_AFD.T_Budget_Sheet_Detail
                        .Where(d => d.Budget_Sheet_ID.HasValue &&
                                    budgetSheetIds.Contains(d.Budget_Sheet_ID.Value))
                        .ToList();

                    db_AFD.T_Budget_Sheet_Detail.RemoveRange(details);
                    db_AFD.T_Budget_Sheet.RemoveRange(
                        db_AFD.T_Budget_Sheet.Where(x => x.AFD_ID == afdId && x.Budget_Classification == budgetClassification)
                    );

                    db_AFD.SaveChanges();

                    // HEADER
                    var header = new T_Budget_Sheet
                    {
                        AFD_ID = afdId,
                        Budget_Classification = budgetClassification,
                        CreateDateTime = DateTime.Now,
                        CreateUserId = NIKlogin,
                        CreateIP = Request.UserHostAddress
                    };

                    db_AFD.T_Budget_Sheet.Add(header);
                    db_AFD.SaveChanges();

                    // DETAIL
                    foreach (var item in budgetItems)
                    {
                        db_AFD.T_Budget_Sheet_Detail.Add(new T_Budget_Sheet_Detail
                        {
                            Budget_Sheet_ID = header.Budget_Sheet_ID,
                            Budget_Item = item.ItemName,

                            Mech_Machine_Import = item.MechMachImport,
                            Mech_Machine_Local = item.MechMachLocal,
                            Mech_Construction = item.MechCons,

                            Elec_Machine_Import = item.ElecMachImport,
                            Elec_Machine_Local = item.ElecMachLocal,
                            Elec_Construction = item.ElecCons,

                            Inst_Machine_Import = item.InstMachImport,
                            Inst_Machine_Local = item.InstMachLocal,
                            Inst_Construction = item.InstCons,

                            Civil_Construction = item.CivilCons,
                            Remark = item.Remark
                        });
                    }

                    db_AFD.SaveChanges();
                    trx.Commit();

                    return Json(new { success = true });
                }
                catch (Exception ex)
                {
                    trx.Rollback();
                    return Json(new { success = false, message = ex.Message });
                }
            }
        }


        public ActionResult PrintBudgetSheet(string CoverLetterId)
        { 

            List<PrintCoverLetter> DataHeaderCoverLetter = new List<PrintCoverLetter>();
            var xDataHeaderCoverLetter = "EXEC [SP_PrintCoverLetter] " + CoverLetterId + ",'Main'";
            DataHeaderCoverLetter = db_AFD.Database.SqlQuery<PrintCoverLetter>(xDataHeaderCoverLetter).ToList();
            ViewBag.HeaderCoverLetter = DataHeaderCoverLetter;
             


            List<PrintBudgetSheetbyClassification> DataBudgetSheetbyClassification = new List<PrintBudgetSheetbyClassification>();
            var xDataBudgetSheetbyClassification = "EXEC SP_PrintBudgetSheet " + CoverLetterId + "";
            DataBudgetSheetbyClassification = db_AFD.Database
                                .SqlQuery<PrintBudgetSheetbyClassification>(xDataBudgetSheetbyClassification)
                                .ToList(); 
            ViewBag.BudgetSheet = DataBudgetSheetbyClassification;



            return View();


        }



        //==**
        //==*******
        //==*********
        //==***********
        //==************* 
        //==*************** 
        //==******************************************************************************************************************************************==// 
        //==============================================================VA Report========================================================//
        //==******************************************************************************************************************************************==// 


        public ActionResult IndexVAReport(int CoverLetterId)
        {

            string NIKlogin = Session["NIK"].ToString();
            ViewBag.NIKLogin = NIKlogin;

              
            var flagCreate = db_AFD.T_AFD
            .Where(x => x.AFD_ID == CoverLetterId
            && x.CreateUserId == NIKlogin)
            .ToList();
            ViewBag.xflagcreate = flagCreate.Count > 0 ? 1 : 0;




            var flagDraft = db_AFD.T_AFD
                        .Where(x => x.AFD_ID == CoverLetterId)
                        .Select(x => (int?)x.Flag_Draft)
                        .FirstOrDefault() ?? 0;
            ViewBag.xflagdraft = flagDraft;



            var afdData = db_AFD.T_AFD
                .Where(x => x.AFD_ID == CoverLetterId)
                .Select(x => new
                {
                    AFD_ID = x.AFD_ID,
                    AFD_Title = x.AFD_Title,
                    Budget_Amount = x.Budget_Amount,
                    Budget_Used = (x.Capital_Expense_Amount ?? 0)
                                  + (x.Expense_Amount ?? 0)
                })
                .FirstOrDefault();


            var dataBudgetSheetAmount =
     from a in db_AFD.T_Budget_Sheet
     join b in db_AFD.T_Budget_Sheet_Detail
         on a.Budget_Sheet_ID equals b.Budget_Sheet_ID into bs
     from b in bs.DefaultIfEmpty()
     where a.AFD_ID == CoverLetterId
     group b by a.Budget_Classification into g
     select new
     {
         Budget_Classification = g.Key,
         Amount =
             g.Sum(x => (x.Mech_Machine_Import ?? 0)) +
             g.Sum(x => (x.Mech_Machine_Local ?? 0)) +
             g.Sum(x => (x.Mech_Construction ?? 0)) +
             g.Sum(x => (x.Elec_Machine_Import ?? 0)) +
             g.Sum(x => (x.Elec_Machine_Local ?? 0)) +
             g.Sum(x => (x.Elec_Construction ?? 0)) +
             g.Sum(x => (x.Inst_Machine_Import ?? 0)) +
             g.Sum(x => (x.Inst_Machine_Local ?? 0)) +
             g.Sum(x => (x.Inst_Construction ?? 0)) +
             g.Sum(x => (x.Civil_Construction ?? 0))
     };





            if (afdData != null)
            {
                ViewBag.AFD_ID = afdData.AFD_ID;
                ViewBag.AFD_Title = afdData.AFD_Title;
                ViewBag.AFD_AmountBudgetFinal = afdData.Budget_Amount;
                ViewBag.Budget_Used = afdData.Budget_Used;

                ViewBag.EXPENSE = dataBudgetSheetAmount
                                .Where(x => x.Budget_Classification == "EXPENSE")
                                .Select(x => x.Amount)
                                .FirstOrDefault();

                ViewBag.CAPITAL_EXPENDITURE = dataBudgetSheetAmount
                                            .Where(x => x.Budget_Classification == "CAPITAL EXPENDITURE")
                                            .Select(x => x.Amount)
                                            .FirstOrDefault();
            }





            var result =
           (
               from A in db_AFD.T_Budget_Sheet
               join B in db_AFD.T_Budget_Sheet_Detail
                   on A.Budget_Sheet_ID equals B.Budget_Sheet_ID into gj
               from B in gj.DefaultIfEmpty() // LEFT JOIN
               where A.AFD_ID == CoverLetterId
               select new
               {
                   BudgetSheet = A,
                   BudgetSheetDetail = B
               }
           ).FirstOrDefault();

            return View();
        }
         
        [HttpPost]
        public ActionResult GetVAReport(VAReportRequest model)
        {

            int afdId = model.AfdId; 
            var data = (
                        from h in db_AFD.T_VA_Report
                        join d in db_AFD.T_VA_Report_Detail
                            on h.VA_Report_ID equals d.VA_Report_ID
                        where h.AFD_ID == afdId 
                        select new
                        { 
                            d.VA_Item, 
                            d.Amount_Before_VA,
                            d.Amount_After_VA,
                            d.VA_Capital_Expenditure,
                            d.VA_Expense,
                            d.VA_Content
                        }
                    ).ToList();

             
            return Json(data, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult SaveVAReport(VAReportSave model)
        {
            if (model.Items == null || !model.Items.Any())
            {
                return Json(new { success = false, message = "No data to save" });
            }

            int afdId = model.AfdId; 
            var VAReportItems = model.Items;
            var VAEffect = model.EffectVA;
            var VAReductionRatio = model.ReductionRatioVA;

            using (var trx = db_AFD.Database.BeginTransaction())
            {
                try
                {
                    string NIKlogin = Session["NIK"]?.ToString();

                    if (string.IsNullOrEmpty(NIKlogin))
                        throw new Exception("Session expired");

                  
                    var VAReportIds = db_AFD.T_VA_Report
                                        .Where(x => x.AFD_ID == afdId)
                                        .Select(x => x.VA_Report_ID)
                                        .ToList();



                    var details = db_AFD.T_VA_Report_Detail
                        .Where(d => d.VA_Report_ID.HasValue &&
                                    VAReportIds.Contains(d.VA_Report_ID.Value))
                        .ToList();

                    db_AFD.T_VA_Report_Detail.RemoveRange(details);
                    db_AFD.T_VA_Report.RemoveRange(
                        db_AFD.T_VA_Report.Where(x => x.AFD_ID == afdId)
                    );

                    db_AFD.SaveChanges();

                    // HEADER
                    var header = new T_VA_Report
                    {
                        AFD_ID = afdId, 
                        VA_Effect = VAEffect ,
                        VA_Reduction_Ratio =VAReductionRatio , 
                        CreateDateTime = DateTime.Now,
                        CreateUserId = NIKlogin,
                        CreateIP = Request.UserHostAddress
                    };

                    db_AFD.T_VA_Report.Add(header);
                    db_AFD.SaveChanges();

                    // DETAIL
                    foreach (var item in VAReportItems)
                    {
                        db_AFD.T_VA_Report_Detail.Add(new T_VA_Report_Detail
                        {
                            VA_Report_ID = header.VA_Report_ID,
                            VA_Item = item.ItemName,
                            Amount_Before_VA = item.BeforeVA,
                            Amount_After_VA = item.AfterVA,
                            VA_Capital_Expenditure = item.VAamountCAPEX,  
                            VA_Expense = item.VAamountEXPENSE,  
                            VA_Content = item.Content
                        });
                    }

                    db_AFD.SaveChanges();
                    trx.Commit();

                    return Json(new { success = true });
                }
                catch (Exception ex)
                {
                    trx.Rollback();
                    return Json(new { success = false, message = ex.Message });
                }
            }
        }

        public ActionResult PrintVAReport(string CoverLetterId)
        {

            List<PrintCoverLetter> DataHeaderCoverLetter = new List<PrintCoverLetter>();
            var xDataHeaderCoverLetter = "EXEC [SP_PrintCoverLetter] " + CoverLetterId + ",'Main'";
            DataHeaderCoverLetter = db_AFD.Database.SqlQuery<PrintCoverLetter>(xDataHeaderCoverLetter).ToList();
            ViewBag.HeaderCoverLetter = DataHeaderCoverLetter;



            List<PrintVAReport> DataVAReport = new List<PrintVAReport>();
            var xDataPrintVAReport = "EXEC SP_PrintVAReport " + CoverLetterId + "";
            DataVAReport = db_AFD.Database
                                .SqlQuery<PrintVAReport>(xDataPrintVAReport)
                                .ToList();
            ViewBag.VAReport = DataVAReport;



            return View();


        }











        //SEPERTINYA TIDAK DIGUNAKAN

        //[HttpPost]
        //public JsonResult SubmitApproval(AFDCreateModel model)
        //{
        //    try
        //    {

        //        int CoverLetterID = Convert.ToInt32(model.CoverLetterID);


        //        // Ambil data lama
        //        var data = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);

        //        var NIKLogin = model.NIKLogin;

        //        if (data == null)
        //        {
        //            return Json(new { success = false, message = "Data not found" });
        //        }

        //        // =====================================================================
        //        //  UPDATE HEADER
        //        // =====================================================================
        //        data.Form_AFD_ID = model.FormAFDID;
        //        data.Budget_Final_ID = model.AmountBudgetID;
        //        data.Proposal_Date = model.DateOfProposal;
        //        data.AFD_Title = model.Title;

        //        data.ExchangeRate_USD = (double)model.Rate;
        //        data.Place = model.Place;
        //        data.Period_Commencement = model.PeriodeCommencement;
        //        data.Period_Completion = model.PeriodeCompletion;
        //        data.Purpose_Description = model.PurposeDescription;
        //        data.Specification_Requisite = model.RequisiteSpecification;
        //        data.Expected_Effect = model.ExpectedEffect;
        //        data.Coordinator_Name = model.CoordinatorName;
        //        data.Coordinator_Section = model.CoordinatorSection;
        //        data.Decision_Status = model.DecisionStatus;
        //        data.Disposal_Responsible = model.DisposalResponsible;

        //        // audit update
        //        data.UpdateUserId = model.NIKLogin;
        //        data.UpdateDateTime = DateTime.Now;
        //        data.UpdateIP = Request.UserHostAddress;

        //        db_AFD.SaveChanges();

        //        // =====================================================================
        //        //  Hapus detail payment lama
        //        // =====================================================================
        //        var oldPayments = db_AFD.T_Payment.Where(x => x.AFD_ID == CoverLetterID).ToList();
        //        db_AFD.T_Payment.RemoveRange(oldPayments);
        //        db_AFD.SaveChanges();




        //        // =====================================================================
        //        //   Insert kembali payment FY1–FY3(12 baris)
        //        // =====================================================================

        //        var FY = int.Parse(model.FiscalYear);

        //        var payments = new List<T_Payment>();

        //        for (int fy = 1; fy <= 3; fy++)
        //        {
        //            for (int q = 1; q <= 4; q++)
        //            {
        //                decimal capex = 0;
        //                decimal expense = 0;
        //                int fiscalyear = FY;   // <-- default agar tidak unassigned


        //                if (fy == 1)
        //                {
        //                    if (q == 1) { capex = model.Payment.CAPEX.FY1.Q1 ?? 0; expense = model.Payment.EXPENSE.FY1.Q1 ?? 0; }
        //                    if (q == 2) { capex = model.Payment.CAPEX.FY1.Q2 ?? 0; expense = model.Payment.EXPENSE.FY1.Q2 ?? 0; }
        //                    if (q == 3) { capex = model.Payment.CAPEX.FY1.Q3 ?? 0; expense = model.Payment.EXPENSE.FY1.Q3 ?? 0; }
        //                    if (q == 4) { capex = model.Payment.CAPEX.FY1.Q4 ?? 0; expense = model.Payment.EXPENSE.FY1.Q4 ?? 0; }
        //                }

        //                if (fy == 2)
        //                {
        //                    fiscalyear = FY + 1;
        //                    if (q == 1) { capex = model.Payment.CAPEX.FY2.Q1 ?? 0; expense = model.Payment.EXPENSE.FY2.Q1 ?? 0; }
        //                    if (q == 2) { capex = model.Payment.CAPEX.FY2.Q2 ?? 0; expense = model.Payment.EXPENSE.FY2.Q2 ?? 0; }
        //                    if (q == 3) { capex = model.Payment.CAPEX.FY2.Q3 ?? 0; expense = model.Payment.EXPENSE.FY2.Q3 ?? 0; }
        //                    if (q == 4) { capex = model.Payment.CAPEX.FY2.Q4 ?? 0; expense = model.Payment.EXPENSE.FY2.Q4 ?? 0; }
        //                }

        //                if (fy == 3)
        //                {
        //                    fiscalyear = FY + 2;
        //                    if (q == 1) { capex = model.Payment.CAPEX.FY3.Q1 ?? 0; expense = model.Payment.EXPENSE.FY3.Q1 ?? 0; }
        //                    if (q == 2) { capex = model.Payment.CAPEX.FY3.Q2 ?? 0; expense = model.Payment.EXPENSE.FY3.Q2 ?? 0; }
        //                    if (q == 3) { capex = model.Payment.CAPEX.FY3.Q3 ?? 0; expense = model.Payment.EXPENSE.FY3.Q3 ?? 0; }
        //                    if (q == 4) { capex = model.Payment.CAPEX.FY3.Q4 ?? 0; expense = model.Payment.EXPENSE.FY3.Q4 ?? 0; }
        //                }

        //                payments.Add(new T_Payment
        //                {
        //                    AFD_ID = CoverLetterID,
        //                    Fiscal_Year = fiscalyear.ToString(),
        //                    Fiscal_Quarter = $"Q{q}",
        //                    Capital_Expense_Amount = capex,
        //                    Expense_Amount = expense
        //                });
        //            }
        //        }

        //        db_AFD.T_Payment.AddRange(payments);
        //        db_AFD.SaveChanges();


        //        // =====================================================================
        //        //   Update total
        //        // =====================================================================
        //        data.Capital_Expense_Amount = payments.Sum(x => (double?)x.Capital_Expense_Amount);
        //        data.Expense_Amount = payments.Sum(x => (double?)x.Expense_Amount);
        //        data.Budget_Amount = (decimal?)(data.Capital_Expense_Amount + data.Expense_Amount);

        //        db_AFD.SaveChanges();



        //        // =====================================================================
        //        //   Update file (overwrite)
        //        // =====================================================================

        //        // =====================================================================
        //        //  SAVE FILE LAMPIRAN PENDUKUNG AND RENAME FILE FISIK
        //        // ===================================================================== 

        //        string SaveAndRename(string base64, string originalName, string folderPath, string prefix)
        //        {
        //            if (string.IsNullOrEmpty(base64) || string.IsNullOrEmpty(originalName))
        //                return "";

        //            string cleanName = Path.GetFileName(originalName);
        //            string originalPath = Path.Combine(folderPath, cleanName);

        //            byte[] fileBytes = Convert.FromBase64String(base64);

        //            // Pastikan jika file lama masih ada → hapus (unlock friendly)
        //            if (System.IO.File.Exists(originalPath))
        //            {
        //                System.IO.File.SetAttributes(originalPath, FileAttributes.Normal);
        //                System.IO.File.Delete(originalPath);
        //            }

        //            // SAVE FILE TANPA LOCK
        //            using (var fs = new FileStream(originalPath, FileMode.Create, FileAccess.Write, FileShare.None))
        //            {
        //                fs.Write(fileBytes, 0, fileBytes.Length);
        //            } // <-- file dijamin tertutup 100%

        //            // Rename
        //            string newFileName = $"{prefix}_{cleanName}";
        //            string newFilePath = Path.Combine(folderPath, newFileName);

        //            if (System.IO.File.Exists(newFilePath))
        //            {
        //                System.IO.File.SetAttributes(newFilePath, FileAttributes.Normal);
        //                System.IO.File.Delete(newFilePath);
        //            }

        //            // MOVE TANPA LOCK
        //            System.IO.File.Move(originalPath, newFilePath);

        //            return newFileName;
        //        }

        //        string SourceUploadDocumentAFD = System.Configuration.ConfigurationManager.AppSettings["SourceUploadDocumentAFD"];

        //        //var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}\\{model.CostSection}";

        //        var xFolder = $"{SourceUploadDocumentAFD}\\FY{model.FiscalYear}\\{model.AFDType}\\{model.AFDSubType}";
        //        if (!Directory.Exists(xFolder)) Directory.CreateDirectory(xFolder);

        //        // Save + Rename fisik:
        //        string overviewFile = SaveAndRename(
        //            model.FileContentOverview,
        //            model.FileNameContentOverview,
        //            xFolder,
        //            CoverLetterID + "_ContentOverview"
        //        );

        //        string scheduleFile = SaveAndRename(
        //            model.FileSchedule,
        //            model.FileNameSchedule,
        //            xFolder,
        //            CoverLetterID + "_Schedule"
        //        );

        //        string biddingFile = SaveAndRename(
        //            model.FileBiddingDocument,
        //            model.FileNameBiddingDocument,
        //            xFolder,
        //            CoverLetterID + "_Bidding"
        //        );

        //        var afdAttachFile = db_AFD.T_AFD.FirstOrDefault(x => x.AFD_ID == CoverLetterID);

        //        if (afdAttachFile != null)
        //        {
        //            if (!string.IsNullOrEmpty(overviewFile))
        //                afdAttachFile.Content_Overview = overviewFile;

        //            if (!string.IsNullOrEmpty(scheduleFile))
        //                afdAttachFile.Schedule = scheduleFile;

        //            if (!string.IsNullOrEmpty(biddingFile))
        //                afdAttachFile.Bidding_Document = biddingFile;

        //            db_AFD.SaveChanges();


        //        }


        //        //=====================================================
        //        //SEND NOTIFICATION
        //        //=====================================================
        //        var ExecuteSendEmailNotification = "EXEC [dbo].[SP_SendMailNotification]   " + CoverLetterID + ",'Submit Approval','" + NIKLogin + "'";
        //        db_AFD.Database.ExecuteSqlCommand(ExecuteSendEmailNotification);


        //        return Json(new { success = true, afd_id = CoverLetterID, attch1 = overviewFile, attch3 = scheduleFile, attch5 = biddingFile, });

        //    }
        //    catch (Exception ex)
        //    {
        //        Response.StatusCode = 500;
        //        return Json(new { success = false, message = ex.Message });
        //    }
        //}





    }
}