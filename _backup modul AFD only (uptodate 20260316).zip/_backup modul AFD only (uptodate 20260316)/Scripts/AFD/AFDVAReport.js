﻿$(document).ready(function () {

 

    //**********************************  VA REPORT

    if (typeof InitialPage !== "undefined" && InitialPage === "IndexVAReport") {
       loaddataVAReport();

        function toNumber(val) {
            return parseFloat(val) || 0;
        }

        function calculateRowVAReport(row,type) {

            let VA_CapitalExpenditure =
                toNumber(row.find('.Before-VA').val()) - toNumber(row.find('.After-VA').val());

            let VA_Expense =
                toNumber(row.find('.Before-VA').val()) - toNumber(row.find('.After-VA').val());

             
            if (type == "CAPEX") {
                row.find('.Capital-Expenditure-VA').val(VA_CapitalExpenditure.toFixed(1));

            }
            if (type == "EXPENSE") {
                row.find('.Expense-VA').val(VA_Expense.toFixed(1)); 
            }

        }
        function calculateGrandTotalVAReport() {

            let grandBeforeVA = 0,
                grandAfterVA = 0,
                grandCAPEX = 0,
                grandEXPEN = 0,  
                grandVAEffect = 0;
                grandReductionRatio = 0;

            $('#VAReportTable tbody tr').each(function () {
                grandBeforeVA += toNumber($(this).find('.Before-VA').val());
                grandAfterVA += toNumber($(this).find('.After-VA').val());
                grandCAPEX += toNumber($(this).find('.Capital-Expenditure-VA').val());
                grandEXPEN += toNumber($(this).find('.Expense-VA').val());
  
                grandVAEffect += grandCAPEX + grandEXPEN;
                grandReductionRatio += (grandCAPEX + grandEXPEN) / grandBeforeVA;
            
                 
            });

            $('#grand-before-VA').text(grandBeforeVA.toFixed(1));
            $('#grand-after-VA').text(grandAfterVA.toFixed(1));
            $('#grand-capital-expenditure').text(grandCAPEX.toFixed(1));
            $('#grand-expense').text(grandEXPEN.toFixed(1));

        
            let VALgrandVAEffect = isNaN(grandVAEffect) ? 0 : grandVAEffect;
            $('#spanAmountVAEffect').html(VALgrandVAEffect.toFixed(1));


            let VALgrandReductionRatio = isNaN(grandReductionRatio) ? 0 : grandReductionRatio; 
            $('#spanReductionRatio').html(VALgrandReductionRatio.toFixed(1));

         
 
        }

        $(document).on('input', '.calc', function () {
            let row = $(this).closest('tr');
          /*  calculateRowVAReport(row);*/
            calculateGrandTotalVAReport();
        });

        $('#addRow').click(function () {

            if (!validateVAReportRow()) {
                return;
            }


            // ===== lanjut add row =====
            let newRow = $('#VAReportTable tbody tr:first').clone();

            newRow.find('input').val('');
            newRow.find('.subtotal-mach-import,.subtotal-mach-local,.subtotal-cons,.total')
                .text('0.0');

            newRow.find('td:first').html(
                '<input type="text" style="width:550px;padding:5px"  class="item-name">'
            );

            $('#VAReportTable tbody').append(newRow);
        });

        function validateVAReportRow() {

            let isInvalid = false;

            $('#VAReportTable tbody tr').each(function () {

                let row = $(this);
                let itemName = row.find('.item-name').val()?.trim();
                let beforeVA = parseFloat(row.find('.Before-VA').val()) || 0;
                let afterVA = parseFloat(row.find('.After-VA').val()) || 0;
                let capex = parseFloat(row.find('.Capital-Expenditure-VA').val()) || 0;
                let expense = parseFloat(row.find('.Expense-VA').val()) || 0;
                 
            
                // reset highlight
                row.removeClass('table-danger');

                if (!itemName ||
                    (beforeVA === 0 && afterVA === 0 && capex === 0 && expense === 0)
                ) {
                    row.addClass('table-danger');
                    isInvalid = true;
                    return false;
                }


            });

            if (isInvalid) {
                Swal.fire({
                    icon: 'warning',
                    title: '',
                    text: 'Item Name cannot be empty and amount (Before VA, After VA, Capital Expenditure & Expense) cannot be 0.0',
                    confirmButtonText: 'OK',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

                return false;
            }

            return true;
        }

        $(document).on('click', '.VAReportTable_deleteRow', function () {

            if ($('#VAReportTable tbody tr').length === 1) {
                alert('There must be at least one line.');
                return;
            }

            let row = $(this).closest('tr');

            let itemName = row.find('td:first input').val();



            //Swal.fire({
            //    title: "Are you sure?",
            //    text: "Item " + itemName +" will be deleted!",
            //    icon: "warning",
            //    showCancelButton: true,
            //    confirmButtonColor: "#3085d6",
            //    cancelButtonColor: "#d33",
            //    confirmButtonText: "OK",
            //    width: '80rem',
            //    customClass: {
            //        title: 'swal-title-big',
            //        htmlContainer: 'swal-text-big',
            //        confirmButton: 'swal-btn-big',
            //        cancelButton: 'swal-btn-big',
            //        icon: 'swal-icon-big'
            //    }
            //}).then((result) => {
            //    if (result.isConfirmed) {
            //        Swal.fire({
            //            title: "Deleted!",
            //            text: "Item " + itemName +"  has been deleted.",
            //            icon: "success",
            //            width: '80rem',
            //            customClass: {
            //                title: 'swal-title-big',
            //                htmlContainer: 'swal-text-big',
            //                confirmButton: 'swal-btn-big',
            //                cancelButtonColor: 'swal-btn-big',
            //                icon: 'swal-icon-big'
            //            }
            //        });


            //    }
            //});


            //if (
            //    !confirm('Delete this line?\nItem: ' + itemName)

            //    ) return;

            row.remove();
            calculateGrandTotal();

        });

        $('#SaveVAReport').click(function () {


            var xBudgetFinal = parseFloat(($("#txtBudgetFinal").val() || "0").replace(/,/g, ""));
            var xTotalAfterVA = parseFloat(($("#grand-after-VA").text() || "0").replace(/,/g, ""));
 
            if (xTotalAfterVA > xBudgetFinal) {
                //alert("Tidak boleh melebihi budget amount");

                Swal.fire({
                    icon: "error",
                    title: "Budget amount limit exceeded",
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        confirmButton: 'swal-btn-big',
                        icon: 'swal-icon-big'
                    }

                });

                return;
            }


            if (!validateVAReportRow()) {
                return;
            }

            let VAReportItems = [];

            $('#VAReportTable tbody tr').each(function () {

                let row = $(this);

                let item = {
                    ItemName: row.find('.item-name').val(), 
                    BeforeVA: toNumber(row.find('.Before-VA').val()),
                    AfterVA: toNumber(row.find('.After-VA').val()),
                    VAamountCAPEX: toNumber(row.find('.Capital-Expenditure-VA').val()),
                    VAamountEXPENSE: toNumber(row.find('.Expense-VA').val()),
                    Content: row.find('.content').val()
                };

                VAReportItems.push(item);
            });

            if (VAReportItems.length === 0) {
                alert('No data to save');
                return;
            }


            var xReductionRatio = $("#spanReductionRatio").html();
            if (xReductionRatio === 0 || xReductionRatio === 0.0 ) {
                alert('Please input data');
                return;
            }




            var dataPost = {
                afdId: $("#txtIDAFD").val(),
                EffectVA: $("#spanAmountVAEffect").text(),
                ReductionRatioVA: $("#spanReductionRatio").text(),
                items: VAReportItems
            };


            $.ajax({
                url: '/AFDCoverLetter/SaveVAReport',
                type: 'POST',
                data: JSON.stringify(dataPost),
                contentType: 'application/json; charset=utf-8',

                success: function (res) {
                    if (res.success) {

                        Swal.fire({
                            icon: "success",
                            title: "Data saved successfully",
                            showConfirmButton: true,
                            confirmButtonText: "OK",
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big',
                                icon: 'swal-icon-big'
                            }

                        }).then((result) => {
                            if (result.isConfirmed) {
                                $("#copy_txtTotalCapitalExpenditure").html("");
                                $("#copy_txtTotalExpense").html("");

                                window.close();
                            }
                        });

                    } else {
                        alert(res.message);
                    }
             
                },
                error: function () {
                    alert('Error saving data');
                }
            });




        });


  
        function loaddataVAReport() {

             
            var coverLetterId=  $("#txtIDAFD").val();
            
            /*================= AJAX =================*/
            var dataPost = {
                afdId: coverLetterId
            };

            $.ajax({
                url: '/AFDCoverLetter/GetVAReport',
                type: 'POST',
                data: JSON.stringify(dataPost),
                contentType: 'application/json; charset=utf-8',
                processData: false,
                success: function (response) {

                    let tbody = $('#VAReportBody');
                    tbody.empty();

                    $("#VAReportTable, #addRow, #SaveVAReport").removeClass("hide");

                    if (!response || response.length === 0) {
                        tbody.append(createEmptyRow());
                    } else {
                        renderVAReportTable(response);
                        console.log(response);
                    }

                    recalcAll();
                },
                error: function (err) {
                    console.log(err);
                }
            });












        }
         
        function renderVAReportTable(data) {

            let tbody = $('#VAReportBody');
            tbody.empty(); // bersihkan dulu

            $.each(data, function (i, d) {

                let row = `
        <tr>
            <td><input type="text"  style="width:550px;padding:5px"   class="item-name" value="${d.VA_Item ?? ''}"></td> 
            <td><input type="number" style="width:70px;padding:5px" class="calc Before-VA" value="${d.Amount_Before_VA ?? 0}" min=0></td>
            <td><input type="number" style="width:70px;padding:5px" class="calc After-VA" value="${d.Amount_After_VA ?? 0}" min=0></td>
            <td>
                <input type="number" style="width:100px;padding:5px" class="calc Capital-Expenditure-VA" value="${d.VA_Capital_Expenditure ?? 0}" min=0 disabled>
                <span class="glyphicon glyphicon-check" style="color:green;cursor:pointer" id= "VAReportTable_GetCalculateCapex" ></span>
                <span class="glyphicon glyphicon-remove" style="color:red;cursor:pointer" id= "VAReportTable_EditCalculateCapex" ></span>
            </td>
            <td>
                <input type="number" style="width:100px;padding:5px" class="calc Expense-VA" value="${d.VA_Expense ?? 0}" min=0 disabled>
                <span class="glyphicon glyphicon-check" style="color:green;cursor:pointer" id= "VAReportTable_GetCalculateExpense" ></span>
                <span class="glyphicon glyphicon-remove" style="color:red;cursor:pointer" id= "VAReportTable_EditCalculateExpense" ></span>
            </td> 
            <td colspan="4"><input type="text" style="width:450px;padding:5px"   class="content"  value="${d.VA_Content ?? ''}"></td>
            <td style="border:none">
                <button type="button" class="btn btn-danger VAReportTable_deleteRow">
                    <span class="glyphicon glyphicon-remove"></span>
                </button>
            </td>
        </tr>
        `;
                tbody.append(row);

                console.log(row);
            });


        }
         
        function recalcAll() {
            $('#VAReportTable tbody tr').each(function () {
               /* calculateRowVAReport($(this));*/
            });

            calculateGrandTotalVAReport();
        }

        function createEmptyRow() {
            return `
    <tr>
        <td><input type="text" style="width:550px;padding:5px" class="item-name"></td>
        <td><input type="number" style="width:70px;padding:5px" class="calc Before-VA"  min=0></td>
        <td><input type="number" style="width:70px;padding:5px" class="calc After-VA"  min=0></td>
        <td>
            <input type="number" style="width:100px;padding:5px"  class="calc Capital-Expenditure-VA"  min=0>
            <span class="glyphicon glyphicon-check" style="color:green;cursor:pointer" id= "VAReportTable_GetCalculateCapex" ></span>
            <span class="glyphicon glyphicon-remove" style="color:red;cursor:pointer" id= "VAReportTable_EditCalculateCapex" ></span>
        </td>
        <td>
            <input type="number" style="width:100px;padding:5px"  class="calc Expense-VA"  min=0>
            <span class="glyphicon glyphicon-check" style="color:green;cursor:pointer" id= "VAReportTable_GetCalculateExpense" ></span>
            <span class="glyphicon glyphicon-remove" style="color:red;cursor:pointer" id= "VAReportTable_EditCalculateExpense" ></span>
        </td>
        <td colspan="4"><input type="text" style="width:450px;padding:5px"  class="content" ></td>
        <td style="border:none">
            <button type="button" class="btn btn-danger VAReportTable_deleteRow">
                <span class="glyphicon glyphicon-remove"></span>
            </button>
        </td>
    </tr>`;
        }

        $(document).on('click', '#VAReportTable_GetCalculateCapex', function () {
            let row = $(this).closest('tr');
            let type = "CAPEX";

            // reset expense
            row.find('.Expense-VA').val(0.0);

            calculateRowVAReport(row, type);
            calculateGrandTotalVAReport();
        });

        $(document).on('click', '#VAReportTable_EditCalculateCapex', function () {
            let row = $(this).closest('tr');
            row.find('.Capital-Expenditure-VA').val(0.0);
            calculateGrandTotalVAReport();
        });

        $(document).on('click', '#VAReportTable_GetCalculateExpense', function () {
            let row = $(this).closest('tr');
            let type = "EXPENSE";

            // reset capex
            row.find('.Capital-Expenditure-VA').val(0.0);

            calculateRowVAReport(row, type);
            calculateGrandTotalVAReport();
        });

        $(document).on('click', '#VAReportTable_EditCalculateExpense', function () {
            let row = $(this).closest('tr');
            row.find('.Expense-VA').val(0.0);
            calculateGrandTotalVAReport();
        });

        $("#PreviewVAReport").click(function () {

            var IDAFD = $("#txtIDAFD").val();
            console.log(IDAFD);

            var url = '/AFDCoverLetter/PrintVAReport?CoverLetterId=' + IDAFD;
            window.open(url, '_blank');


        })

        $("#ExitVAReport").click(function () {
           window.close(); 
        })
    }
    //END OF VA REPORT





 }); //END OF DOCUMENT
