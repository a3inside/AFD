﻿$(document).ready(function () {

    if (typeof InitialPage !== "undefined" && InitialPage === "IndexCoverLetter") {




        var IdentifyReload = true;


        $(this).scrollTop(0);



        function generateFiscalYear() {
            var tgl = $("#dtp_DateOfProposal").val();           // contoh: "2025-11-18"
            var date = new Date(tgl);

            let tahun = date.getFullYear();
            let bulan = date.getMonth() + 1;   // getMonth() = 0-11 → tambah 1

            var fiscalYear;

            if (bulan >= 4) {
                fiscalYear = tahun;            // mulai April → FY = tahun input
            } else {
                fiscalYear = tahun - 1;        // Jan–Mar → FY = tahun sebelumnya
            }

            $("#txt_FiscalYear").val(fiscalYear);
            $("#txt_RateFY").html("(FY " + fiscalYear + ") ")



            //set untuk nama kolom di inputan Payment
            var FY1 = fiscalYear;
            var FY2 = fiscalYear + 1
            var FY3 = fiscalYear + 2

            $("#span_PaymentFY1").html(FY1);
            $("#span_PaymentFY2").html(FY2);
            $("#span_PaymentFY3").html(FY3);
            // end of 



            //get Rate
            var xFiscalYear = fiscalYear;
            var xCurrencyCode = "USD";
            GetRate(xFiscalYear, xCurrencyCode)
            //end of   
        }

        $("#txt_AmountBudget").on("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();

                var Category = $("#ddl_Category").val(); 
          
                if (!Category) { 
                    Swal.fire({
                        icon: 'warning',
                        title: "Please select a category first",
                        text: "", 
                         width: '80rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }

                    });


                    return;
                }
              

                SetDecisionLevel();
            }
        });
         
        $("#dtp_PeriodeCommencement").on("input", function () {

            var tgl = $("#dtp_PeriodeCommencement").val();
            var btnName = "#txt_PeriodeCommencement";
            formatTanggal(tgl, btnName);
        });

        $("#dtp_PeriodeCommencement").on("change", function () {
            var tgl = $("#dtp_PeriodeCommencement").val();
            var btnName = "#txt_PeriodeCommencement";
            formatTanggal(tgl, btnName);
        });

        $("#dtp_PeriodeCompletion").on("input", function () {

            var tgl = $("#dtp_PeriodeCompletion").val();
            var btnName = "#txt_PeriodeCompletion";
            formatTanggal(tgl, btnName);
        });

        $("#dtp_PeriodeCompletion").on("change", function () {
            var tgl = $("#dtp_PeriodeCompletion").val();
            var btnName = "#txt_PeriodeCompletion";
            formatTanggal(tgl, btnName);
        });

        //end of trigger inputan Date 



        //OTHER FUNCTION
        function formatTanggal(tgl, dtp) {
            // tgl contoh: "03/13/2026"

            if (tgl == "" || tgl == null) {
                return;
            }

            // Input contoh: "2025-11-21"
            let parts = tgl.split("-");

            let tahun = parts[0];
            let bulan = parts[1];
            let hari = parts[2];

            let namaBulan = [
                "", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"
            ];


            var result = ""
            if (dtp == "#txt_PeriodeCommencement" || dtp == "#txt_PeriodeCompletion") {
                result = namaBulan[parseInt(bulan)] + " " + tahun;
            } else {
                var result = parseInt(hari) + " " + namaBulan[parseInt(bulan)] + " " + tahun;
            }

            $(dtp).html(result);


        }
        //end of OTHER FUNCTION


        $("#ViewBudgetSheet").click(function () {

            var coverLetterId = getQueryParam("CoverLetterId"); 
             
            var url = '/AFDCoverLetter/PrintBudgetSheet?CoverLetterId=' + coverLetterId;
            window.open(url, '_blank');


        })


        //PAYMENT 
        $(".inputamt").on('input', function () {
            this.value = this.value.replace(/[^0-9.,]/g, '');

            // Replace koma jadi titik
            this.value = this.value.replace(',', '.');

            // Batasi hanya 1 angka setelah desimal
            this.value = this.value.replace(/^(\d+)\.(\d?).*$/, '$1.$2');
        })

        PAYMENT();

        function PAYMENT() {

            // SIMPAN LAST VALUE saat focus
            $('[id^="CAPEX_"], [id^="EXP_"]').on('focus', function () {
                $(this).data('lastvalue', $(this).val());

            });

            // Event untuk semua input CAPEX & EXP
            $('[id^="CAPEX_"], [id^="EXP_"]').on('input', function () {

                var limit = parseFloat($("#txt_AmountBudget").val()) || 0;
                var currentBox = $(this);
                var newValue = parseFloat(currentBox.val()) || 0;

                // =========================
                // Hitung total baru TANPA update field total lebih dulu
                // =========================
                var totalBaru = 0;

                $('[id^="TOTAL_FY"]').each(function () {
                    totalBaru += parseFloat($(this).val()) || 0;
                });

                // Kurangi nilai lama di kolom ini, tambahkan nilai baru
                var lastValue = parseFloat(currentBox.data('lastvalue')) || 0;
                totalBaru = totalBaru - lastValue + newValue;

                // =========================
                // VALIDASI LIMIT
                // =========================
                if (totalBaru > limit) {

                    var AmountBudgetMaster = $("#txt_AmountBudget").val();


                    if (IdentifyReload == false) {

                        Swal.fire({
                            title: "Total must not exceed the approved budget!",
                            text: "Your Budget : " + AmountBudgetMaster + " KUSD",
                            icon: "warning",
                            draggable: true,
                            width: '80rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                icon: 'swal-icon-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });

                    }
                    IdentifyReload = false;

                    // Kembalikan ke nilai sebelumnya
                    currentBox.val(lastValue);

                    // Jangan lanjut update total
                    return;
                }

                // Aman → simpan nilai sebagai lastValue baru
                currentBox.data('lastvalue', newValue);

                // Update total setelah lolos validasi
                updateAllTotals();
            });






























            // -----------------------
            // FUNCTION UPDATE TOTAL
            // -----------------------
            function updateAllTotals() {
                for (var fy = 1; fy <= 3; fy++) {
                    for (var q = 1; q <= 4; q++) {
                        var capex = parseFloat($("#CAPEX_FY" + fy + "_Q" + q).val()) || 0;
                        var exp = parseFloat($("#EXP_FY" + fy + "_Q" + q).val()) || 0;
                        $("#TOTAL_FY" + fy + "_Q" + q).val((capex + exp).toFixed(1));
                    }
                }

                sumTOTALBARIS();
                sumEXPTOTALBARIS();
                sumCAPEXTOTALBARIS();
            }

            function sumTOTALBARIS() {
                var total = 0;
                $('[id^="TOTAL_FY"]').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                $("#TOTAL_ALL").val(total.toFixed(1));
            }

            function sumEXPTOTALBARIS() {
                var total = 0;
                $('[id^="EXP_FY"]').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                $("#EXP_TOTAL").val(total.toFixed(1));
            }

            function sumCAPEXTOTALBARIS() {
                var total = 0;
                $('[id^="CAPEX_FY"]').each(function () {
                    total += parseFloat($(this).val()) || 0;
                });
                $("#CAPEX_TOTAL").val(total.toFixed(1));
            }

        }
        //END OF PAYMENT


        //PURPOSE
        $("#divPurposeDescription, #divRequisiteSpesification, #divExpectedEffect, #divReturnReason").summernote({
            focus: false,
            height: 150,
            codemirror: { // codemirror options
                mode: 'text/html',
                htmlMode: true,
                lineNumbers: true,
                theme: 'monokai'
            },

            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'italic', 'underline', 'clear', 'fontsize']],
                ['para', ['ul', 'ol', 'paragraph']], 
                ['view', ['fullscreen', 'help']],
                ['misc', ['undo', 'redo']],
                ['style2', ['hr']]
            ],
        });
        //END OF PURPOSE



        //validasi UPLOAD FILE PDF
        function validatePdf(input) {

            const file = input.files[0];
            const errorMsg = input.parentElement.querySelector("small");

            if (!file) return;

            // Reset error dulu
            if (errorMsg) {
                errorMsg.classList.add("d-none");
                errorMsg.textContent = "";
            }

            // ✅ Validasi tipe PDF (lebih aman)
            if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {

                if (errorMsg) {
                    errorMsg.classList.remove("d-none");
                    errorMsg.textContent = "File must be PDF.";
                }

                input.value = "";
                return;
            }

            // ✅ Validasi ukuran maksimum 2MB
            const maxSize = 2 * 1024 * 1024;

            if (file.size > maxSize) {

                input.value = ""; // clear file

                Swal.fire({
                    icon: 'info',
                    title: 'Your file size is more than 2MB',
                    text: 'Re-upload with file size not exceeding 2MB',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

                return; // 🔥 penting supaya stop di sini
            }

        }

        $(".pdf-upload").on("change", function () {
            validatePdf(this);
        });

        //// Terapkan ke setiap input file
        //["fileContentOverview", "fileSchedule", "fileBiddingDocument"].forEach(id => {

        //    const el = document.getElementById("ID_ELEMEN");
        //    if (!el) return; // ⛔ cegah error

        //    document.getElementById(id).addEventListener("change", function () {
        //        validatePdf(this);
        //    });
        //});







        //END OF UPLOAD FILE PDF


        ////pilih decision
        //$('input[name="DecisionLevel"]').on('change', function () {
        //    // Jika ada yang dipilih, tampilkan div
        //    if ($('input[name="DecisionLevel"]:checked').length > 0) {
        //        $('#div_AFDType').show();
        //        $("#div_inputan").removeClass("hidden");
        //    }
        //});
        ////end of pilih decision


        //validasi radiobutton disposal 
        $("#txtOtherDept").hide();         // Awal kondisi: input text hidden


        $("input[name='deptDisposal']").change(function () {
            if ($("#otherDept").is(":checked")) {
                $("#txtOtherDept").show();
            } else {
                $("#txtOtherDept").hide();
                $("#txtOtherDept").val(""); // optionally clear input
            }
        });
        //END OF validasi  radiobutton disposal


        //BUDGET SHEET
        $("#btnOpenBudgetForm").click(function () {
            var txt_CoverLetterID = $("#txt_CoverLetterID").val();

            if (txt_CoverLetterID === undefined || txt_CoverLetterID === "") {

                Swal.fire({
                    icon: 'warning',
                    title: 'The Cover Letter ID has not been created yet.',
                    text: 'Please save this as a draft first !!!',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

            } else {
                var url = "/AFDCoverLetter/IndexBudgetSheet?CoverLetterId=" + txt_CoverLetterID;
                window.open(url, "_blank"); // buka new tab

            }



        });
        //END OF BUDGET SHEET


        //VA SHEET
        $("#btnOpenVAReportForm").click(function () {
            var txt_CoverLetterID = $("#txt_CoverLetterID").val();

            if (txt_CoverLetterID === undefined || txt_CoverLetterID === "") {

                Swal.fire({
                    icon: 'warning',
                    title: 'The Cover Letter ID has not been created yet.',
                    text: 'Please save this as a draft first !!!',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

            } else {
                var url = "/AFDCoverLetter/IndexVAReport?CoverLetterId=" + txt_CoverLetterID;
                window.open(url, "_blank"); // buka new tab
            }



        });
        //END OF VA SHEET


        //AFD Type Change
        $(document).on('change', '#ddl_AFDType', function () {
             
            getAFDCostSection();

            var val = $(this).val();
            getAFDSubType(val);

            $("#ddl_Category").remove();
            $("#txt_FormAFDID").val("");

            if (val === "CAPITAL INVESTMENT") {
                $("#div_ResponsibleforDisposal").addClass("hidden");
                $("#txt_AmountBudget").val("");
                $("#span_AmountBudget").html("");
                $("#div_Payment").addClass("hidden");
                $("#txt_AmountBudget").prop("disabled", true);
                $("#ddl_BudgetType").prop("disabled", false);
            }

            if (val === "DISPOSAL") {
                $("#div_ResponsibleforDisposal").removeClass("hidden");
                $("#txt_AmountBudget").val(0);
                $("#span_AmountBudget").html("(Additional)");
                $("#btn_SearchMasterBudget").addClass("hidden");
                $("#div_Payment").removeClass("hidden");
                $("#ddl_BudgetType")
                    .val("Additional")
                    .prop("disabled", true);

            }


            // disable semua radio
            $('input[name="DecisionLevel"]').prop('disabled', true);
        });


        function getAFDSubType(val) {
            if (val === "CAPITAL INVESTMENT") {
                html = `  
                    <select id="ddl_AFDSubType" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Rutin</option> 
                        <option>Special</option> 
                    </select> `;
            }

            else if (val === "DISPOSAL") {
                html = `  
                    <select id="ddl_AFDSubType" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Stock</option> 
                        <option>Asset</option> 
                    </select> `;
            }

            // isi atau kosongkan wrapper
            $('#div_AFDSubType').html(html);

        }


        function getAFDCostSection() {
             
            var NIKLogin = ($("#txt_NIKLogin").val() || "").trim();

            $.ajax({
                url: '/AFDCoverLetter/GetCostSection',
                type: 'GET',
                dataType: 'json',
                data: {
                    NIKLogin: NIKLogin
                },
                success: function (res) {

                    if (res.status !== "ok") {
                        alert(res.message);
                        return;
                    }

                    let html2 = `
        <select id="ddl_CostSection" class="form-select form-select-sm soft-dropdown">
    `;

                    // Jika hanya 1 data
                    if (res.CostSection.length === 1) {

                        html2 += `<option value="${res.CostSection[0]}" selected>
                    ${res.CostSection[0]}
                  </option>`;

                        html2 += `</select>`;

                        $('#div_CostSection').html(html2);

                        // OPTIONAL: jika ingin tidak bisa diganti
                        // $('#ddl_CostSection').prop('disabled', true);

                        getAFDCoordinator();

                    } else {

                        html2 += `<option selected disabled></option>`;

                        $.each(res.CostSection, function (i, val) {
                            html2 += `<option value="${val}">${val}</option>`;
                        });

                        html2 += `</select>`;

                        $('#div_CostSection').html(html2);
                    }
                },
                error: function () {
                    alert('Gagal mengambil data category');
                }
            });
        }
        //END OF AFD Type Change


        //AFD Sub Type Change
        //$('#div_AFDSubType').on('change', function () {
        //    //$('#div_Category').removeClass('hidden');
        //});



        $(document).on('change', '#ddl_AFDSubType', function () {
            var AFDType = $("#ddl_AFDType").val();

            $("#btn_SearchMasterBudget").removeClass("hidden");
            $("#txt_AmountBudget").prop("disabled", false);
            $("#txt_AmountBudget").val(0);

            //isi pilihan pada category 
            getAFDCategory();
            $('#div_Category').removeClass("hidden")

      

            $("#span_ViewAmount").html("");
            $("#txt_FormAFDID").val("");
        }); 
        // END OF AFD Sub Type Change


        function getAFDCategory() {
            html2 = `<select id="ddl_Category" class="form-select form-select-sm soft-dropdown">
                        <option selected disabled></option>
                        <option>Mesin / Fasilitas Produksi langsung</option>
                        <option>Lain-lain (selain mesin / fasilitas produksi)</option>
                    </select>`; 
            $('#div_Category').html(html2); 
        }

        //function getCategory() {
             
        //    var xAFDType = $("#ddl_AFDType").val();
        //    var xAFDSubType = $("#ddl_AFDSubType").val();
        //    var xBudgetFinalID = parseInt($("#span_BudgetFinalID").text());
             
        //    $.ajax({
        //        url: '/AFDCoverLetter/getCategoryInvestment', // sesuaikan dengan Controller kamu
        //        type: 'GET',
        //        dataType: 'json', 
        //        data: {
        //            AFDType: xAFDType,
        //            AFDSubType: xAFDSubType,
        //            BudgetFinalID: xBudgetFinalID
        //        }, 
        //        success: function (res) { 
        //            let html2 = `
        //        <select id="ddl_Category" class="form-select form-select-sm soft-dropdown">
        //            <option selected disabled>-- Pilih Category --</option>
        //    `;

        //            $.each(res, function (i, val) {
        //                html2 += `<option value="${val}">${val}</option>`;
        //            });

        //            html2 += `</select>`;

        //            $('#div_Category').html(html2);
        //        },
        //        error: function () {
        //            alert('Gagal mengambil data category');
        //        }
        //    });
        //}

        //Category Change 
        $(document).on('change', '#ddl_Category', function () {
            $('#div_Category').removeClass('hidden');
            //$("#tbl_minmaxamount").removeClass('hidden');  
            SetDecisionLevel();
        });

        //Cost Section Change 
        $(document).on('change', '#ddl_CostSection', function () {
            getAFDCoordinator();
        });



        var lastDecisionLevel = null;
        function SetDecisionLevel() {
             
            // simpan pilihan saat ini SEBELUM ajax jalan
            lastDecisionLevel = $("input[name='DecisionLevel']:checked").val();


            var xAFDType = $('#ddl_AFDType').val();
            var xAFDSubType = $('#ddl_AFDSubType').val();
            var xCategory = $('#ddl_Category').val(); 
            var xAmountBudget = parseFloat(
                $('#txt_AmountBudget').val().replace(/,/g, '')
            );

            $.ajax({
                url: "/AFDCoverLetter/SetDecisionLevel",
                type: "GET",
                data: { 
                    afdType: xAFDType,
                    afdSubType: xAFDSubType,
                    category: xCategory,
                    AmountBudget: xAmountBudget
                },
                success: function (res) {
                    if (res.status === "error") {
                        //alert(res.message);


                        Swal.fire({
                            icon: 'warning',
                            title: "Unknown Data",
                            text: "please call IS (151/152)",
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });


                        // 🔹 KEMBALIKAN KE PILIHAN SEBELUMNYA
                        if (lastDecisionLevel) {
                            $("input[name='DecisionLevel']").prop("checked", false);
                            $("input[name='DecisionLevel'][value='" + lastDecisionLevel + "']")
                                .prop("checked", true);
                        }


                        return;

                    } else {

                        // jika tidak error 

                        // enable semua dulu
                        $("input[name='DecisionLevel']").prop("disabled", true);

                        // aktifkan & select sesuai decision
                        $("input[name='DecisionLevel'][value='" + res.DecisionBy + "']")
                            .prop("disabled", false)
                            .prop("checked", true);



                        // jika tidak error 
                        $("#span_MinAmount").html(res.minAmount);
                        $("#span_MaxAmount").html(res.maxAmount);
                        $("#span_ViewAmount").html(res.viewAmount);
                        $("#txt_FormAFDID").val(res.idAFDForm);

                    }
                }
            });


        }
         
        function GetAmountRange() {

            var xDecision = $('input[name="DecisionLevel"]:checked').val();
            var xAFDType = $('#ddl_AFDType').val();
            var xAFDSubType = $('#ddl_AFDSubType').val();
            var xCategory = $('#ddl_Category').val();

            $.ajax({
                url: "/AFDCoverLetter/GetAmountRange",
                type: "GET",
                data: {
                    decisionLevel: xDecision,
                    afdType: xAFDType,
                    afdSubType: xAFDSubType,
                    category: xCategory
                },
                success: function (res) {
                    if (res.status === "error") {
                        //alert(res.message);


                        Swal.fire({
                            icon: 'warning',
                            title: "Master data is not available.",
                            text: "please check in table M_Form_AFD & M_Rule_Approval",
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big'
                            }   
                        });


                        $("#span_MinAmount").html(0);
                        $("#span_MaxAmount").html(0);
                        $("#span_ViewAmount").html(0);
                        $("#txt_FormAFDID").html(0);

                        return;

                    } else {

                        // jika tidak error 
                        $("#span_MinAmount").html(res.minAmount);
                        $("#span_MaxAmount").html(res.maxAmount);
                        $("#span_ViewAmount").html(res.viewAmount);
                        $("#txt_FormAFDID").val(res.idAFDForm);

                    }
                }
            });


        }

        function GetRate(xFiscalYear, xCurrencyCode) {
            $.ajax({
                url: "/AFDCoverLetter/GetRate",
                type: "GET",
                data: {
                    FiscalYear: xFiscalYear,
                    CurrencyCode: xCurrencyCode
                },
                success: function (res) {
                    if (res.status === "error") {
                        //alert(res.message);

                        Swal.fire({
                            icon: 'warning',
                            title: res.message,
                            text: res.solution,
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });


                        $("#txt_Rate").val("").prop("disabled", true);

                        return;
                    } else {

                        // jika tidak error

                        let nilai = res.Rate;

                        nilai = (nilai === null || nilai === undefined) ? "" : String(nilai).replace(/,/g, "");

                        if (nilai === "" || isNaN(Number(nilai))) {
                            $("#txt_Rate").val("");
                        } else {
                            // gunakan locale en-US untuk pemisah koma (16,750). Untuk format Indonesia ganti ke 'id-ID' -> 16.750
                            let formatted = Number(nilai).toLocaleString('en-US');
                            $("#txt_Rate").val(formatted);
                        }


                    }
                }
            });
        }

        $("#btn_SearchMasterBudget").click(function () {

            // Tampilkan modal
            $("#modalSearchMasterBudget").modal("show");

            // Loading text
            $("#mb_list").html("Loading the final master budget data, please wait...");


           
            $.ajax({
                url: "/AFDCoverLetter/GetMasterBudgetFinal",
                type: "GET",
                dataType: "json",
                data: {
                    CostSection: $("#txt_CostSection").val(),    
                    FiscalYear: $("#txt_FiscalYear").val(),
                    AFDSubType: $("#ddl_AFDSubType").val() 
                },
                success: function (res) {

                    // Jika server kirim status error
                    if (res.status !== "ok") {
                        $("#mb_list").html(`
                    <p style='color:red'>${res.message}</p>
                    <small>${res.solution}</small>
                `);
                        return;
                    }

                    // Jika datanya kosong
                    if (res.data.length === 0) {
                        $("#mb_list").html("<p>No data found.</p>");
                        return;
                    }

                    // Build tabel
                    let html = "<table class='table table-bordered table-lg'>";
                    html += `
                    <table class="table table-bordered table-lg">
                    <thead>
                    <tr >
                        <th class='hidden'>Budget Final ID</th>
                        <th class="text-center">Budget Type</th>
                        <th class="text-center">Title</th> 
                        <th class="text-center">Purpose</th>
                        <th class="text-center">Cost Section</th>
                        <th class="text-center">Fiscal Year</th>
                        <th class="text-center">Budget Amount</th>
                        <th class="text-center">Remark Budget Amount</th>
                        <th class="text-center">Remark</th> 
                        <th></th> 
                    </tr>
                    </thead>
                    <tbody>`;

                    res.data.forEach(x => {
                        html += `
                    <tr>
                        <td class='hidden'>${x.Budget_Final_ID ?? ''}</td>
                        <td>${x.Budget_Type ?? ''}</td>
                        <td>${x.Title ?? ''}</td>
                        <td style='text-align:center'>${x.Purpose_Type ?? ''}</td>
                        <td style='text-align:center'>${x.Cost_Section ?? ''}</td>
                        <td style='text-align:center'>${x.Fiscal_Year ?? ''}</td>
                        <td style='text-align:center'>${x.Budget_Amount ?? ''}</td>
                        <td style='text-align:right'>${x.Remark_Budget_Amount ?? ''}</td>
                        <td>${x.Remark ?? ''}</td>
                        <td style='text-align:center'><button class="btn btn-primary btn-sm btnSelect">Select</button></td>
                    </tr>
                `;
                    });

                    html += "</tbody></table>";

                    $("#mb_list").html(html);

                },
                error: function () {
                    $("#mb_list").html("<p style='color:red'>Oops! Something went wrong while loading the data.</p>");
                }
            });

        });

        //$(document).on("click", ".btnSelect", function () {

        //    // Ambil nilai Budget Final ID dari kolom pertama (yang hidden)
        //    let budgetFinalID = $(this).closest("tr").find("td:eq(0)").text().trim();

        //    console.log("Budget Final ID =", budgetFinalID);

        //    // Lanjutkan pengecekan ID ke server
        //    checkBudgetIDinTransaction(budgetFinalID);


        //    $('#div_Payment input').each(function () {
        //        $(this).val('');
        //    });
        //    $('#div_Payment input').trigger('change');


           
        //    getCategoryInvestment();


        //    $('#div_Category').removeClass('hidden');
        //});

        function checkBudgetIDinTransaction(xbudgetFinalID) {
            $.ajax({
                url: "/AFDCoverLetter/CheckBudgetIDinTransaction",
                type: "GET",
                dataType: "json",
                data: { BudgetFinalID: xbudgetFinalID },
                success: function (res) {

                    if (res.status === "exists") {
                        Swal.fire({
                            icon: 'warning',
                            title: res.message,
                            //text: res.solution,
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });
                    }


                    if (res.status === "ok") {
                        var Budget_Final_ID = res.data[0].Budget_Final_ID;
                        var Title = res.data[0].Title;
                        var Budget_Type = res.data[0].Budget_Type;
                        var Budget_Amount = res.data[0].Budget_Amount;
                        var Purpose_Type = res.data[0].Purpose_Type;


                        $("#span_BudgetFinalID").html(Budget_Final_ID);
                        $("#span_AmountBudget").html(" (" + Budget_Type + ")");

                        Budget_Amount = Number(Budget_Amount).toLocaleString('en-US');
                        $("#txt_AmountBudget").val(Budget_Amount);

                        // $("#txt_PurposeFor").val(Purpose_Type); 
                        $("#ddl_PurposeFor").val(Purpose_Type);

                        $("#btn_CloseModalMasterBudget").trigger("click");

                        Title = Title.toUpperCase();
                        $("#txt_Title").val(Title);

                        //Swal.fire({
                        //    title: "Would you like the title on the cover letter to be the same as the title in the master budget?",
                        //    text: "",
                        //    icon: "warning",
                        //    showCancelButton: true,
                        //    confirmButtonColor: "#10ac84",
                        //    cancelButtonColor: "#d33",
                        //    cancelButtonText: "No",
                        //    confirmButtonText: "Yes",
                        //    width: '80rem',
                        //    customClass: {
                        //        title: 'swal-title-big',
                        //        htmlContainer: 'swal-text-big',
                        //        confirmButton: 'swal-btn-big',
                        //        cancelButton: 'swal-btn-big',
                        //        icon: 'swal-icon-big'
                        //    }
                        //}).then((result) => {
                        //    if (result.isConfirmed) {

                        //        Title = Title.toUpperCase(); 
                        //        $("#txt_Title").val(Title); 

                        //        Swal.fire({
                        //            title: "",
                        //            text: "Your title has been changed.",
                        //            icon: "success",
                        //            width: '60rem',
                        //            customClass: {
                        //                title: 'swal-title-big',
                        //                htmlContainer: 'swal-text-big',
                        //                icon: 'swal-icon-big',
                        //                  confirmButton: 'swal-btn-big'
                        //            }
                        //        });
                        //    }
                        //});



                        $("#div_Payment").removeClass("hidden");

                        var AFDType = $("#ddl_AFDType").val();
                        if (AFDType == "DISPOSAL") {
                            //$("#ddl_PurposeFor").removeAttr("disabled");
                            $("#ddl_PurposeFor").attr("disabled", "disabled");
                        } else {
                            $("#ddl_PurposeFor").attr("disabled", "disabled");
                        }


                    }








                },
                error: function () {
                    alert("Error checking Budget ID.");
                }
            });
        }


        //**********************************  ACTION BUTTON


        $("#btnSaveFirst").click(async function () {

            //cek ada inputan kosong ??
            let isValid = ValidasiRequiredInput();
            if (!isValid) {
                Swal.fire({
                    icon: 'warning',
                    title: "This field cannot be empty.",
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        confirmButton: 'swal-btn-big',
                        icon: 'swal-icon-big'
                    }
                });
                return; // stop semua proses
            }
            //end of


            //cek range inputan budget amount
            let isValidAmountBudget = true;
            let minAmount = 0;
            let maxAmount = 0;

            if ($("#ddl_AFDType").val() === "DISPOSAL") {
                const result = ValidasiInputanAmountBudget();
                isValidAmountBudget = result.isValid;
                minAmount = result.minAmount;
                maxAmount = result.maxAmount;
            }
            if (!isValidAmountBudget) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Input',
                    text: 'Budget amount must be between ' +
                        minAmount.toLocaleString() + ' and ' +
                        maxAmount.toLocaleString(),
                    confirmButtonText: 'OK',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                }).then(() => {
                    $("#txt_AmountBudget")
                        .prop("disabled", false)
                        //.removeClass("is-invalid") // optional reset
                        //.addClass("is-invalid")
                        .focus();
                });

                return;
            }

            //end of



            // convert file to Base64
            async function toBase64(file) {
                if (!file) return null;
                return new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result.split(',')[1]);
                    reader.onerror = error => reject(error);
                    reader.readAsDataURL(file);
                });
            }

            var divPurposeDescription = $('#divPurposeDescription').summernote('code');
            var divRequisiteSpesification = $('#divRequisiteSpesification').summernote('code');
            var divExpectedEffect = $('#divExpectedEffect').summernote('code');

            var AmountBudget = $("#txt_AmountBudget").val();
            AmountBudget = AmountBudget.replace(/,(?=\d{3}(?:\D|$))/g, '');

            var Rate = $("#txt_Rate").val();
            Rate = Rate.replace(/,(?=\d{3}(?:\D|$))/g, '');

            var fileContentOverview = await toBase64($("#fileContentOverview")[0].files[0]);
            var fileSchedule = await toBase64($("#fileSchedule")[0].files[0]);
            var fileBiddingDocument = await toBase64($("#fileBiddingDocument")[0].files[0]);


            var model = {
                CoverLetterID: $("#txt_CoverLetterID").val(),
                FiscalYear: $("#txt_FiscalYear").val(),
                DateOfProposal: $("#dtp_DateOfProposal").val(),
                DateOfDecision: $("#dtp_DateofDecision").val(),
                DecisionNumber: $("#txt_DecisionNumber").val(),
                Title: $("#txt_Title").val(),
                AFDType: $("#ddl_AFDType").val(),
                AFDSubType: $("#ddl_AFDSubType").val(),
                MinAmount: $("#span_MinAmount").text(),
                MaxAmount: $("#span_MaxAmount").text(),
                FormAFDID: $("#txt_FormAFDID").val(),
                CostSection: $("#ddl_CostSection").val(),
                NIKLogin: $("#txt_NIKLogin").val(),
                AmountBudget: AmountBudget,
                AmountBudgetID: $("#span_BudgetFinalID").html(),
                Rate: Rate,
                Place: $("#txt_Place").val(),
                PeriodeCommencement: $("#dtp_PeriodeCommencement").val(),
                PeriodeCompletion: $("#dtp_PeriodeCompletion").val(),
                //PurposeFor: $("#txt_PurposeFor").val(),
                PurposeFor: $("#ddl_PurposeFor").val(),
                PurposeDescription: divPurposeDescription,
                RequisiteSpecification: divRequisiteSpesification,
                ExpectedEffect: divExpectedEffect,
                CoordinatorName: $("#txt_CoordinatorName").val(),
                CoordinatorSection: $("#txt_CoordinatorSection").val(),
                DecisionLevel: $("input[name='DecisionLevel']:checked").val(),
                DisposalResponsible: $("input[name='deptDisposal']:checked").val(),

                BudgetAmount: $("#txt_AmountBudget").val(),
                BudgetType: $("#ddl_BudgetType").val(),


                Payment: {
                    CAPEX: {
                        FY1: {
                            Q1: $("#CAPEX_FY1_Q1").val(),
                            Q2: $("#CAPEX_FY1_Q2").val(),
                            Q3: $("#CAPEX_FY1_Q3").val(),
                            Q4: $("#CAPEX_FY1_Q4").val()
                        },
                        FY2: {
                            Q1: $("#CAPEX_FY2_Q1").val(),
                            Q2: $("#CAPEX_FY2_Q2").val(),
                            Q3: $("#CAPEX_FY2_Q3").val(),
                            Q4: $("#CAPEX_FY2_Q4").val()
                        },
                        FY3: {
                            Q1: $("#CAPEX_FY3_Q1").val(),
                            Q2: $("#CAPEX_FY3_Q2").val(),
                            Q3: $("#CAPEX_FY3_Q3").val(),
                            Q4: $("#CAPEX_FY3_Q4").val()
                        },
                        Total: $("#CAPEX_TOTAL").val()
                    },

                    // EXPENSE
                    EXPENSE: {
                        FY1: {
                            Q1: $("#EXP_FY1_Q1").val(),
                            Q2: $("#EXP_FY1_Q2").val(),
                            Q3: $("#EXP_FY1_Q3").val(),
                            Q4: $("#EXP_FY1_Q4").val()
                        },
                        FY2: {
                            Q1: $("#EXP_FY2_Q1").val(),
                            Q2: $("#EXP_FY2_Q2").val(),
                            Q3: $("#EXP_FY2_Q3").val(),
                            Q4: $("#EXP_FY2_Q4").val()
                        },
                        FY3: {
                            Q1: $("#EXP_FY3_Q1").val(),
                            Q2: $("#EXP_FY3_Q2").val(),
                            Q3: $("#EXP_FY3_Q3").val(),
                            Q4: $("#EXP_FY3_Q4").val()
                        },
                        Total: $("#EXP_TOTAL").val()
                    },

                    // TOTAL ROW
                    TOTAL: {
                        FY1: {
                            Q1: $("#TOTAL_FY1_Q1").val(),
                            Q2: $("#TOTAL_FY1_Q2").val(),
                            Q3: $("#TOTAL_FY1_Q3").val(),
                            Q4: $("#TOTAL_FY1_Q4").val()
                        },
                        FY2: {
                            Q1: $("#TOTAL_FY2_Q1").val(),
                            Q2: $("#TOTAL_FY2_Q2").val(),
                            Q3: $("#TOTAL_FY2_Q3").val(),
                            Q4: $("#TOTAL_FY2_Q4").val()
                        },
                        FY3: {
                            Q1: $("#TOTAL_FY3_Q1").val(),
                            Q2: $("#TOTAL_FY3_Q2").val(),
                            Q3: $("#TOTAL_FY3_Q3").val(),
                            Q4: $("#TOTAL_FY3_Q4").val()
                        },
                        Total: $("#TOTAL_ALL").val()
                    }
                },


                FileContentOverview: fileContentOverview,
                FileNameContentOverview: $("#fileContentOverview").val(),
                FileSchedule: fileSchedule,
                FileNameSchedule: $("#fileSchedule").val(),
                FileBiddingDocument: fileBiddingDocument,
                FileNameBiddingDocument: $("#fileBiddingDocument").val(),
            };

            // Tampilkan loading sebelum AJAX dijalankan
            Swal.fire({
                title: 'Saving your data...',
                text: 'Please wait',
                width: '60rem',
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    confirmButton: 'swal-btn-big',
                    icon: 'swal-icon-big'
                },
                didOpen: () => {
                    Swal.showLoading();
                }
            });


            $.ajax({
                url: '/AFDCoverLetter/SaveDraft',
                type: 'POST',
                data: JSON.stringify(model),
                contentType: "application/json; charset=utf-8",
                success: function (result) {


                    Swal.close(); // MATIKAN LOADING

                    $("#txt_CoverLetterID").val(result.afd_id);
                    $("#btnSaveFirst").addClass("hidden");
                    $("#btnSaveDraft").removeClass("hidden");
                    $("#btnDeleteData").removeClass("hidden");



                    $("#ddl_AFDType").prop("disabled", true);
                    $("#ddl_AFDSubType").prop("disabled", true);
                    $("#ddl_Category").prop("disabled", true);
                     
                    console.log("Redirect CoverLetterID:", result.afd_id);
                    window.location.href = '/AFDCoverLetter/Index?CoverLetterId=' + result.afd_id;


                },
                error: function (xhr) {


                    Swal.close(); // MATIKAN LOADING


                    Swal.fire({
                        icon: 'error',
                        title: 'Your data cannot be saved as a draft.',
                        text: xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText,
                        width: '80rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            icon: 'swal-icon-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });

                }

            });



        });

        async function saveDraftAsync(showSuccessPopup = true) {

            // ================= VALIDASI REQUIRED =================
            let isValid = ValidasiRequiredInput();
            if (!isValid) {
                Swal.fire({
                    icon: 'warning',
                    title: "This field cannot be empty.",
                    width: '60rem'
                });
                throw "Required validation failed";
            }

            // ================= FORMAT NUMBER =================
            let AmountBudget = ($("#txt_AmountBudget").val() || "").replace(/,/g, '');
            let Rate = ($("#txt_Rate").val() || "").replace(/,/g, '');

            // ================= MODEL =================
            var model = {
                CoverLetterID: $("#txt_CoverLetterID").val(),
                FiscalYear: $("#txt_FiscalYear").val(),
                DateOfProposal: $("#dtp_DateOfProposal").val(),
                DateOfDecision: $("#dtp_DateofDecision").val(),
                DecisionNumber: $("#txt_DecisionNumber").val(),
                Title: $("#txt_Title").val(),
                AFDType: $("#ddl_AFDType").val(),
                AFDSubType: $("#ddl_AFDSubType").val(),
                FormAFDID: $("#txt_FormAFDID").val(),
                CostSection: $("#ddl_CostSection").val(),
                NIKLogin: $("#txt_NIKLogin").val(),
                AmountBudgetID: $("#span_BudgetFinalID").html(),
                Rate: Rate,
                Place: $("#txt_Place").val(),
                PeriodeCommencement: $("#dtp_PeriodeCommencement").val(),
                PeriodeCompletion: $("#dtp_PeriodeCompletion").val(),
                PurposeFor: $("#ddl_PurposeFor").val(),
                PurposeDescription: $('#divPurposeDescription').summernote('code'),
                RequisiteSpecification: $('#divRequisiteSpesification').summernote('code'),
                ExpectedEffect: $('#divExpectedEffect').summernote('code'),
                CoordinatorName: $("#txt_CoordinatorName").val(),
                CoordinatorSection: $("#txt_CoordinatorSection").val(),
                DecisionLevel: $("input[name='DecisionLevel']:checked").val(),
                DisposalResponsible: $("input[name='deptDisposal']:checked").val(),
                AmountBudget: AmountBudget,
                BudgetType: $("#ddl_BudgetType").val(),

                Payment: {
                    CAPEX: {
                        FY1: { Q1: $("#CAPEX_FY1_Q1").val(), Q2: $("#CAPEX_FY1_Q2").val(), Q3: $("#CAPEX_FY1_Q3").val(), Q4: $("#CAPEX_FY1_Q4").val() },
                        FY2: { Q1: $("#CAPEX_FY2_Q1").val(), Q2: $("#CAPEX_FY2_Q2").val(), Q3: $("#CAPEX_FY2_Q3").val(), Q4: $("#CAPEX_FY2_Q4").val() },
                        FY3: { Q1: $("#CAPEX_FY3_Q1").val(), Q2: $("#CAPEX_FY3_Q2").val(), Q3: $("#CAPEX_FY3_Q3").val(), Q4: $("#CAPEX_FY3_Q4").val() }
                    },
                    EXPENSE: {
                        FY1: { Q1: $("#EXP_FY1_Q1").val(), Q2: $("#EXP_FY1_Q2").val(), Q3: $("#EXP_FY1_Q3").val(), Q4: $("#EXP_FY1_Q4").val() },
                        FY2: { Q1: $("#EXP_FY2_Q1").val(), Q2: $("#EXP_FY2_Q2").val(), Q3: $("#EXP_FY2_Q3").val(), Q4: $("#EXP_FY2_Q4").val() },
                        FY3: { Q1: $("#EXP_FY3_Q1").val(), Q2: $("#EXP_FY3_Q2").val(), Q3: $("#EXP_FY3_Q3").val(), Q4: $("#EXP_FY3_Q4").val() }
                    }
                }
            };

            // ================= FORM DATA =================
            var formData = new FormData();

            // model json
            formData.append("model", JSON.stringify(model));

            // file upload
            var file1 = $("#fileContentOverview")[0].files[0];
            var file2 = $("#fileSchedule")[0].files[0];
            var file3 = $("#fileBiddingDocument")[0].files[0];

            if (file1) formData.append("fileContentOverview", file1);
            if (file2) formData.append("fileSchedule", file2);
            if (file3) formData.append("fileBiddingDocument", file3);

            // ================= LOADING =================
            Swal.fire({
                title: 'Saving your data...',
                html: 'Please wait...',
                width: '650px',
                allowOutsideClick: false,
                allowEscapeKey: false,
                didOpen: () => Swal.showLoading()
            });

            // ================= AJAX =================
            return new Promise((resolve, reject) => {

                $.ajax({
                    url: '/AFDCoverLetter/SaveDataChanges',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,

                    success: function (result) {

                        Swal.close();

                        $("#txt_CoverLetterID").val(result.afd_id);
                        $("#btnSaveFirst").addClass("hidden");
                        $("#btnSaveDraft").removeClass("hidden");
                        $("#div_btnPreviewCoverLetter").removeClass("hidden");

                        if (showSuccessPopup) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Draft has been saved successfully',
                                width: '80rem'
                            });
                        }

                        resolve(result);
                    },

                    error: function (xhr) {

                        Swal.close();

                        Swal.fire({
                            icon: 'error',
                            title: 'Your data cannot be changed',
                            text: xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText,
                            width: '80rem'
                        });

                        reject(xhr);
                    }
                });

            });
        }


        $("#btnSaveDraft").click(async function () {
            await saveDraftAsync(true);
        });

        $("#btnSubmit").click(async function () {

             //validasi jika yg login adalah approver, maka tidak bisa save data
            if (xflagcreate != 0) {
                await saveDraftAsync(false);
            } 
            //end of


            var xCoverLetterId = $("#txt_CoverLetterID").val();
            var xDecisionDate = $("#dtp_DateofDecision").val();
            var xDecisionNumber = $("#txt_DecisionNumber").val();
            var xDecisionStatus = $('input[name="DecisionStatus"]:checked').val();


            //validasi jika yg login mempnuyai hak input decision number
            if (!$('#txt_DecisionNumber').prop('disabled')) {

                var decisionNumber = $('#txt_DecisionNumber').val();
                if (!decisionNumber || decisionNumber.trim() === '') {

                    Swal.fire({
                        icon: 'warning',
                        title: "Decision Number is required.",
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    });

                    return; // stop proses
                }
            } else {
                decisionNumber = 'NOT USE'
            }


            //validasi jika yg login mempunyai hak akses Decision by 
            if (!$('input[name="DecisionStatus"]').is(':disabled')) {
                var decisionStatus = $('input[name="DecisionStatus"]:checked').val();

                if (!decisionStatus || decisionStatus.trim() === '') {

                    Swal.fire({
                        icon: 'warning',
                        title: "Decision Status is required.",
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    });

                    return; // stop proses
                }

            } else {
                decisionStatus = 'NOT USE'
            }



            $.ajax({
                url: '/AFDCoverLetter/SubmitData',
                type: 'POST',
                data: {
                    CoverLetterId: xCoverLetterId,
                    DecisionDate: xDecisionDate,
                    DecisionNumber: xDecisionNumber,
                    DecisionStatus: xDecisionStatus,
                },
                success: function (result) {


                    Swal.fire({
                        icon: result.status,
                        title: result.message,
                        text: result.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    }).then(() => {

                        if (result.status == "success") {
                            $("#div_btnAction").remove();


                            setTimeout(function () {
                               /* window.location.href = urlIndexAFDCL;   // redirect*/
                                 
                                location.reload();

                            }, 800); // 800 ms delay supaya tidak terasa hang
                        }

                    });


                },

            });
        });


        $("#btnDeleteData").click(function () {

            var xCoverLetterId = $("#txt_CoverLetterID").val();

            $.ajax({
                url: '/AFDCoverLetter/DeleteData',
                type: 'POST',
                data: {
                    CoverLetterId: xCoverLetterId
                },
                success: function (result) {


                    Swal.fire({
                        icon: result.status,
                        title: result.message,
                        text: result.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    }).then(() => {

                        if (result.status == "success") {
                            $("#div_btnAction").remove();
                            setTimeout(function () {
                                window.location.href = urlIndexAFDCL;   // redirect
                            }, 1000); // 800 ms delay supaya tidak terasa hang
                        }

                    });


                },

            });

        });


        $("#btnReturn").click(function () {

            // Tampilkan modal
            $("#modalReturnReason").modal("show");
             
        });


        // ===== GLOBAL FUNCTION =====
        const toBase64 = (file) => {
            if (!file) return Promise.resolve(null);

            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result.split(',')[1]);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        };



        $("#fileReturn").change(async function () {  
            return false;
            var file = this.files[0];
            var base64 = await toBase64(file);
            console.log(base64);
        });



        $("#btnOKReturnReason").click(async function () {

            var xCoverLetterId = $("#txt_CoverLetterID").val();
            var xReturnReason = $('#divReturnReason').summernote('code');
            var FiscalYear = $("#txt_FiscalYear").val();
            var AFDType = $("#ddl_AFDType").val();
            var AFDSubType = $("#ddl_AFDSubType").val();
            var CostSection = $("#txt_CostSection").val();

            const fileInput = $("#fileReturn")[0];

            let fileBase64 = null;
            let fileName = null;

            // ✅ jika ada file
            if (fileInput && fileInput.files.length > 0) {
                const file = fileInput.files[0];
                fileBase64 = await toBase64(file);
                fileName = file.name;
            }

            $("#btnCancelReturnReason").trigger("click");

            $.ajax({
                url: '/AFDCoverLetter/ReturnData',
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify({
                    CoverLetterId: parseInt(xCoverLetterId),
                    ReturnReason: xReturnReason,
                    FileBase64Return: fileBase64,   // bisa null
                    FileNameReturn: fileName,       // bisa null
                    FiscalYear: parseInt(FiscalYear),
                    AFDType: AFDType,
                    AFDSubType: AFDSubType,
                    CostSection: CostSection
                }),
                success: function (result) {
                    Swal.fire({
                        icon: result.status,
                        title: result.message,
                        text: result.solution,
                        width: '60rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            confirmButton: 'swal-btn-big',
                            icon: 'swal-icon-big'
                        }
                    }).then(() => {
                        if (result.status === "success") {
                            $("#div_btnAction").remove();
                            setTimeout(function () {
                                location.reload();
                            }, 1000);
                        }
                    });
                },
                error: function (err) {
                    console.error(err);
                }
            });

        });
          
        function ValidasiRequiredInput() {


            var ddl_AFDType = $("#ddl_AFDType").val();
            var ddl_AFDSubType = $("#ddl_AFDSubType").val();
            var ddl_Category = $("#ddl_Category").val();
            var AmountBudget = $("#txt_AmountBudget").val();
            var txt_Title = $("#txt_Title").val();
            var txt_Place = $("#txt_Place").val();
            var dtp_PeriodeCommencement = $("#dtp_PeriodeCommencement").val();
            var dtp_PeriodeCompletion = $("#dtp_PeriodeCompletion").val();
            var ddl_PurposeFor = $("#ddl_PurposeFor").val();
            var Disposal_Responsible = $("input[name='deptDisposal']:checked").val() || "";


            if (ddl_AFDType == "") { $("#ddl_AFDType").focus(); return false }
            if (ddl_AFDSubType == "") { $("#ddl_AFDSubType").focus(); return false }
            if (ddl_Category == "") { $("#ddl_AFDSubType").focus(); return false }
            if (txt_Title == "") { $("#txt_Title").focus(); return false }
            if (txt_Place == "") { $("#txt_Place").focus(); return false }
            if (AmountBudget == "" || AmountBudget < 0.1) { $("#txt_AmountBudget").focus(); return false }
            if (dtp_PeriodeCommencement == "") { $("#dtp_PeriodeCommencement").focus(); return false }
            if (dtp_PeriodeCompletion == "") { $("#dtp_PeriodeCompletion").focus(); return false }
            if (ddl_PurposeFor == "") { $("#ddl_PurposeFor").focus(); return false }



            if (ddl_AFDType === "DISPOSAL" && !Disposal_Responsible) {
                // highlight label
                $("#lblDisposal").css({ "color": "red" });
                $("#txt_AmountBudget").prop("disabled", false);
                return false;
            } else {
                // reset jika valid
                $("#lblDisposal").css({ "color": "", });
                $("#txt_AmountBudget").prop("disabled", true);
            }

            return true; // ← WAJIB ADA!
        }

        function ValidasiInputanAmountBudget() {
            let amount = parseFloat($("#txt_AmountBudget").val().replace(/,/g, '')) || 0;
            let minAmount = parseFloat($("#span_MinAmount").text().replace(/,/g, '')) || 0;
            let maxAmount = parseFloat($("#span_MaxAmount").text().replace(/,/g, '')) || 0;

            console.log("amount :" + amount);
            console.log("minAmount :" + minAmount);
            console.log("maxAmount :" + maxAmount);

            let isValid = !(amount < minAmount || amount > maxAmount);

            return {
                isValid: isValid,
                minAmount: minAmount,
                maxAmount: maxAmount
            };




        }


        //**********************************  end of  ACTION BUTTON







        //**********************************  TRIGGER SAAT LOAD AWAL
         

        //set datenow
        var IDDataAFD = $("#txt_CoverLetterID").val();
        let today = new Date().toISOString().split('T')[0];

        if (IDDataAFD === "") {
            $("#dtp_DateOfProposal").val(today);

            var proposalDate = $("#dtp_DateOfProposal").val();
            $("#dtp_PeriodeCommencement").attr("min", proposalDate);
            $("#dtp_PeriodeCompletion").attr("min", proposalDate);
        }

        generateFiscalYear();
        var tgl = $("#dtp_DateOfProposal").val();
        var btnName = $("#txt_DateOfProposal");
        formatTanggal(tgl, btnName);


        // isi coordinator name & coordinator section   
        function getAFDCoordinator() {

           
            var xNIKLogin = ($("#txt_NIKLogin").val() || "").trim();
            var xCostSection = $("#ddl_CostSection").val();

            $.ajax({
                url: "/AFDCoverLetter/GetCoordinator",
                type: "GET",
                data: {
                    NIKLogin: xNIKLogin,
                    CostSection : xCostSection
                },
                success: function (res) {
                    if (res.status === "error") {

                        Swal.fire({
                            icon: 'warning',
                            title: res.message,
                            text: res.solution,
                            width: '60rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });

                        $("#txt_CostSection").val("").prop("disabled", true);

                        return;

                    } else {

                        // jika tidak error
                        let nilai = res.data;

                        var CoordinatorName = (nilai[0]?.Coordinator_Name || "").trim();
                        var CoordinatorSection = (nilai[0]?.Coordinator_Section || "").trim();
                     

                        $("#txt_CoordinatorName").val(CoordinatorName).prop("disabled", true);
                        $("#txt_CoordinatorSection").val(CoordinatorSection).prop("disabled", true);

                    }
                }
            });
        }


        //validasi auto get data jika ada query string
        function getQueryParam(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

 
        var coverLetterId = getQueryParam("CoverLetterId");
        $("#txt_CoverLetterID").val(coverLetterId);


        if (coverLetterId != null && coverLetterId !== "") { 
            $("#div_inputan").removeClass("hidden");
            $("#div_AFDType").removeClass("hide");
            $("#div_Category").removeClass("hidden");
            $("#btn_SearchMasterBudget").removeClass("hidden");
            $("#btnSaveFirst").addClass("hidden");

            getCoverLetter(coverLetterId); // <-- kirim ID yang benar 
        }


        function getCoverLetter(id) {
            $.ajax({
                url: "/AFDCoverLetter/GetCoverLetter",
                type: "GET",
                data: {
                    CoverLetterId: id
                },
                success: function (res) {
                    if (res.status === "success") {

                        //HEADER
                        var decisionBy = res.AFD.xDecision_By;
                        $("input[name='DecisionLevel'][value='" + decisionBy + "']").prop("checked", true);
                        $("input[name='DecisionLevel']").prop("disabled", true);


                        var decisionStatus = res.AFD.xDecision_Status;
                        $("input[name='DecisionStatus'][value='" + decisionStatus + "']").prop("checked", true);

                        //$("input[name='DecisionStatus']").prop("disabled", true);
                


                        $("#txt_CoverLetterID").val(res.AFD.xAFD_ID);
                        $("#btnPreviewCoverLetter").attr("href", "/AFDCoverLetter/PrintCoverLetter?CoverLetterId=" + res.AFD.xAFD_ID);
                        $("#txt_FiscalYear").val(res.AFD.xFiscal_Year);

                        var xProposalDate = res.AFD.xProposal_Date;
                        $("#dtp_DateOfProposal").val(xProposalDate);
                        formatTanggal(xProposalDate, "#txt_DateOfProposal");

                        var xDecision_Date = res.AFD.xDecision_Date;
                        $("#dtp_DateofDecision").val(xDecision_Date);
                        formatTanggal(xDecision_Date, "#txt_DateofDecision");

                        $("#txt_DecisionNumber").val(res.AFD.xDecision_Number);
                        $("#txt_Title").val(res.AFD.xTitle);

                        $("#txt_FormAFDID").val(res.AFD.xForm_AFD_ID);


                        $("#txt_CostSection").removeClass("hidden");
                        $("#txt_CostSection").val(res.AFD.xCost_Section); 


                        $("#txt_AmountBudget").val(res.AFD.xBudget_Amount_Master);
                        $("#span_AmountBudget").html(" (" + res.AFD.xBudget_Type + ") ");
                        $("#span_BudgetFinalID").html(res.AFD.xBudget_Final_ID);
                        $("#txt_Rate").val(res.AFD.xExchangeRate_USD);
                        $("#txt_RateFY").html(" (FY " + res.AFD.xFiscal_Year + ") ");

                        $("#txt_Place").val(res.AFD.xPlace);

                        var xPeriod_Commencement = res.AFD.xPeriod_Commencement;
                        $("#dtp_PeriodeCommencement").val(xPeriod_Commencement);
                        formatTanggal(xPeriod_Commencement, "#txt_PeriodeCommencement");

                        var xPeriod_Completion = res.AFD.xPeriod_Completion;
                        $("#dtp_PeriodeCompletion").val(xPeriod_Completion);
                        formatTanggal(xPeriod_Completion, "#txt_PeriodeCompletion");

                        $("#divPurposeDescription").summernote("code", res.AFD.xPurpose_Description);
                        $("#divRequisiteSpesification").summernote("code", res.AFD.xSpecification_Requisite);
                        $("#divExpectedEffect").summernote("code", res.AFD.xExpected_Effect);

                        //disabled jika yg login bukan PIC
                        if (xflagcreate == 0 ) { 
                            $('#divPurposeDescription').summernote('disable');
                            $('#divRequisiteSpesification').summernote('disable');
                            $('#divExpectedEffect').summernote('disable');

                            $('#summernote')
                                .next('.note-editor')
                                .find('.note-editable')
                                .css('background-color', '#fff3cd');
                        }


                      


                        //$("#txt_PurposeFor").val(res.AFD.xPurpose_Type);
                        $("#ddl_PurposeFor").val(res.AFD.xPurpose_Type).trigger("change").prop("disabled", true);

                         
                        // Jalankan AJAX dengan promise
                        $.when(
                            getAFDSubType(res.AFD.xAFD_Type),     // load ddl Sub Type
                            getAFDCategory() ,                       // load category
                            //getAFDCostSection(),                       // load cost section
                            
                        ).done(function () {


                            // Set value setelah semua dropdown ter-load
                            $("#ddl_AFDType").val(res.AFD.xAFD_Type);
                            $("#ddl_AFDSubType").val(res.AFD.xAFD_SubType);
                            $("#ddl_Category").val(res.AFD.xForm_AFD_Category);

                     
                            //set jika disposal
                            if (res.AFD.xAFD_Type == "DISPOSAL") {
                                $("#span_AmountBudget").html("(Additional)");
                            };



                            //get Rate
                            var xFiscalYear = res.AFD.xFiscal_Year;
                            var xCurrencyCode = "USD";
                            GetRate(xFiscalYear, xCurrencyCode)



                            //set path document
                            var urlContentOverview = res.AFD.xPath_Content_Overview;
                            $("#link_fileContentOverview").attr("href", urlContentOverview);

                            var urlPathSchedule = res.AFD.xPath_Schedule;
                            $("#link_fileSchedule").attr("href", urlPathSchedule);

                            var urlPathBiddingDocument = res.AFD.xPath_Bidding_Document;
                            $("#link_fileBiddingDocument").attr("href", urlPathBiddingDocument);


                            var filenameContentOverview = decodeURIComponent(urlContentOverview.split('/').pop());
                            var filenamePathSchedule = decodeURIComponent(urlPathSchedule.split('/').pop());
                            var filenamePathBiddingDocument = decodeURIComponent(urlPathBiddingDocument.split('/').pop());

                            if (filenameContentOverview != "") { $("#link_fileContentOverview").removeClass("hidden"); }
                            if (filenamePathSchedule != "") { $("#link_fileSchedule").removeClass("hidden"); }
                            if (filenamePathBiddingDocument != "") { $("#link_fileBiddingDocument").removeClass("hidden"); }


                        });




                        //PAYMENT 
                        $("#div_Payment").removeClass("hidden");

                        // --- SET FISCAL YEAR ---
                        $("#span_PaymentFY1").html(res.Payment[0].FiscalYear);
                        $("#span_PaymentFY2").html(res.Payment[4].FiscalYear);
                        $("#span_PaymentFY3").html(res.Payment[8].FiscalYear);

                        //FOR DEBUGING
                        //console.log("=== PAYMENT CHECK ===");
                        //console.log("Length:", res.Payment.length);
                        //console.log(res.Payment);




                        // --- LOOP UNTUK CAPEX & EXP ---
                        ["CAPEX", "EXP"].forEach(type => {
                            for (let fy = 1; fy <= 3; fy++) {
                                for (let q = 1; q <= 4; q++) {

                                    // Hitung index array Payment
                                    let index = (fy - 1) * 4 + (q - 1);

                                    // Pilih key data
                                    let key = (type === "CAPEX") ? "CapitalExpense" : "Expense";

                                    // Build selector
                                    let selector = `#${type}_FY${fy}_Q${q}`;


                                    //FOR DEBUGING
                                    //console.log(
                                    //    "selector =", selector,
                                    //    "| index =", index,
                                    //    "| key =", key,
                                    //    "| value =", res.Payment[index] ? res.Payment[index][key] : "undefined",
                                    //    "| element exists =", $(selector).length
                                    //);



                                    // Isi value
                                    //$(selector).val(res.Payment[index][key]); 
                                    //$(selector).addClass("text-right");


                                    setValueOrBlank(selector, res.Payment[index][key]);

                                }
                            }
                        });

                        // --- Hitung TOTAL per Quarter ---
                        for (let fy = 1; fy <= 3; fy++) {
                            for (let q = 1; q <= 4; q++) {

                                let capex = parseFloat($(`#CAPEX_FY${fy}_Q${q}`).val()) || 0;
                                let exp = parseFloat($(`#EXP_FY${fy}_Q${q}`).val()) || 0;

                                let total = capex + exp;

                                //$(`#TOTAL_FY${fy}_Q${q}`).val(total.toFixed(1)); 
                                //$(`#TOTAL_FY${fy}_Q${q}`).addClass("text-right");

                                setValueOrBlank(`#TOTAL_FY${fy}_Q${q}`, total);

                            }
                        }

                        // ---  Hitung GRAND TOTAL  ---
                        calculateGrandTotal();
                        function calculateGrandTotal() {

                            let grandTotal = 0;

                            for (let fy = 1; fy <= 3; fy++) {
                                for (let q = 1; q <= 4; q++) {

                                    let val = parseFloat($(`#TOTAL_FY${fy}_Q${q}`).val()) || 0;
                                    grandTotal += val;
                                }
                            }

                            //$("#TOTAL_ALL").val(grandTotal.toFixed(1));
                            //$("#TOTAL_ALL").addClass("text-right");

                            setValueOrBlank("#TOTAL_ALL", grandTotal);


                        }

                        // ---  Hitung GRAND TOTAL BARIS  ---
                        calculateRowTotal();
                        function calculateRowTotal() {

                            let capexTotal = 0;
                            let expTotal = 0;

                            for (let fy = 1; fy <= 3; fy++) {
                                for (let q = 1; q <= 4; q++) {

                                    capexTotal += parseFloat($(`#CAPEX_FY${fy}_Q${q}`).val()) || 0;
                                    expTotal += parseFloat($(`#EXP_FY${fy}_Q${q}`).val()) || 0;
                                }
                            }

                            //$("#CAPEX_TOTAL").val(capexTotal.toFixed(1));
                            //$("#EXP_TOTAL").val(expTotal.toFixed(1));

                            //$("#CAPEX_TOTAL").addClass("text-right");
                            //$("#EXP_TOTAL").addClass("text-right");


                            setValueOrBlank("#CAPEX_TOTAL", capexTotal);
                            setValueOrBlank("#EXP_TOTAL", expTotal);

                        }


                        function setValueOrBlank(selector, value, decimals = 1) {
                            let num = parseFloat(value) || 0;
                            $(selector).val(num === 0 ? "" : num.toFixed(decimals));
                            $(selector).addClass("text-right");
                        }











                        //// Trigger event setelah semua di-set
                        //$(".inputamt").trigger("input");
                        console.log(res.AFD.xDisposal_Responsible)

                        if (res.AFD.xAFD_Type == "DISPOSAL") {
                            $("#div_ResponsibleforDisposal").removeClass("hidden");
                            $("input[name='deptDisposal'][value='" + res.AFD.xDisposal_Responsible + "']").prop("checked", true);
                        }

                        var BudgetType = res.AFD.xBudget_Type
                        console.log(BudgetType);
                        $("#ddl_BudgetType")
                            .val(BudgetType)
                            .prop("disabled", true);


                        var AFDCategory = res.AFD.xForm_AFD_Category
                        console.log(AFDCategory);
                        $("#ddl_Category")
                            .val(AFDCategory)
                            .prop("disabled", true);


                        //VALIDASI 
                        var FlagDraft = res.AFD.xFlag_Draft;
                        if (FlagDraft == 1) {
                            $("#btnDeleteData").removeClass("hidden");
                            $("#btnSaveFirst").addClass("hidden");
                            $("#btnSaveDraft").removeClass("hidden");
                        }

                        //VALIDASI NON EDITABLE
                        $("#btn_SearchMasterBudget").remove();
                        $("#ddl_AFDType").prop("disabled", true);
                        $("#ddl_AFDSubType").prop("disabled", true);
                        $("#ddl_Category").prop("disabled", true);


                        if (res.AFD.xAFD_Type == "CAPITAL INVESTMENT") {
                            $("#div_Attach1").removeClass("hidden");
                            $("#div_Attach2").removeClass("hidden");
                            $("#div_Attach3").removeClass("hidden");
                            $("#div_Attach4").removeClass("hidden");
                            $("#div_Attach5").removeClass("hidden");


                            $("#span_Attach1").html("Attachment File-1 (Content Overview) :");
                            $("#span_Attach2").html("Attachment File-1 (Content Overview) :");
                            $("#span_Attach3").html("Attachment File-3 (Schedule) :");
                            $("#span_Attach4").html("Attachment File-1 (Content Overview) :");
                            $("#span_Attach5").html("Attachment File-5 (Bidding Document) :");
                        }

                        if (res.AFD.xAFD_Type == "DISPOSAL") {
                            $("#div_Attach1").removeClass("hidden");
                            $("#div_Attach3").removeClass("hidden");
                            $("#div_Attach5").removeClass("hidden");


                            $("#span_Attach1").html("Attachment File-1 (List of Fix Asset) :");
                            $("#span_Attach3").html("Attachment File-2 (Schedule) :");
                            $("#span_Attach5").html("Attachment File-3 (Item Disposal) :");
                        }


                        $("#div_btnPreviewCoverLetter").removeClass("hidden");

 

                        $("#txt_CoordinatorName").val(res.AFD.xCoordinator_Name);
                        console.log(res.AFD.xCoordinator_Name);
                        $("#txt_CoordinatorSection").val(res.AFD.xCoordinator_Section);
                        console.log(res.AFD.xCoordinator_Section);
                        //end of
                         

                    } else {

                        Swal.fire({
                            icon: 'warning',
                            title: res.message,
                            text: '',
                            width: '40rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                icon: 'swal-icon-big',
                                confirmButton: 'swal-btn-big'
                            }
                        });

                        $("#div_rb_decision").remove();
                        $("#div_inputan").remove();
                       
                    }
                }
            });

        }





        //**********************************  end of TRIGGER SAAT LOAD AWAL



        //DECISION NUMBER
        $("#txt_DecisionNumber").on("input", function () {
            let v = $(this).val().toUpperCase();   // otomatis kapital
            v = v.replace(/-/g, "");               // hilangkan semua '-' sebelum format ulang

            // Pola: 1 huruf - 2 angka - 2 angka - 1 huruf - 1 huruf
            let formatted = "";

            if (v.length > 0) formatted += v.substring(0, 1);
            if (v.length > 1) formatted += "-" + v.substring(1, 3);
            if (v.length > 3) formatted += "-" + v.substring(3, 5);
            if (v.length > 5) formatted += "-" + v.substring(5, 7);

            $(this).val(formatted);
        });
        //END OF


        //VALIDASI FORMAT INPUTAN BUDGET AMOUNT 
        let lastValidValue_BudgetAmount = "";
        let isAlertShown_BudgetAmount = false;

        //format: max 1 decimal
        function isValidAmountFormat(value) {
            const regex = /^\d{0,3}(,\d{3})*(\.\d{0,1})?$|^\d*(\.\d{0,1})?$/;
            return regex.test(value);
        }

        //// format: max 3 decimal
        //function isValidAmountFormat(value) {
        //    const regex = /^\d{0,3}(,\d{3})*(\.\d{0,3})?$|^\d*(\.\d{0,3})?$/;
        //    return regex.test(value);
        //}

        $("#txt_AmountBudget").on("input", function () {

            $("#ddl_Category").prop("selectedIndex", 0);
            $("#span_ViewAmount").html("");

            let currentValue = $(this).val();

            // kosong dianggap valid
            if (currentValue === "") {
                lastValidValue_BudgetAmount = "";
                isAlertShown_BudgetAmount = false;
                return;
            }

            if (!isValidAmountFormat(currentValue)) {

                // rollback ke nilai terakhir yang valid
                $(this).val(lastValidValue_BudgetAmount);

                if (!isAlertShown_BudgetAmount) {

                    isAlertShown_BudgetAmount = true; // set dulu supaya tidak double popup

                    Swal.fire({
                        icon: 'warning',
                        title: 'Invalid Format',
                        text: 'Please enter a number with up to 1 decimal place only.',
                        confirmButtonText: 'OK',
                        width: '80rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            icon: 'swal-icon-big',
                            confirmButton: 'swal-btn-big'
                        }
                    }).then(() => {
                        // reset setelah klik OK
                        isAlertShown_BudgetAmount = false;
                    });

                }

            } else {
                // simpan nilai valid
                lastValidValue_BudgetAmount = currentValue;
            }

        });
        //END OF


    }

 }); //END OF DOCUMENT
