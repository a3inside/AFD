﻿$(document).ready(function () {


 

    //**********************************  LIST OF STATUS PROGRESS AFD
     
    if (typeof InitialPage !== "undefined" && InitialPage === "IndexListStatusAFD") {
     
        
        // Trigger setiap dropdown berubah
        $("#ddlFiscalYear, #ddlTypeAFD, #ddlDepartment").on("change", function () {
            toggleButtonFilter();
        });
 

        function toggleButtonFilter() {
            let fiscalYear = $("#ddlFiscalYear").val();
            //let typeAFD = $("#ddlTypeAFD").val();
            var typeAFD = $("input[name='TypeAFD']:checked").val();
            let department = $("#ddlDepartment").val();

            if (fiscalYear && typeAFD && department) {
                $("#btnShowData").removeClass("hidden");
            } else { 
                $("#btnShowData").addClass("hidden");
            }
        }


        $(document).on("change", "#ddlDepartment", function () {
        let dept = $(this).val();

        $("#ddlCostSection").empty()
            .append('<option value=""><< select options >></option>');

        if (dept === "") return;

        $.ajax({ 
            url: "/AFDCoverLetter/DDLCostSection",
            type: 'GET',
            data: { dept: dept },
            success: function (res) {

                //console.log(res);

                $("#ddlCostSection")
                    .empty()
                    .append('<option value="ALL">ALL</option>');

                $.each(res, function (i, v) {
                    $("#ddlCostSection").append(
                        $("<option>").val(v).text(v)
                    );
                });
                 
            },
            error: function () { 

                Swal.fire({
                    icon: 'error',
                    title: 'Failed load Cost Section',
                    text: ' ',
                    confirmButtonText: 'OK',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

            }
        });
    });
         
        $('#btnShowData').click(function () {

            let param = {
                fiscalYear: $('#ddlFiscalYear').val(),
                //typeAFD: $('#ddlTypeAFD').val(),
                typeAFD : $("input[name='TypeAFD']:checked").val(),
                department: $('#ddlDepartment').val(),
                costSection: $('#ddlCostSection').val()
            };

            $.ajax({
                url: "/AFDCoverLetter/GetListProgressAFD",
                type: 'GET',
                data: param,
                beforeSend: function () {
                    $('#tblBody').html(`
                    <tr>
                        <td colspan="21" class="text-center">
                            Loading...
                        </td>
                    </tr>
                `);
                },
                success: function (res) {
                    let html = '';
                    var FlagReapplication = '';


                    if (res.length === 0) {
                        html = `
                        <tr>
                            <td colspan="21" class="text-center text-muted">
                                No Data Found
                            </td>
                        </tr>`;
                    } else {
                        $.each(res, function (i, item) {

                            let statusBadge = 'secondary';
                            if (item.StatusProgress === 'Finished') statusBadge = 'success';
                            else if (item.StatusProgress === 'Approval In Progress') statusBadge = 'warning';

                            html += `
                        <tr>
                            <td>${item.Dept_Name}</td>
                            <td>${item.Cost_Section}</td>
                            <td style='max-width:150px'>${item.AFD_Title}</td>
                            <td>${item.Decision_Number}</td>
                            <td>${item.AFD_Type}</td>
                            <td>${item.Budget_Type}</td> 
                            <td class="text-end" style='text-align:right'>  $ ${Number(item.Budget_Amount || 0).toLocaleString()}</td>  
                            <td class="text-end" style='text-align:right'>  $ ${Number(item.Capital_Expense_Amount || 0).toLocaleString()}</td>  
                            <td class="text-end" style='text-align:right'>  $ ${Number(item.Expense_Amount || 0).toLocaleString()}</td>  
                            <td class="text-end" style='text-align:right'>  ${Number(item.ExchangeRate_USD || 0).toLocaleString()}</td> 
                            <td>${item.Proposal_Date}</td> 
                            <td>${item.Decision_Date}</td> 
                            <td>${item.Place}</td>
                            <td>${item.Period_Commencement}</td>
                            <td>${item.Period_Completion}</td>
                            <td>${item.Purpose_Type}</td> 
                            <td>${item.Coordinator_Name}</td>  
                            <td>${item.PositionApproval}</td> 
                            <td>${item.StatusProgress}</td> 
                            <td>
                                <a href="${afdCoverLetterUrl}?CoverLetterId=${item.AFD_ID}" class="btn btn-primary"  target="_blank" title="view data"    data-toggle="tooltip"  data-placement="top"  title="Hooray!">  <span class="glyphicon glyphicon-new-window"></span> </a>
                            </td>
  
                            ${item.FlagReapplication === "YES" ? `
                            <td>
                            <a href="#"
                               class="btn btn-warning btn-reapply"
                               data-id="${item.AFD_ID}"
                               data-title="${item.AFD_Title}"
                               title="Re-application">
                               <span class="glyphicon glyphicon-repeat"></span>
                            </a>
                            </td>` : ''}
 
                            </tr>`;
                             
                           
                        });
                    }

                    $('#tblBody').html(html);

                
                    //if (FlagReapplication == "NO") {
                    //    $("#th_ActionList").attr("colspan","1");
                    //    $("#td_Reapplication").remove();
                    //}

                    $('[data-toggle="tooltip"]').tooltip();

                },
                error: function () {
                    alert('Failed to load data');
                }
            });
        }); 


        $(document).on('click', '.btn-reapply', function (e) {
            e.preventDefault(); // stop redirect
            var afdId = $(this).data('id');
            var afdTitle = $(this).data('title');


            Swal.fire({
                title: "Re-Application AFD : " + afdTitle + " ?",
                text: "approval sign will restart from the beginning",
                showCancelButton: true,
                confirmButtonText: "OK",
                cancelButtonText: "Cancel",
                width: '80rem',
                customClass: {
                    title: 'swal-title-big',
                    htmlContainer: 'swal-text-big',
                    icon: 'swal-icon-big',
                    confirmButton: 'swal-btn-big',
                    cancelButton: 'swal-btn-big'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                     

                    $.ajax({
                        url: '/AFDCoverLetter/ReApplication',
                        type: 'POST',
                        data: { coverLetterId: afdId, title: afdTitle },

                        beforeSend: function () {
                            Swal.fire({
                                title: 'Processing...',
                                text: 'Please wait',
                                allowOutsideClick: false,
                                allowEscapeKey: false, 
                                didOpen: () => {
                                    Swal.showLoading();
                                }
                            });
                        },

                        success: function (res) {
                            Swal.close(); // tutup loading

                            if (res.success === true) {

                                Swal.fire({
                                    title: "Ready to start the AFD re-application",
                                    confirmButtonText: "OK",
                                    width: '80rem',
                                    customClass: {
                                        title: 'swal-title-big',
                                        htmlContainer: 'swal-text-big',
                                        icon: 'swal-icon-big',
                                        confirmButton: 'swal-btn-big'
                                    }
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        $("#btnShowData").trigger("click");
                                    }
                                });

                            } else {
                                Swal.fire('Warning', res.message ?? 'Process failed', 'warning');
                            }
                        },

                        error: function () {
                            Swal.close(); // pastikan loading tertutup
                            Swal.fire('Error', 'Something went wrong', 'error');
                        }
                    });

















               
                }
            });
        }); 

    } //END OF LIST PROGRESS

 


 }); //END OF DOCUMENT
