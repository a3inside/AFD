﻿$(document).ready(function () {


 
        loadAFDType();
 


    $("input[name='AFDType']").change(function () {

        let selectedValue = $("input[name='AFDType']:checked").val();

        if (selectedValue === "CAPITAL INVESTMENT") { 
            $(".AFDTypeCapitalInvestment").removeClass("hide");
            $(".AFDTypeDisposal").addClass("hide");
            $("input[name='AFDSubType']").prop("checked", false);
        }

        if (selectedValue === "DISPOSAL") {  
            $(".AFDTypeDisposal").removeClass("hide");
            $(".AFDTypeCapitalInvestment").addClass("hide");
            $("input[name='AFDSubType']").prop("checked", false);
        }

    });


    $("#btnSearch").click(function () {
        var CostSection = $("#ddl_AFDCostSection").val();
        var TypeForm = $("input[name='TypeForm']:checked").val();
        var DecisionBy = $("input[name='DecisionBy']:checked").val();
        var AFDType = $("input[name='AFDType']:checked").val();
        var AFDCategory = $("input[name='AFDCategory']:checked").val();
        var AFDSubType = $("input[name='AFDSubType']:checked").val();

        if (TypeForm == 'PRODUCTION') { TypeForm = 'FORM P-'}
        if (TypeForm == 'MECHANIC') { TypeForm = 'FORM M-' }
        if (TypeForm == 'ELECTRIC') { TypeForm = 'FORM E-' }
        if (TypeForm == 'UTILITY') { TypeForm =  'FORM U-' }


        if (DecisionBy == 'PRESIDENT') { DecisionBy = 'II' }
        if (DecisionBy == 'GENERAL MANAGER') { DecisionBy = 'I' }

        var param1 = CostSection;
        var param2 = TypeForm + DecisionBy;
        var param3 = AFDType;
        var param4 = AFDCategory;
        var param5 = AFDSubType;

        loaddataMasterApproval(param1, param2, param3, param4);
    })

    $("#ddl_AFDDept").change(function () {

        var Dept = $(this).val();

        loadCostSection(Dept);

    });

    $('#SaveRuleApproval').click(function () {



        let ApprovalTableItems = [];

        $('#ApprovalTable tbody tr').each(function () {

            let row = $(this);

            let item = {
                FormAFDID: row.find('.FormAFDID').html(),
                Step: row.find('.Step').html(),
                NIK: row.find('.nikInput').html(),
                SignName: row.find('.signName').html(),
                SignTitle: row.find('.signTitle').html()
            };

            ApprovalTableItems.push(item);
        });

        if (ApprovalTableItems.length === 0) {
            alert('No data to save');
            return;
        }

        var dataPost = {
            CostSection: $("#ddl_AFDCostSection").val(),
            Items: ApprovalTableItems
        };

        $.ajax({
            url: '/AFDMaster/SaveRuleApproval',
            type: 'POST',
            data: JSON.stringify(dataPost),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',

            success: function (res) {
                if (res.success) {

                    Swal.fire({
                        icon: "success",
                        title: "Data saved successfully",
                        confirmButtonText: "OK"
                    });

                } else {
                    alert(res.message);
                }
            },
            error: function () {
                alert('Error saving data');
            }
        });

    });

    $("#AddStep").click(function () {

        var x = $("#spanFormAFDID").html().trim();

        if (x == "") {
            alert("asdasdas")
        } else { 
        $("#modalAddStep").modal("show");
            loadAddStep();
        }
    })

    function loaddataMasterApproval(param1, param2, param3, param4) {

         
        /*================= AJAX =================*/
        var dataPost = {
            param1: param1,
            param2: param2,
            param3: param3,
            param4: param4,
            param5: param5
        };

        $.ajax({
            url: '/AFDMaster/GetRuleApproval',
            type: 'POST',
            data: JSON.stringify(dataPost),
            contentType: 'application/json; charset=utf-8',
            processData: false,
            success: function (response) {

                let tbody = $('#ApprovalBody');
                tbody.empty();
                 
                if (!response || response.length === 0) {
                    //tbody.append(createEmptyRow());

                    Swal.fire({
                        title: "Master Not Available",
                        icon: "info",
                        draggable: true,
                        width: '80rem',
                        customClass: {
                            title: 'swal-title-big',
                            htmlContainer: 'swal-text-big',
                            icon: 'swal-icon-big',
                            confirmButton: 'swal-btn-big'
                        }
                    });

                } else {
                    renderRuleApprovalTable(response);
                    console.log(response);
                    $("#ApprovalTable").removeClass("hidden");
                }
                 
            },
            error: function (err) {
                console.log(err);
            }
        });




        function createEmptyRow() {
            return `
    <tr>
        <td><input type="text" style="width:40px;padding:5px" class="" readonly></td>
        <td><input type="text" style="width:70px;padding:5px" class=""   readonly></td>
        <td><input type="text" style="width:500px;padding:5px" class=""  readonly></td> 
         <td><input type="text" style="width:250px;padding:5px" class=""   readonly></td> 
  <td><input type="text" style="width:250px;padding:5px" class=""  ></td> 
        <td style="border:none"   > 
            <button type="button" class="btn btn-danger ApprovalTable_deleteRow">
               X
            </button>
        </td>
    </tr>`;
        }


        function renderRuleApprovalTable(data) {

            let tbody = $('#ApprovalBody');
            tbody.empty(); // bersihkan dulu

            $.each(data, function (i, d) {


                let row = `
        <tr border="0px">
  <td class="hidden"><span   style="width:40px;padding:5px"   class="FormAFDID"  > ${d.Form_AFD_ID ?? ''}  </span></td> 
<td><span   style="width:40px;padding:5px"   class="Step"  > ${d.Approval_Step ?? ''}  </span></td> 
            <td>
                <span style="width:70px;padding:5px" class="nikInput"  >${d.NIK ?? ''}  </span>
                <button type="button" class="searchNIK">🔍</button>
            </td>
            <td><span  style="width:500px;padding:5px" class="signName" >   ${d.Sign_Name ?? ''} </span></td>
            <td colspan="4"><span  style="width:250px;padding:5px"   class="signTitle"  > ${d.Sign_Title ?? ''}  </span></td> 
            <td style="border:none">
                <button type="button" class="btn btn-success moveUp"><h2>⬆</h2></button> 
            </td>
            <td style="border:none">
              <button type="button" class="btn btn-success moveDown"><h2>⬇</h2></button>
            </td>
            <td style="border:none">
             <button type="button" class="btn btn-danger ApprovalTable_deleteRow"><b>X</b></button>
            </td>
        </tr>
        `;
                tbody.append(row);

                console.log(row);
            });


        }

        $(document).on('click', '.ApprovalTable_deleteRow', function () { 
            let row = $(this).closest('tr');
            updateStep(); 
            row.remove();  
        });

        // UP
        $("#ApprovalTable").on("click", ".moveUp", function () {

            var row = $(this).closest("tr");
            row.prev().before(row);

            updateStep();
        });

        // DOWN
        $("#ApprovalTable").on("click", ".moveDown", function () {

            var row = $(this).closest("tr");
            row.next().after(row);

            updateStep();
        });
         

        function updateStep() {

            $("#ApprovalBody tr:visible").each(function (index) {

                $(this).find("td:first input").val(index);

            });

        }


        var selectedRow; 
        $("#ApprovalTable").on("click", ".searchNIK", function () {

            selectedRow = $(this).closest("tr");

            $("#modalSearchNIK").modal("show");

            loadEmployee();

        });


        function loadEmployee() {

            $.ajax({
                url: '/AFDMaster/GetEmployee',
                type: 'GET',
                success: function (data) {

                    var html = "";

                    $.each(data, function (i, item) {

                        html += "<tr>";

                        html += "<td>" + item.NIK + "</td>";
                        html += "<td>" + item.Sign_Name + "</td>";
                        html += "<td>" + item.Sign_Title + "</td>"; 
                        html += "<td class='text-center'><button class='selectEmployee btn btn-success'>Select</button></td>";

                        html += "</tr>";

                    });

                    $("#tableSearchNIK tbody").html(html);

                }
            });

        }




        $("#tableSearchNIK").on("click", ".selectEmployee", function () {

            var row = $(this).closest("tr");

            var nik = row.find("td:eq(0)").text();
            var name = row.find("td:eq(1)").text();
            var title = row.find("td:eq(2)").text();

            selectedRow.find(".nikInput").html(nik);
            selectedRow.find(".signName").html(name);
            selectedRow.find(".signTitle").html(title);

            $("#modalSearchNIK").modal("hide");

        });



    }
    function loadAFDType() {

        $.ajax({
            url: "/AFDMaster/GetDept", // controller
            type: "GET",
            success: function (data) {

                var ddl = $("#ddl_AFDDept");
                ddl.empty();

                ddl.append('<option selected disabled>Choose Department</option>');

                $.each(data, function (i, item) {
                    ddl.append('<option value="' + item.Value + '">' + item.Text + '</option>');
                });
            },
            error: function () {
                alert("Gagal mengambil data Department");
            }
        });

    } 
    function loadCostSection(Dept) {

        $.ajax({
            url: "/AFDMaster/GetCostSection",
            type: "GET",
            data: { Dept: Dept },
            success: function (data) {

                var ddl = $("#ddl_AFDCostSection");
                ddl.empty();

                ddl.append('<option selected disabled>Choose Cost Section</option>');

                $.each(data, function (i, item) {

                    ddl.append('<option value="' + item.Value + '">' + item.Text + '</option>');

                });

            },
            error: function () {
                alert("Gagal mengambil data Cost Section");
            }
        });
    }



    function loadAddStep() {

        $.ajax({
            url: '/AFDMaster/GetNewStep',
            type: 'GET',
            success: function (data) {

                var html = "";

                $.each(data, function (i, item) {

                    html += "<tr>";

                    html += "<td>" + item.NIK + "</td>";
                    html += "<td>" + item.Sign_Name + "</td>";
                    html += "<td>" + item.Sign_Title + "</td>";
                    html += "<td class='text-center'><button class='selectEmployeeforNextStep btn btn-success'>Select</button></td>";

                    html += "</tr>";

                });

                $("#tableAddStep tbody").html(html);

            }
        });

    }









    $("#tableAddStep").on("click", ".selectEmployeeforNextStep", function () {
        var row = $(this).closest("tr");

        var xNIK = row.find("td:eq(0)").text();
        var xSignName = row.find("td:eq(1)").text();
        var xSigntitle = row.find("td:eq(2)").text(); 
        var xStep = $("#ApprovalBody tr").length + 0; 
        var xFormAFDID = "";

        var newRow = "";
        newRow += "<tr border='0px'>";
        newRow += "<td class='hidden'><span   style='width: 40px; padding: 5px'   class='FormAFDID'  > " + xFormAFDID +"  </span></td>";
        newRow += "<td><span   style='width: 40px; padding: 5px'   class='Step'  > " + xStep +" </span></td>";
        newRow += "<td><span style='width:70px;padding:5px' class='nikInput'  > " + xNIK +"  </span><button type='button' class='searchNIK'>🔍</button></td>";
        newRow += "<td><span  style='width: 500px; padding: 5px' class='signName' >  " + xSignName +"  </span></td>";
        newRow += "<td colspan='4'><span  style='width: 250px; padding: 5px'   class='signTitle'  > " + xSigntitle +"  </span></td>";
        newRow += "<td style='border: none'> <button type='button' class='btn btn-success moveUp'><h2>⬆</h2></button> </td>";
        newRow += "<td style='border:none'><button type='button' class='btn btn-success moveDown'><h2>⬇</h2></button></td>";
        newRow += "<td style='border:none'><button type='button' class='btn btn-danger ApprovalTable_deleteRow'><b>X</b></button></td></tr>";
     

        var selectedRow;
        $("#ApprovalTable").on("click", ".searchNIK", function () { 
            selectedRow = $(this).closest("tr"); 
            $("#modalSearchNIK").modal("show"); 
            loadEmployee(); 
        });


        function loadEmployee() {

            $.ajax({
                url: '/AFDMaster/GetEmployee',
                type: 'GET',
                success: function (data) {

                    var html = "";

                    $.each(data, function (i, item) {

                        html += "<tr>";

                        html += "<td>" + item.NIK + "</td>";
                        html += "<td>" + item.Sign_Name + "</td>";
                        html += "<td>" + item.Sign_Title + "</td>";
                        html += "<td class='text-center'><button class='selectEmployee btn btn-success'>Select</button></td>";

                        html += "</tr>";

                    });

                    $("#tableSearchNIK tbody").html(html);

                }
            });

        }
        $("#tableSearchNIK").on("click", ".selectEmployee", function () {

            var row = $(this).closest("tr");

            var nik = row.find("td:eq(0)").text();
            var name = row.find("td:eq(1)").text();
            var title = row.find("td:eq(2)").text();

            selectedRow.find(".nikInput").html(nik);
            selectedRow.find(".signName").html(name);
            selectedRow.find(".signTitle").html(title);

            $("#modalSearchNIK").modal("hide");

        });



        //var newRow = "";
        //newRow += "<tr border='0px'>";
        //newRow += "<td class='hidden'><span   style='width: 40px; padding: 5px'   class='FormAFDID'  > ${d.Form_AFD_ID ?? ''}  </span></td> "
        //newRow += "<td class='hidden FormAFDID'></td>";
        //newRow += "<td class='Step text-center'>" + step + "</td>";
        //newRow += "<td class='nikInput'>" + nik + "</td>";
        //newRow += "<td class='signName'>" + name + "</td>";
        //newRow += "<td class='signTitle'>" + title + "</td>";
        //newRow += "<td class='text-center'><button class='btn btn-danger btn-sm removeRow'>Delete</button></td>";
        //newRow += "</tr>";

        $("#ApprovalBody").append(newRow);

        $("#modalAddStep").modal("hide");

    });


 }); //END OF DOCUMENT
