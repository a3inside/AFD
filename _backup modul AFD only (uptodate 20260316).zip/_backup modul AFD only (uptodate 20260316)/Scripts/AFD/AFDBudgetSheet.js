﻿$(document).ready(function () {

 

     //**********************************  BUDGET SHEET

    if (typeof InitialPage !== "undefined" && InitialPage === "IndexBudgetSheet") {


        function toNumber(val) {
            return parseFloat(val) || 0;
        }

        function calculateRow(row) {

            let machImport =
                toNumber(row.find('.mech-mach-import').val()) +
                toNumber(row.find('.elec-mach-import').val()) +
                toNumber(row.find('.inst-mach-import').val());

            let machLocal =
                toNumber(row.find('.mech-mach-local').val()) +
                toNumber(row.find('.elec-mach-local').val()) +
                toNumber(row.find('.inst-mach-local').val());

            let cons =
                toNumber(row.find('.mech-cons').val()) +
                toNumber(row.find('.elec-cons').val()) +
                toNumber(row.find('.inst-cons').val()) +
                toNumber(row.find('.civil-cons').val());

            let total = machImport + machLocal + cons;

            row.find('.subtotal-mach-import').text(machImport.toFixed(1));
            row.find('.subtotal-mach-local').text(machLocal.toFixed(1));
            row.find('.subtotal-cons').text(cons.toFixed(1));
            row.find('.total').text(total.toFixed(1));
        }

        function calculateGrandTotal() {

            let grandMechMachImport = 0,
                grandMechMachLocal = 0,
                grandMechMachCons = 0,
                grandElecMachImport = 0,
                grandElecMachLocal = 0,
                grandElecMachCons = 0,
                grandInstMachImport = 0,
                grandInstMachLocal = 0,
                grandInstMachCons = 0,
                grandCivilCons = 0,

                gMachImport = 0,
                gMachLocal = 0,
                gCons = 0,
                gTotal = 0;

            $('#BudgetSheetTable tbody tr').each(function () {
                grandMechMachImport += toNumber($(this).find('.mech-mach-import').val());
                grandMechMachLocal += toNumber($(this).find('.mech-mach-local').val());
                grandMechMachCons += toNumber($(this).find('.mech-cons').val());

                grandElecMachImport += toNumber($(this).find('.elec-mach-import').val());
                grandElecMachLocal += toNumber($(this).find('.elec-mach-local').val());
                grandElecMachCons += toNumber($(this).find('.elec-cons').val());

                grandInstMachImport += toNumber($(this).find('.inst-mach-import').val());
                grandInstMachLocal += toNumber($(this).find('.inst-mach-local').val());
                grandInstMachCons += toNumber($(this).find('.inst-cons').val());

                grandCivilCons += toNumber($(this).find('.civil-cons').val());

                gMachImport += toNumber($(this).find('.subtotal-mach-import').text());
                gMachLocal += toNumber($(this).find('.subtotal-mach-local').text());
                gCons += toNumber($(this).find('.subtotal-cons').text());
                gTotal += toNumber($(this).find('.total').text());
            });

            $('#grand-mech-mach-import').text(grandMechMachImport.toFixed(1));
            $('#grand-mech-mach-local').text(grandMechMachLocal.toFixed(1));
            $('#grand-mech-cons').text(grandMechMachCons.toFixed(1));

            $('#grand-elec-mach-import').text(grandElecMachImport.toFixed(1));
            $('#grand-elec-mach-local').text(grandElecMachLocal.toFixed(1));
            $('#grand-elec-cons').text(grandElecMachCons.toFixed(1));

            $('#grand-inst-mach-import').text(grandInstMachImport.toFixed(1));
            $('#grand-inst-mach-local').text(grandInstMachLocal.toFixed(1));
            $('#grand-inst-cons').text(grandInstMachCons.toFixed(1));

            $('#grand-civil-cons').text(grandCivilCons.toFixed(1));

            $('#grand-subtotal-mach-import').text(gMachImport.toFixed(1));
            $('#grand-subtotal-mach-local').text(gMachLocal.toFixed(1));
            $('#grand-subtotal-cons').text(gCons.toFixed(1));
            $('#grandTotal').text(gTotal.toFixed(1));



            var xBudgetFinal = parseFloat(($("#txtBudgetFinal").val() || "0").replace(/,/g, ""));
            var xTotalCapitalExpenditure = parseFloat(($("#txtTotalCapitalExpenditure").val() || "0").replace(/,/g, ""));
            var xTotalExpense = parseFloat(($("#txtTotalExpense").val() || "0").replace(/,/g, ""));
            var xTOTAL = xTotalCapitalExpenditure + xTotalExpense;

            if ($("#ddl_BudgetSheetClassification").val() == "CAPITAL EXPENDITURE") {
                $('#txtTotalCapitalExpenditure').val(gTotal.toFixed(1));

                if (xTOTAL > xBudgetFinal) {
                    $("#txtTotalCapitalExpenditure").css({
                        "font-weight": "bold", "color": "red"
                    });

                    console.log("XXX")
                } else {
                    $("#txtTotalCapitalExpenditure").removeAttr("style");
                    console.log("yyy")
                }



            }


            if ($("#ddl_BudgetSheetClassification").val() == "EXPENSE") {
                $('#txtTotalExpense').val(gTotal.toFixed(1));



                if (xTOTAL > xBudgetFinal) {
                    $("#txtTotalExpense").css({
                        "font-weight": "bold", "color": "red"
                    });

                } else {
                    $("#txtTotalExpense").removeAttr("style");

                }


            }


        }

        $(document).on('input', '.calc', function () {
            let row = $(this).closest('tr');
            calculateRow(row);
            calculateGrandTotal();
        });

        $('#addRow').click(function () {

            if (!validateBudgetSheetRow()) {
                return;
            }


            // ===== lanjut add row =====
            let newRow = $('#BudgetSheetTable tbody tr:first').clone();

            newRow.find('input').val('');
            newRow.find('.subtotal-mach-import,.subtotal-mach-local,.subtotal-cons,.total')
                .text('0.0');

            newRow.find('td:first').html(
                '<input type="text"  style="width:300px;padding:5px"   class="item-name">'
            );

            $('#BudgetSheetTable tbody').append(newRow);
        });

        function validateBudgetSheetRow() {

            let isInvalid = false;

            $('#BudgetSheetTable tbody tr').each(function () {

                let row = $(this);
                let itemName = row.find('.item-name').val()?.trim();
                let totalText = row.find('.total').text().trim();
                let total = parseFloat(totalText) || 0;

                // reset highlight
                row.removeClass('table-danger');

                if (!itemName && total === 0) {
                    row.addClass('table-danger');
                    isInvalid = true;
                    return false; // break loop
                }
            });

            if (isInvalid) {
                Swal.fire({
                    icon: 'warning',
                    title: '',
                    text: 'Item Name cannot be empty and Total cannot be 0.0',
                    confirmButtonText: 'OK',
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        icon: 'swal-icon-big',
                        confirmButton: 'swal-btn-big'
                    }
                });

                return false;
            }

            return true;
        }

        $(document).on('click', '.BudgetSheetTable_deleteRow', function () {

            if ($('#BudgetSheetTable tbody tr').length === 1) {
                alert('There must be at least one line.');
                return;
            }

            let row = $(this).closest('tr');

            let itemName = row.find('td:first input').val();



            //Swal.fire({
            //    title: "Are you sure?",
            //    text: "Item " + itemName +" will be deleted!",
            //    icon: "warning",
            //    showCancelButton: true,
            //    confirmButtonColor: "#3085d6",
            //    cancelButtonColor: "#d33",
            //    confirmButtonText: "OK",
            //    width: '80rem',
            //    customClass: {
            //        title: 'swal-title-big',
            //        htmlContainer: 'swal-text-big',
            //        confirmButton: 'swal-btn-big',
            //        cancelButton: 'swal-btn-big',
            //        icon: 'swal-icon-big'
            //    }
            //}).then((result) => {
            //    if (result.isConfirmed) {
            //        Swal.fire({
            //            title: "Deleted!",
            //            text: "Item " + itemName +"  has been deleted.",
            //            icon: "success",
            //            width: '80rem',
            //            customClass: {
            //                title: 'swal-title-big',
            //                htmlContainer: 'swal-text-big',
            //                confirmButton: 'swal-btn-big',
            //                cancelButtonColor: 'swal-btn-big',
            //                icon: 'swal-icon-big'
            //            }
            //        });


            //    }
            //});


            //if (
            //    !confirm('Delete this line?\nItem: ' + itemName)

            //    ) return;

            row.remove();
            calculateGrandTotal();

        });

        $('#SaveBudgetSheet').click(function () {


            var xBudgetFinal = parseFloat(($("#txtBudgetFinal").val() || "0").replace(/,/g, ""));
            var xTotalCapitalExpenditure = parseFloat(($("#txtTotalCapitalExpenditure").val() || "0").replace(/,/g, ""));
            var xTotalExpense = parseFloat(($("#txtTotalExpense").val() || "0").replace(/,/g, ""));
            var xgrandTotal = parseFloat(($("#grandTotal").html() || "0").replace(/,/g, ""));

            var xBudgetSheetClassification = $("input[name='BudgetSheetClassification']:checked").val();
            var xTOTAL = 0;

            if (xBudgetSheetClassification == "CAPITAL EXPENDITURE") { xTOTAL = xgrandTotal + xTotalExpense; }
            if (xBudgetSheetClassification == "EXPENSE") { xTOTAL = xTotalCapitalExpenditure + xgrandTotal; }



            if (xTOTAL > xBudgetFinal) {
                //alert("Tidak boleh melebihi budget amount");

                Swal.fire({
                    icon: "error",
                    title: "Budget amount limit exceeded",
                    width: '80rem',
                    customClass: {
                        title: 'swal-title-big',
                        htmlContainer: 'swal-text-big',
                        confirmButton: 'swal-btn-big',
                        icon: 'swal-icon-big'
                    }

                });

                return;
            }


            if (!validateBudgetSheetRow()) {
                return;
            }

            let budgetItems = [];

            $('#BudgetSheetTable tbody tr').each(function () {

                let row = $(this);

                let item = {
                    ItemName: row.find('.item-name').val(),

                    MechMachImport: toNumber(row.find('.mech-mach-import').val()),
                    MechMachLocal: toNumber(row.find('.mech-mach-local').val()),
                    MechCons: toNumber(row.find('.mech-cons').val()),

                    ElecMachImport: toNumber(row.find('.elec-mach-import').val()),
                    ElecMachLocal: toNumber(row.find('.elec-mach-local').val()),
                    ElecCons: toNumber(row.find('.elec-cons').val()),

                    InstMachImport: toNumber(row.find('.inst-mach-import').val()),
                    InstMachLocal: toNumber(row.find('.inst-mach-local').val()),
                    InstCons: toNumber(row.find('.inst-cons').val()),

                    CivilCons: toNumber(row.find('.civil-cons').val()),

                    SubtotalMachImport: toNumber(row.find('.subtotal-mach-import').text()),
                    SubtotalMachLocal: toNumber(row.find('.subtotal-mach-local').text()),
                    SubtotalCons: toNumber(row.find('.subtotal-cons').text()),

                    Total: toNumber(row.find('.total').text()),
                    Remark: row.find('.budget-remark').val()
                };

                budgetItems.push(item);
            });

            if (budgetItems.length === 0) {
                alert('No data to save');
                return;
            }
            if ($("#grandTotal").html() === 0) {
                alert('Please input data');
                return;
            }




            var dataPost = {
                afdId: $("#txtIDAFD").val(),
                //budgetClassification: $("#ddl_BudgetSheetClassification").val(),
                budgetClassification: $("input[name='BudgetSheetClassification']:checked").val(),
                items: budgetItems
            };




            $.ajax({
                url: '/AFDCoverLetter/SaveBudgetSheet',
                type: 'POST',
                data: JSON.stringify(dataPost),
                contentType: 'application/json; charset=utf-8',
                success: function (res) {
                    if (res.success) {


                        Swal.fire({
                            title: "Amount " + xBudgetSheetClassification + " has been saved",
                            icon: "success",
                            text: "Do you want to continue edit budget sheet?",
                            showDenyButton: false,
                            showCancelButton: true,
                            confirmButtonText: "Yes",
                            cancelButtonText: "No",
                            width: '80rem',
                            customClass: {
                                title: 'swal-title-big',
                                htmlContainer: 'swal-text-big',
                                confirmButton: 'swal-btn-big',
                                cancelButton: 'swal-btn-big',
                                icon: 'swal-icon-big'
                            }

                        }).then((result) => {
                            if (result.isConfirmed) {

                                if (xBudgetSheetClassification == "CAPITAL EXPENDITURE") { $("#txtTotalCapitalExpenditure").val(xgrandTotal.toFixed(1)) }
                                if (xBudgetSheetClassification == "EXPENSE") { $("#txtTotalExpense").val(xgrandTotal.toFixed(1)) }

                            } else if (result.isDismissed) {

                                $("#copy_txtTotalCapitalExpenditure").html("");
                                $("#copy_txtTotalExpense").html("");
                                window.close();
                            }
                        });





                    } else {
                        alert(res.message);
                    }
                },
                error: function () {
                    alert('Error saving data');
                }
            });




        });


        let previousValueDDL = '';
        //$('#ddl_BudgetSheetClassification').on('focus', function () {  previousValueDDL = this.value;  }).on('change', function () {
        $("input[name='BudgetSheetClassification']").on("change", function () {

            previousValueDDL = $("input[name='BudgetSheetClassification']:checked").val();


            //let currentValue = $(this).val(); 
            //var TCE = parseFloat(($("#txtTotalCapitalExpenditure").val() || "0").replace(/,/g, ""));
            //var TE = parseFloat(($("#txtTotalExpense").val() || "0").replace(/,/g, "")); 
            //var copy_TCE = parseFloat(($("#copy_txtTotalCapitalExpenditure").val() || "0").replace(/,/g, ""));
            //var copy_TE = parseFloat(($("#copy_txtTotalExpense").val() || "0").replace(/,/g, ""));

            //if (TCE != copy_TCE || TE != copy_TE) {

            //    Swal.fire({
            //        title: "Your changes have not been saved", 
            //        icon: "warning",
            //        showCancelButton: true,
            //        confirmButtonColor: "#3085d6",
            //        cancelButtonColor: "#d33",
            //        confirmButtonText: "Yes, continue",
            //        cancelButtonText: "Cancel",
            //        width: '80rem',
            //        customClass: {
            //            title: 'swal-title-big',
            //            htmlContainer: 'swal-text-big',
            //            confirmButton: 'swal-btn-big',
            //            cancelButton: 'swal-btn-big',
            //            icon: 'swal-icon-big'
            //        }

            //    }).then((result) => {

            //        if (!result.isConfirmed) {
            //            $('#ddl_BudgetSheetClassification')
            //                .val(previousValueDDL)
            //                .trigger('change.select2');
            //        }

            //    });


            //}

            /*================= AJAX =================*/
            var dataPost = {
                afdId: $("#txtIDAFD").val(),
                //budgetClassification: $("#ddl_BudgetSheetClassification").val()
                budgetClassification: previousValueDDL
            };

            $.ajax({
                url: '/AFDCoverLetter/GetBudgetSheetByClassification',
                type: 'POST',
                data: JSON.stringify(dataPost),
                contentType: 'application/json; charset=utf-8',
                processData: false,
                success: function (response) {

                    let tbody = $('#budgetsheetBody');
                    tbody.empty();

                    $("#BudgetSheetTable, #addRow, #SaveBudgetSheet").removeClass("hide");

                    if (!response || response.length === 0) {
                        tbody.append(createEmptyRow());
                    } else {
                        renderBudgetSheetTable(response);
                    }

                    recalcAll();
                },
                error: function (err) {
                    console.log(err);
                }
            });
        });


        function renderBudgetSheetTable(data) {

            let tbody = $('#budgetsheetBody');
            tbody.empty(); // bersihkan dulu

            $.each(data, function (i, d) {

                let row = `
        <tr>
            <td><input type="text"  style="width:300px;padding:5px"  class="item-name" value="${d.Budget_Item ?? ''}"></td>

            <td><input type="number" style="padding:5px" class="calc mech-mach-import" value="${d.Mech_Machine_Import ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc mech-mach-local" value="${d.Mech_Machine_Local ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc mech-cons" value="${d.Mech_Construction ?? 0}" min=0></td>

            <td><input type="number" style="padding:5px" class="calc elec-mach-import" value="${d.Elec_Machine_Import ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc elec-mach-local" value="${d.Elec_Machine_Local ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc elec-cons" value="${d.Elec_Construction ?? 0}" min=0></td>

            <td><input type="number" style="padding:5px" class="calc inst-mach-import" value="${d.Inst_Machine_Import ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc inst-mach-local" value="${d.Inst_Machine_Local ?? 0}" min=0></td>
            <td><input type="number" style="padding:5px" class="calc inst-cons" value="${d.Inst_Construction ?? 0}" min=0></td>

            <td><input type="number" style="padding:5px" class="calc civil-cons" value="${d.Civil_Construction ?? 0}" min=0></td>

            <td style="padding:5px"  class="subtotal-mach-import">0</td>
            <td style="padding:5px" class="subtotal-mach-local">0</td>
            <td style="padding:5px" class="subtotal-cons">0</td>
            <td style="padding:5px" class="total">0</td>

            <td><input type="text" class="budget-remark"  style="width:200px;padding:5px" value="${d.Remark ?? ''}"></td>

            <td style="border:none">
                <button type="button" class="btn btn-danger BudgetSheetTable_deleteRow">
                    <span class="glyphicon glyphicon-remove"></span>
                </button>
            </td>
        </tr>
        `;

                tbody.append(row);
            });


        }


        function recalcAll() {
            $('#BudgetSheetTable tbody tr').each(function () {
                calculateRow($(this));
            });

            calculateGrandTotal();
        }

        function createEmptyRow() {
            return `
    <tr>
        <td><input type="text"  style="width:300px;padding:5px" class="item-name"></td>

        <td><input type="number" style="padding:5px" class="calc mech-mach-import"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc mech-mach-local"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc mech-cons"  min=0></td>

        <td><input type="number" style="padding:5px" class="calc elec-mach-import"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc elec-mach-local"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc elec-cons"  min=0></td>

        <td><input type="number" style="padding:5px" class="calc inst-mach-import"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc inst-mach-local"  min=0></td>
        <td><input type="number" style="padding:5px" class="calc inst-cons"  min=0></td>

        <td><input type="number" style="padding:5px" class="calc civil-cons"  min=0></td>

        <td style="padding:5px" class="subtotal-mach-import">0.0</td>
        <td style="padding:5px" class="subtotal-mach-local">0.0</td>
        <td style="padding:5px" class="subtotal-cons">0.0</td>
        <td style="padding:5px" class="total">0.0</td>

        <td><input type="text" style="width:200px;padding:5px" class="budget-remark"></td>

        <td style="border:none">
            <button type="button" class="btn btn-danger BudgetSheetTable_deleteRow">
                <span class="glyphicon glyphicon-remove"></span>
            </button>
        </td>
    </tr>`;
        }

        $("#PreviewBudgetSheet").click(function () {
 
            var IDAFD = $("#txtIDAFD").val();
            console.log(IDAFD);

            var url = '/AFDCoverLetter/PrintBudgetSheet?CoverLetterId=' + IDAFD;
            window.open(url, '_blank');


        })


        $("#ExitBudgetSheet").click(function () {
           window.close(); 
        })


    }
    //END OF BUDGET SHEET

 


 }); //END OF DOCUMENT
