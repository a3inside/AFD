﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Web_Portal.Models
{
    public class AFDCreateModel
    {

        // 1. General Info
        public string CoverLetterID { get; set; }
        public string FiscalYear { get; set; }
        public DateTime? DateOfProposal { get; set; }
        public DateTime? DateOfDecision { get; set; }
        public string DecisionNumber { get; set; }
        public string Title { get; set; }
        public string AFDType { get; set; }
        public string AFDSubType { get; set; }
        public decimal MinAmount { get; set; }
        public decimal MaxAmount { get; set; }
        public int FormAFDID { get; set; }
        public string CostSection { get; set; }
        public string NIKLogin { get; set; }
        public decimal AmountBudget { get; set; }
        public int AmountBudgetID { get; set; }
        public decimal Rate { get; set; }
        public string Place { get; set; }
        public DateTime? PeriodeCommencement { get; set; }
        public DateTime? PeriodeCompletion { get; set; }
        public string PurposeFor { get; set; }
        public string DisposalResponsible { get; set; }
        public string BudgetType { get; set; }

        public string Classification { get; set; }

        // 2. Long Text Fields
        public string PurposeDescription { get; set; }
        public string RequisiteSpecification { get; set; }
        public string ExpectedEffect { get; set; }

        // 3. Coordinator
        public string CoordinatorName { get; set; }
        public string CoordinatorSection { get; set; }

        // 4. Decision (Radio)
        public string DecisionStatus { get; set; }  // Approved / Hold / Disapproved

        // 5. Payments (nested model)
        public PaymentModel Payment { get; set; }

        // 6. File uploads (base64)
        public string FileContentOverview { get; set; }
        public string FileNameContentOverview { get; set; }

        public string FileSchedule { get; set; }
        public string FileNameSchedule { get; set; }

        public string FileBiddingDocument { get; set; }
        public string FileNameBiddingDocument { get; set; }


        // 7. Flag

        public string Flag_Reapplication { get; set; }
        public string Flag_Close_Approval { get; set; }
        public string Flag_Draft { get; set; }

    }



    public class PaymentQuarterModel
    {
        public decimal? Q1 { get; set; }
        public decimal? Q2 { get; set; }
        public decimal? Q3 { get; set; }
        public decimal? Q4 { get; set; }
    }


    public class PaymentCategoryModel
    {
        public PaymentQuarterModel FY1 { get; set; }
        public PaymentQuarterModel FY2 { get; set; }
        public PaymentQuarterModel FY3 { get; set; }
        public decimal Total { get; set; }
    }


    public class PaymentModel
    {
        public PaymentCategoryModel CAPEX { get; set; }
        public PaymentCategoryModel EXPENSE { get; set; }
        public PaymentCategoryModel TOTAL { get; set; }
    }



    public class PaymentViewModel
    {
        public string FiscalYear { get; set; }
        public string Quarter { get; set; }
        public decimal CapitalExpense { get; set; }
        public decimal Expense { get; set; }
    }
     

    public class PrintCoverLetter
    {
        public string DecisionLevel_BOD { get; set; }
        public string DecisionLevel_PD { get; set; }
        public string DecisionLevel_GM { get; set; }
        public string budgettype_inbudget { get; set; }
        public string budgettype_additional { get; set; }
        public decimal Total_CAP_EXP { get; set; }
        public decimal Capital_Expense_Amount { get; set; }
        public decimal Expense_Amount { get; set; }
        public string RemarkAmountBudget { get; set; }
        public decimal AmountBudgetMaster { get; set; }
        public string FiscalYear { get; set; }
        public string DateOfProposal { get; set; }
        public string DateOfDecision { get; set; }
        public string DecisionNumber { get; set; }
        public string Title { get; set; }
        public string AFD_Type_Investment { get; set; }
        public string AFD_Type_Disposal { get; set; }
        public string Show_Disposal { get; set; }
        public string Type_Form { get; set; }
        public string AFD_SubType { get; set; }
        public string CostSection { get; set; }
        public string Rate { get; set; }
        public string Place { get; set; }
        public string PeriodeCommencement { get; set; }
        public string PeriodeCompletion { get; set; }
        public string PurposeFor { get; set; }
        public string PurposeDescription { get; set; }
        public string RequisiteSpecification { get; set; }
        public string ExpectedEffect { get; set; }
        public string CoordinatorName { get; set; }
        public string CoordinatorSection { get; set; }
        public string DisposalResponsible_Sales { get; set; }
        public string DisposalResponsible_Purch { get; set; }
        public string DisposalResponsible_SE { get; set; }
        public string decision_approved { get; set; }
        public string decision_hold { get; set; }
        public string decision_disapproved { get; set; }
        public PaymentModel Payment { get; set; }


    }

    public class PrintSignature
    {

        public int Approval_Step { get; set; }
        public string Sign_Name { get; set; }
        public string Sign_Image { get; set; }
        public string Sign_Date { get; set; }
    }

    public class PrintPayment
    {

        public string Fiscal_Year { get; set; }
        public string Fiscal_Quarter { get; set; }
        public decimal Capital_Expense_Amount { get; set; }
        public decimal Expense_Amount { get; set; }
    }


    //public class Return
    //{
    //    public int CoverLetterId { get; set; }

    //    [AllowHtml]
    //    public string ReturnReason { get; set; }

    //    public string FileNameReturn { get; set; }
         

    //    public string  FiscalYear { get; set; }
    //    public string  AFDType  { get; set; }
    //    public string  AFDSubType { get; set; }
    //    public string  CostSection { get; set; } 
    //}



    public class Return
    {
        public int CoverLetterId { get; set; }
        public string ReturnReason { get; set; }

        public string FileBase64Return { get; set; }   // base64 file
        public string FileNameReturn { get; set; }     // nama file asli

        public int FiscalYear { get; set; }
        public string AFDType { get; set; }
        public string AFDSubType { get; set; }
        public string CostSection { get; set; }
    }


    public class ListProgressAFD
    {
        public int AFD_ID { get; set; }
        public string Dept_Name { get; set; }
        public string Cost_Section { get; set; }
        public string AFD_Title { get; set; } 

        public string Decision_Number { get; set; }

     
        public string AFD_Type { get; set; }
        public string Budget_Type { get; set; }

        public string Proposal_Date { get; set; }
        public string Decision_Date { get; set; }
        public string Place { get; set; }
        public string Period_Commencement { get; set; }
        public string Period_Completion { get; set; }

        public string Purpose_Type { get; set; }

        public decimal? Budget_Amount { get; set; }
        public decimal? Capital_Expense_Amount { get; set; }
        public decimal? Expense_Amount { get; set; }
        public decimal? ExchangeRate_USD { get; set; }

        public string Coordinator_Name { get; set; }
        public string Coordinator_Section { get; set; }

        public string PositionApproval { get; set; }
        public string StatusProgress { get; set; } 
        public string FlagReapplication { get; set; }
    }


    public class LogHistory
    {
        public string Log { get; set; } 
    }


    public class BudgetSheetSave
    {
        public int AfdId { get; set; }
        public string BudgetClassification { get; set; }
        public List<BudgetSheet> Items { get; set; }
    }

    public class BudgetSheetRequestByClassification
    {
        public int AfdId { get; set; }
        public string BudgetClassification { get; set; }
    }

    public class VAReportRequest
    {
        public int AfdId { get; set; } 
    }

    public class BudgetSheet
    {
        public string ItemName { get; set; }

        public decimal MechMachImport { get; set; }
        public decimal MechMachLocal { get; set; }
        public decimal MechCons { get; set; }

        public decimal ElecMachImport { get; set; }
        public decimal ElecMachLocal { get; set; }
        public decimal ElecCons { get; set; }

        public decimal InstMachImport { get; set; }
        public decimal InstMachLocal { get; set; }
        public decimal InstCons { get; set; }

        public decimal CivilCons { get; set; }
         
        public string Remark { get; set; }
    }



    public class VAReportSave
    {
        public int AfdId { get; set; } 
        public decimal EffectVA { get; set; }
        public decimal ReductionRatioVA { get; set; }
        public List<VAReport> Items { get; set; }
    }


    public class VAReport
    {
        public string ItemName { get; set; } 
        public decimal BeforeVA { get; set; }
        public decimal AfterVA { get; set; }
        public decimal VAamountCAPEX { get; set; } 
        public decimal VAamountEXPENSE { get; set; } 
        public string Content { get; set; }
    }



    public class PrintBudgetSheetbyClassification
    {
        public string Budget_Classification { get; set; } // Capital / Expense
        public string Budget_Item { get; set; }

        public decimal Mech_Machine_Import { get; set; }
        public decimal Mech_Machine_Local { get; set; }
        public decimal Mech_Construction { get; set; }

        public decimal Elec_Machine_Import { get; set; }
        public decimal Elec_Machine_Local { get; set; }
        public decimal Elec_Construction { get; set; }

        public decimal Inst_Machine_Import { get; set; }
        public decimal Inst_Machine_Local { get; set; }
        public decimal Inst_Construction { get; set; }

        public decimal Civil_Construction { get; set; }

        public decimal SubTotal_Machine_Import { get; set; }
        public decimal SubTotal_Machine_Local { get; set; }
        public decimal SubTotal_Machine_Construction { get; set; }

        public decimal TOTAL { get; set; }

        public string Remark { get; set; }
         


    }


    public class PrintVAReport
    { 
        public string VA_Item { get; set; }
        public decimal Amount_Before_VA { get; set; }
        public decimal Amount_After_VA { get; set; }
        public decimal VA_Capital_Expenditure { get; set; }
        public decimal VA_Expense { get; set; }
        public string VA_Content { get; set; }
        public decimal  VA_Effect { get; set; }
        public decimal  VA_Reduction_Ratio { get; set; }


    }




    public class MasterRuleApproval
    {
        public string CostSection { get; set; }
        public List<RuleApprovalItem> Items { get; set; }
    }

    public class RuleApprovalItem
    {
        public int FormAFDID { get; set; }
        public int Step { get; set; }
        public string NIK { get; set; }
        public string SignName { get; set; }
        public string SignTitle { get; set; }
    }








}